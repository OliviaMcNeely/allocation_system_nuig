import React, {useState, useEffect} from 'react';
import {Link, useHistory} from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import MessageInbox from './InboxMessage';
import MessageSent from './SentMessage';
import './Inbox.css';
import AuthService from '../../../services/auth.service';
import MessageDataService from '../../../services/message.service';

function Inbox(props) {

    const currentUser = AuthService.getCurrentUser();
    const [messages, setMessages] = useState([]);
    const [inboxOpen, setInboxOpen] = useState(true);
    const [sentOpen, setSentOpen] = useState(false);
    const [mes, setMes] = useState(true);
    let history = useHistory();

    /* When component mounts check get the data */
    useEffect(() => {

        const { handle } = props.match.params;
        const user = AuthService.getCurrentUser();

        if (user) {
            if(handle === "inbox") {
                setInboxOpen(true);
                setSentOpen(false);
                MessageDataService.getAllReceivedMessages(currentUser.id)
                .then(response => {
                    setMessages(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
            else if(handle === "sent") {
                setInboxOpen(false);
                setSentOpen(true);
                MessageDataService.getAllSentMessages(currentUser.id)
                .then(response => {
                    setMessages(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        }
        else {
            AuthService.logout()
            history.push("/login");
        }

    },[currentUser.id, history, props.match.params]);

    /* Function to open the inbox tab */
    function handleInboxOpen() {

        MessageDataService.getAllReceivedMessages(currentUser.id)
        .then(response => {
            setMessages(response.data);
            setInboxOpen(true);
            setSentOpen(false);
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Function to open the sent tab */
    function handleSentOpen() {
        MessageDataService.getAllSentMessages(currentUser.id)
        .then(response => {
            setMessages(response.data);
            setInboxOpen(false);
            setSentOpen(true);
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Handle searching for messages */
    const [search, setSearch] = useState(false);
    const [searchTerm, setSearchTerm] = useState();
    function handleSearch() {
        if(document.getElementById("search").value === "") {
            setMes(true);
            setSearch(false);
        }
        else {
            setSearchTerm(document.getElementById("search").value);
            setSearch(true);
            setMes(false);
        }
    }

    /* Handle clearing the search bar */
    function handleClearSearch() {
        setSearch(false);
        setMes(true);
        document.getElementById("search").value = "";
    }

    return (
        <>
            <Navigation />
            <div className="topBar"></div>
            <div className="inboxContainer">
                <div className="inboxSideBar">
                    <div className="messageBtnContainer">
                        <Link to="/new/message">
                            <button className="newMessageBtn">New Message</button>
                        </Link>
                    </div>
                    <div className="inboxMenu">
                        <div className={inboxOpen ? "menuItemOpen" : "menuItem"} onClick={handleInboxOpen}>
                                <p>Inbox</p>
                        </div>
                        <div className={sentOpen ? "menuItemOpen" : "menuItem"} onClick={handleSentOpen}>
                                <p>Sent Items</p>
                        </div>
                    </div>
                </div>
                <div className="messagesContainer">
                    <div className="messagesWrapper">
                        <div className="searchBar">
                            <h1 className="searchTitle">Message Search</h1>
                            <input type="text" className="searchBox" placeholder="Search by keyword" id="search" onChange={handleSearch}></input>
                            <button className="searchButton" onClick={handleClearSearch}>Clear Search</button> 
                        </div>

                        {inboxOpen && 
                            <div className="messages">
                                {mes && messages &&
                                messages.map((message) => (
                                    <div key={message.messageId}>
                                        <MessageInbox
                                            path={"inbox/message/details/" + message.messageId}
                                            message={message.messageText}
                                            sender={message.rsender}
                                            date={message.date}
                                            open={message.opened}
                                            messageId={message.messageId}
                                        />
                                    </div>
                                ))}
                                {search && 
                                messages.filter(m => m.messageText.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                m.rsender.firstname.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                m.rsender.surname.toLowerCase().includes(searchTerm.toLowerCase())).map((message) => (
                                    <div key={message.messageId}>
                                        <MessageInbox
                                            path={"inbox/message/details/" + message.messageId}
                                            message={message.messageText}
                                            sender={message.rsender}
                                            date={message.date}
                                            open={message.opened}
                                            messageId={message.messageId}
                                        />
                                    </div>
                                ))}
                            </div>
                        }

                        {sentOpen && 
                            <div className="messages">
                                {mes && messages &&
                                messages.map((message) => (
                                    <div key={message.messageId}>
                                        <MessageSent
                                            path={"sent/message/details/" + message.messageId}
                                            message={message.messageText}
                                            recipient={message.rrecipient}
                                            date={message.date}
                                            open={message.opened}
                                            messageId={message.messageId}
                                        />
                                    </div>
                                ))}
                                {search && 
                                messages.filter(m => m.messageText.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                m.rrecipient.firstname.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                m.rrecipient.surname.toLowerCase().includes(searchTerm.toLowerCase())).map((message) => (
                                    <div key={message.messageId}>
                                        <MessageSent
                                            path={"inbox/message/details/" + message.messageId}
                                            message={message.messageText}
                                            recipient={message.rrecipient}
                                            date={message.date}
                                            open={message.opened}
                                            messageId={message.messageId}
                                        />
                                    </div>
                                ))}
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}

export default Inbox;
