import React, {useState, useEffect} from 'react';
import {Link, useHistory} from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import MessageDataService from '../../../services/message.service';
import FileUploadDataService from "../../../services/fileupload.service";
import Form from 'react-validation/build/form';
import AuthService from '../../../services/auth.service';

function MessageDetails(props) {

    const currentUser = AuthService.getCurrentUser();
    const [messageId] = useState(props.match.params.id);
    const [message, setMessage] = useState();
    const [profilePicture, setProfilePicture] = useState();
    let history = useHistory();

    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if (user) {
            MessageDataService.getMessage(messageId)
            .then(response => {
                setMessage(response.data);

                if(response.data.opened === false) {
                    MessageDataService.handleOpen(messageId)
                    .catch(e => {
                        console.log(e);
                    });
                }

                FileUploadDataService.checkProfilePicture(response.data.rsender.userId)
                .then((r) => {
                    if(r.data === false) {
                        setProfilePicture(undefined);
                    }
                    else {
                        FileUploadDataService.getProfilePicture(r.data)
                        .then((response) => {
                            setProfilePicture(response.data);
                        })
                        .catch(e => {
                            console.log(e);
                        });
                    }
                })
                .catch(e => {
                    console.log(e);
                }); 
            })
            .catch(e => {
                console.log(e);
            });
        }
        else {
            AuthService.logout()
            history.push("/login");
        }

    },[history, messageId]);

    const [replyOpen, setReplyOpen] = useState(false);
    function handleReplyOpen() {
        setReplyOpen(true);
    }

    function handleMessageSend() {

        var messageText = document.getElementById("messageReply").value;

        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();
        today = dd + '-' + mm + '-' + yyyy;

        let data =  {
            messageText: messageText,
            date: today
        }

        MessageDataService.createMessage(currentUser.id, message.rsender.userId, data)
        .then(() => {
            setReplyOpen(false);
            history.push("/inbox/sent");
        })
        .catch(e => {
            console.log(e);
        });

    }

    function handleReplyBack() {
        setReplyOpen(false);
    }

    return (
        <>
            <Navigation />
            <div className="topBar"></div>
            <div className="inboxContainer">
                <div className="inboxSideBar">
                    <div className="messageBtnContainer">
                        <Link to="/new/message">
                            <button className="newMessageBtn">New Message</button>
                        </Link>
                    </div>
                    <div className="inboxMenu">
                        <div className="menuItem">
                            <Link className="menuItemLink" to="/inbox/inbox">
                                <p>Inbox</p>
                            </Link>
                        </div>
                        <div className="menuItem">
                            <Link className="menuItemLink" to="/inbox/sent">
                                <p>Sent Items</p>
                            </Link>
                        </div>
                    </div>
                </div>
                <div className="messagesContainer">
                    <div className="messagesWrapper">
                        <div className="messageBox">
                            <div className="messageSenderHeader">
                                {profilePicture ? 
                                    <div className="messageImageContainerHeader">
                                        <img src={profilePicture.url} alt="profile" className="inbox_image" />
                                    </div>
                                    :
                                    <div className="messageImageContainerHeader">
                                        <img src={"images/default_picture.jpg"} alt="profile" className="inbox_image" />
                                    </div>
                                }
                                {message &&
                                    <>
                                        <p className="messageName">{message.rsender.firstname} {message.rsender.surname}</p>
                                    </>
                                }
                            </div>
                            <div className="messageDateHeader">
                                {message &&
                                    <p>{message.date}</p>
                                }
                            </div>
                            <hr className="bottom_line"/>
                            <div className="messageText">
                                {message &&
                                    <p>{message.messageText}</p>
                                }
                            </div>
                            <hr className="bottom_line"/>
                            <div>
                                <button className="replyButton" onClick={handleReplyOpen}>Reply</button>
                            </div>
                        </div>
                        {replyOpen && (
                            <div className="replyBox">
                                <Form onSubmit={handleMessageSend}>
                                    <textarea 
                                        id="messageReply" 
                                        className="replyTextArea" 
                                        rows="5"
                                    />
                                    <div className="replyButtons">
                                        <button type="submit" className="sendReplyButton">Send</button>
                                        <button type="button" className="exitReplyButton" onClick={handleReplyBack}>Back</button>
                                    </div>
                                </Form>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    )
}

export default MessageDetails;
