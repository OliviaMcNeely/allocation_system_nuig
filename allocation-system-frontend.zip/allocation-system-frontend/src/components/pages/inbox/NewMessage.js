import React, {useEffect, useState} from 'react';
import {useHistory} from 'react-router-dom';
import Form from 'react-validation/build/form';
import MessageDataService from '../../../services/message.service';
import AuthService from '../../../services/auth.service';
import Navigation from '../navigation/Navigation';
import StudentDataService from '../../../services/students.service';
import LecturerDataService from '../../../services/lecturer.service';

function NewMessage(props) {

    const currentUser = AuthService.getCurrentUser();
    let history = useHistory();
    const [users, setUsers] = useState([]);
    const [recipient, setRecipient] = useState([]);

    /* When component mounts check get the data */
    useEffect(() => {
        const user = AuthService.getCurrentUser();
        if (user) {
            if(user.roles.includes("ROLE_STUDENT")) {
                LecturerDataService.getAllLecturers()
                .then(response => {
                    setUsers(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
            else if(user.roles.includes("ROLE_LECTURER")) {
                StudentDataService.getAllStudents()
                .then(response => {
                    setUsers(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        }
        else {
            AuthService.logout()
            history.push("/login");
        }
    },[history]);

    function handleMessageSend() {

        var messageText = document.getElementById("messageReply").value;

        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();
        today = dd + '-' + mm + '-' + yyyy;

        let data =  {
            messageText: messageText,
            date: today
        }

        MessageDataService.createMessage(currentUser.id, recipient, data)
        .then(() => {
            history.push("/inbox/sent");
        })
        .catch(e => {
            console.log(e);
        });

    }

    function clearMessage() {
        document.getElementById("messageReply").value = "";
    }

    return (
        <>
            <Navigation />
            <div className="topBar"></div>
            <div className="inboxContainer2">
                <div className="replyBoxContainer">
                    <div className="replyBox">
                        <div className="recipientBar">
                            <p className="recipientTitle">Select Recipient</p>
                            <select required onChange={e => setRecipient(e.target.value)} className="recipientInput">
                                <option value="" disabled selected>Select name</option>
                                {users &&
                                users.map((user) => (
                                    <option value={currentUser.roles.includes("ROLE_LECTURER") ? user.studentId : user.lecturerId}>{user.firstname} {user.surname}</option>
                                ))}
                            </select> 
                            <p className="recipientTitle">Write Message</p>
                        </div>
                        <Form onSubmit={handleMessageSend}>
                            <textarea 
                                id="messageReply" 
                                className="replyTextArea" 
                                rows="5"
                            />
                            <div className="replyButtons">
                                <button type="submit" className="sendReplyButton">Send</button>
                                <button type="button" className="exitReplyButton" onClick={clearMessage}>Clear</button>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default NewMessage;
