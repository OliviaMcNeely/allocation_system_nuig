import React, { useState, useEffect } from 'react';
import {Link, useHistory} from 'react-router-dom';
import FileUploadDataService from "../../../services/fileupload.service";
import MessageDataService from '../../../services/message.service';
import AuthService from '../../../services/auth.service';

function Message(props) {

    const currentUser = AuthService.getCurrentUser();
    const [profilePicture, setProfilePicture] = useState();
    const [open, setOpen] = useState(props.open);
    let history = useHistory();

    /* When the component mounts get the data */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if (user) {
            FileUploadDataService.checkProfilePicture(props.sender.userId)
            .then((r) => {
                if(r.data === false) {
                    setProfilePicture(undefined);
                }
                else {
                    FileUploadDataService.getProfilePicture(r.data)
                    .then((response) => {
                        setProfilePicture(response.data);
                    })
                    .catch(e => {
                        console.log(e);
                    });
                }
            })
            .catch(e => {
                console.log(e);
            });
        }
        else {
            AuthService.logout()
            history.push("/login");
        }
        
    },[history, props.sender.userId]);

    /* Handle displaying the right amount of characters for message */
    const MAX_LENGTH = 100;
    const message = props.message;

    const handleOpen = () => {

        setOpen(!open);

        MessageDataService.handleOpen(props.messageId)
        .then(() => {
        })
        .catch(e => {
            console.log(e);
        });
    }

    const handleDelete = () => {

        MessageDataService.deleteReceivedMessage(props.messageId, currentUser.id)
        .then(() => {
            history.push("/inbox/inbox");
        })
        .catch(e => {
            console.log(e);
        });
    }

    return (
        <>
            <div className={open ? "messageContainer" : "messageContainer messageNotOpen"}>
                <div className="leftSideMessage">
                    <div className="messageSender">
                        {profilePicture ? 
                            <div className="messageImageContainer">
                                <img src={profilePicture.url} alt="profile" className="review_image" />
                            </div>
                            :
                            <div className="messageImageContainer">
                                <img src={"images/default_picture.jpg"} alt="profile" className="review_image" />
                            </div>
                        }
                        <p className="messageName">{props.sender.firstname} {props.sender.surname}</p>
                    </div>
                    <Link to={props.path} className="messageDetails">
                        <p>{`${message.substring(0, MAX_LENGTH)}...`}</p>
                    </Link>
                </div>
                <div>
                    <p className="messageDate">{props.date}</p>
                    <div className="iconOptions">
                        <i className="fas fa-trash-alt" onClick={handleDelete}></i>
                        <i className={open ? "fas fa-envelope" : "fas fa-envelope-open"} onClick={handleOpen}></i>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Message;
