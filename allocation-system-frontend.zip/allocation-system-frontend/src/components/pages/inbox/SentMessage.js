import React, { useState, useEffect } from 'react';
import {Link, useHistory} from 'react-router-dom';
import FileUploadDataService from "../../../services/fileupload.service";
import MessageDataService from '../../../services/message.service';
import AuthService from '../../../services/auth.service';

function Message(props) {

    const currentUser = AuthService.getCurrentUser();
    const [profilePicture, setProfilePicture] = useState();
    let history = useHistory();

    /* When the component mounts get the student, experience, education and skills data */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if (user) {
            FileUploadDataService.checkProfilePicture(props.recipient.userId)
            .then((r) => {
                if(r.data === false) {
                    setProfilePicture(undefined);
                }
                else {
                    FileUploadDataService.getProfilePicture(r.data)
                    .then((response) => {
                        setProfilePicture(response.data);
                    })
                    .catch(e => {
                        console.log(e);
                    });
                }
            })
            .catch(e => {
                console.log(e);
            });
        }
        else {
            AuthService.logout()
            history.push("/login");
        }

    },[history, props.recipient.userId]);

    /* Handle displaying the right amount of characters for message */
    const MAX_LENGTH = 100;
    const message = props.message;

    const handleDelete = () => {

        MessageDataService.deleteSentMessage(props.messageId, currentUser.id)
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    return (
        <>
            <div className="messageContainer">
                <div className="leftSideMessage">
                    <div className="messageSender">
                        {profilePicture ? 
                            <div className="messageImageContainer">
                                <img src={profilePicture.url} alt="profile" className="review_image" />
                            </div>
                            :
                            <div className="messageImageContainer">
                                <img src={"images/default_picture.jpg"} alt="profile" className="review_image" />
                            </div>
                        }
                        <p className="messageName">{props.recipient.firstname} {props.recipient.surname}</p>
                    </div>
                    <Link to={props.path} className="messageDetails">
                        <p>{`${message.substring(0, MAX_LENGTH)}...`}</p>
                    </Link>
                </div>
                <div>
                    <p className="messageDate">{props.date}</p>
                    <div className="iconOptions">
                        <i className="fas fa-trash-alt" onClick={handleDelete}></i>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Message;