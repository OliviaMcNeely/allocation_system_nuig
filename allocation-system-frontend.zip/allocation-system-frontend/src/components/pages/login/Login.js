import React, {useState, useRef} from 'react';
import {Link, useHistory} from 'react-router-dom';
import './Login.css';
import Form from 'react-validation/build/form';
import AuthDataService from '../../../services/auth.service';

function Login() {

    const form = useRef();
    const [username, setUsername] = useState();
    const [password, setPassword] = useState();
    const [error, setError] = useState(false);
    let history = useHistory();

    /* function to login the user */
    function handleLogin(e) {
    
        e.preventDefault();
        form.current.validateAll();

        AuthDataService.login(username, password)
        .then(() => {
            history.push("/home");
        })
        .catch(ex => {
            setError(true);
        });
    }

    return (
        <>
            <div className="login">
                <div className="login_box">
                    <img src={"/images/NUIG_logo.jpg"} alt="NUIG" className="login_logo"/>
                    <h1>Welcome to Lab Tutor Allocation</h1>
                    <p>Login using your Student/Staff ID and your password.</p>
                    <Form onSubmit={handleLogin} ref={form}>
                        <div className="login_form">
                            <input 
                                type="text" 
                                className="id_input" 
                                placeholder="Student/Staff ID" 
                                required 
                                onChange={e => setUsername(e.target.value)}
                            />
                            <input 
                                type="password" 
                                className="password_input" 
                                placeholder="Password" 
                                required 
                                onChange={e => setPassword(e.target.value)}
                            />
                            {error &&
                                <div className="login_error">
                                    <p>Wrong ID or password!</p>
                                    <p>Try again!</p>
                                </div>
                            }
                            <button className="login_button">Login</button>
                        </div>
                    </Form>
                    <p className="register_para">
                        Don't have an account?
                        <Link className="register_link" to="/register">Register here</Link>
                    </p>
                </div>
            </div>
        </>
    );
}

export default Login;