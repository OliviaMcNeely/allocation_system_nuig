import React, {useState, useRef} from 'react';
import {Link} from 'react-router-dom';
import './Register.css';
import Form from "react-validation/build/form";
import AuthDataService from "../../../services/auth.service";

function Register(props) {

    const [user, setUser] = useState("NONE");

    /* Show student register */
    function handleStudent() {
        setError("");
        setUser("STUDENT");
    }

    /* Show lecturer register */
    function handleLecturer() {
        setError("");
        setUser("LECTURER");
    }

    /* Back to select options */
    function handleBack() {
        setError("");
        setUser("NONE");
    }

    const form = useRef();
    const [firstname, setFirstname] = useState();
    const [surname, setSurname] = useState();
    const [school, setSchool] = useState("Chemistry");
    const [level, setLevel] = useState("Unset");
    const [username, setUsername] = useState();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const [error, setError] = useState();


    /* Function to register the Student details */
    function handleRegisterStudent(e) {

        e.preventDefault();
        form.current.validateAll();

        let sdata = {
            username: username, 
            email: email,
            password: password, 
            firstname: firstname, 
            surname: surname,
            school: school,
            level: level
        }

        AuthDataService.registerStudent(sdata)
        .then((response) => {
            console.log(response.data);
            if(response.data.message === "Error: ID is already in use!") {
                setError("Error: ID is already in use!");
            }
            else if(response.data.message === "Error: Email is already in use!") {
                setError("Error: Email is already in use!");
            }
            else {
                props.history.push("/login");
            }
        })
        .catch(ex => {
            console.log(ex);
            setError("Error Registering Student: ID or email already in use");
        });

    }


    /* Function to register the Lecturer details */
    function handleRegisterLecturer(e) {

        e.preventDefault();
        form.current.validateAll();

        let ldata = {
            username: username, 
            email: email,
            password: password, 
            firstname: firstname, 
            surname: surname,
            school: school
        }

        AuthDataService.registerLecturer(ldata)
        .then((response) => {
            if(response.data.message === "Error: ID is already in use!") {
                setError("Error: ID is already in use!");
            }
            else if(response.data.message === "Error: Email is already in use!") {
                setError("Error: Email is already in use!");
            }
            else {
                props.history.push("/login");
            }
        })
        .catch(ex => {
            console.log(ex);
            setError("Error Registering Lecturer: ID or email already in use");
        });

    }

    return (
        <div className="register">
            <div className="register_container">
                <img src={"/images/NUIG_logo.jpg"} alt="NUIG" className="register_logo"/>
                <h1>Lab Tutor Allocation Register</h1>

                {user === "NONE" && (
                    <>
                        <p>Select the option that applies to you</p>

                        <div className="register_option" onClick={handleStudent}>
                            <p>Student Register</p>
                        </div>
                        <div className="lecturer_register register_option" onClick={handleLecturer}>
                            <p>Lecturer Register</p>
                        </div>
                    </>
                )}

                {user === "STUDENT" && (
                    <>
                        <button className="backButton" onClick={handleBack}>Back to select</button>
                        <Form onSubmit={handleRegisterStudent} ref={form}>
                            <p>Student Details</p>
                            <input 
                                type="text" 
                                className="firstnameInput" 
                                placeholder="Firstname" 
                                required 
                                onChange={e => setFirstname(e.target.value)}
                            />
                            <input 
                                type="text" 
                                className="surnameInput" 
                                placeholder="Surname" 
                                required 
                                onChange={e => setSurname(e.target.value)}
                            />
                            <select required onChange={e => setSchool(e.target.value)} className="schoolInput">
                                <option value="Chemistry">Chemistry</option>
                                <option value="Computer Science">Computer Science</option>
                                <option value="Engineering">Engineering</option>
                                <option value="Mathematics, Statistics and Applied Mathematics">Mathematics, Statistics and Applied Mathematics</option>
                                <option value="Natural Sciences">Natural Sciences</option>
                                <option value="Physics">Physics</option>
                            </select>
                            <select required onChange={e => setLevel(e.target.value)} className="schoolInput">
                                <option value="PostGraduate Masters">PostGraduate Masters</option>
                                <option value="PostGrdauate PHD">PostGrdauate PHD</option>
                                <option value="UnderGraduate">UnderGraduate</option>
                            </select>
                            <input 
                                type="text" 
                                className="idInput" 
                                placeholder="Student ID" 
                                required 
                                onChange={e => setUsername(e.target.value)}
                            />
                            <input 
                                type="text" 
                                className="emailInput" 
                                placeholder="College Email" 
                                required 
                                onChange={e => setEmail(e.target.value)}
                            />
                            <input 
                                type="password" 
                                className="passwordInput" 
                                placeholder="Password" 
                                required 
                                onChange={e => setPassword(e.target.value)}
                            />
                            {error &&
                                <div className="error">
                                    <p>{error}</p>
                                </div>
                            }
                            <button className="registerButton">Register Student</button>

                        </Form>
                    </>
                )}

                {user === "LECTURER" && (
                    <>
                        <button className="backButton" onClick={handleBack}>Back to select</button>
                        <Form onSubmit={handleRegisterLecturer} ref={form}>
                            <p>Lecturer Details</p>
                            <input 
                                type="text" 
                                className="firstnameInput" 
                                placeholder="Firstname" 
                                required 
                                onChange={e => setFirstname(e.target.value)}
                            />
                            <input 
                                type="text" 
                                className="surnameInput" 
                                placeholder="Surname" 
                                required 
                                onChange={e => setSurname(e.target.value)}
                            />
                            <select required onChange={e => setSchool(e.target.value)} className="schoolInput">
                                <option value="Chemistry">Chemistry</option>
                                <option value="Computer Science">Computer Science</option>
                                <option value="Engineering">Engineering</option>
                                <option value="Mathematics, Statistics and Applied Mathematics">Mathematics, Statistics and Applied Mathematics</option>
                                <option value="Natural Sciences">Natural Sciences</option>
                                <option value="Physics">Physics</option>
                            </select>
                            <input 
                                type="text" 
                                className="idInput" 
                                placeholder="Staff ID" 
                                required 
                                onChange={e => setUsername(e.target.value)}
                            />
                            <input 
                                type="text" 
                                className="emailInput" 
                                placeholder="College Email" 
                                required 
                                onChange={e => setEmail(e.target.value)}
                            />
                            <input 
                                type="text" 
                                className="passwordInput" 
                                placeholder="Password" 
                                required 
                                onChange={e => setPassword(e.target.value)}
                            />
                            {error &&
                                <div className="error">
                                    <p>{error}</p>
                                </div>
                            }
                            <button className="registerButton">Register Lecturer</button>

                        </Form>
                    </>
                )}
                
                <p className="register_para">
                    Already have an account?
                    <Link className="register_link" to="/login">Login</Link>
                </p>
                
            </div>
        </div>
    )
}

export default Register;
