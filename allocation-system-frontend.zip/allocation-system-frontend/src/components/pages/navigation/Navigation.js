import React, { useState, useEffect } from 'react';
import { NavLink, useHistory } from 'react-router-dom';
import './Navigation.css';
import AuthService from '../../../services/auth.service';

function Navigation() {

    const [profile, setProfile] = useState();
    const [applications, setApplications] = useState();
    const [positionsPath, setPositionsPath] = useState("/positions");
    const [positions, setPositions] = useState("Positions");

    /* When component mounts check the current user to display the correct home page */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if (user) {
            if(user.roles.includes("ROLE_STUDENT")) {
                setProfile(true);
                setPositionsPath("/positions/all");
                setPositions("Positions");
                setApplications(false);
            }
            else if(user.roles.includes("ROLE_LECTURER")) {
                setProfile(false);
                setPositionsPath("/uploaded/positions");
                setPositions("My Positions");
                setApplications(true);
            }
        }
    }, []);

    let history = useHistory();

    /* Function to signout of the application and clear the current user data*/
    function signout() {
        AuthService.logout()
        history.push("/login");
    }

    return (
        <>
            <nav className="nav-bar">

                <div className="top-bar">
                </div>

                <img src={"/images/NUIG_logo.jpg"} alt="NUIG" className="logo" />

                <ul className="nav-menu">

                    <NavLink 
                        to="/home" 
                        activeClassName="link-active" 
                        className="nav-link"
                    >
                        <div className="nav-icon-container">
                            <i className="fas fa-home nav-icon"></i>
                        </div>
                        <p className="nav-text">Home</p>
                    </NavLink>

                    {profile && (
                        <NavLink 
                            to="/student/profile/info"
                            activeClassName="link-active" 
                            className="nav-link"
                        >
                            <div className="nav-icon-container">
                                <i className="fas fa-user-circle nav-icon"></i>
                            </div>
                            <p className="nav-text">Profile</p>
                        </NavLink>
                    )}
                    
                    <NavLink 
                        to={positionsPath}
                        activeClassName="link-active"
                        className="nav-link"
                    >
                        <div className="nav-icon-container">
                            <i className="fas fa-chalkboard-teacher nav-icon"></i>
                        </div>
                        <p className="nav-text">{positions}</p>
                    </NavLink>

                    {applications && (
                        <NavLink 
                            to="/all/applications/received"
                            activeClassName="link-active" 
                            className="nav-link"
                        >
                            <div className="nav-icon-container">
                                <i className="fas fa-file-signature nav-icon"></i>
                            </div>
                            <p className="nav-text">All Applications</p>
                        </NavLink>
                    )}

                    <NavLink 
                        to="/inbox/inbox" 
                        activeClassName="link-active" 
                        className="nav-link"
                    >
                        <div className="nav-icon-container">
                            <i className="fas fa-inbox nav-icon"></i>
                        </div>
                        <p className="nav-text">Inbox</p>
                    </NavLink>

                    <button className="signout_btn" onClick={signout}>Sign Out</button>

                </ul>
            </nav>
        </>
    );
}

export default Navigation;