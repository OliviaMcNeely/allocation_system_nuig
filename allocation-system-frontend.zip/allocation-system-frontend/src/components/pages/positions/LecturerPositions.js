import React, {useState, useEffect} from 'react';
import {Link, useHistory} from 'react-router-dom';
import './Positions.css';
import Navigation from '../navigation/Navigation';
import Position from './LecturerPosition';
import AuthService from '../../../services/auth.service';
import PositionDataService from '../../../services/positions.service';

function PositionsLecturer() {
    
    const currentUser = AuthService.getCurrentUser();
    const [positions, setPositions] = useState([]);
    const [pos, setPos] = useState(true);
    let history = useHistory();

    /* When component mounts get the lecturers positions */
    useEffect(() => {

        if(!currentUser || !currentUser.roles.includes("ROLE_LECTURER")) {
            AuthService.logout()
            history.push("/login");
        }

        PositionDataService.getAllLecturerPositions(currentUser.id)
        .then(response => {
            setPositions(response.data);
        })
        .catch(e => {
            console.log(e);
        });

    },[currentUser, history]);

    /* Handle searching for positions */
    const [search, setSearch] = useState(false);
    const [searchTerm, setSearchTerm] = useState();
    function handleSearch() {
        if(document.getElementById("search").value === "") {
            setPos(true);
            setSearch(false);
        }
        else {
            setSearchTerm(document.getElementById("search").value);
            setSearch(true);
            setPos(false);
        }
    }

    /* Handle clearing the search bar */
    function handleClearSearch() {
        setSearch(false);
        setPos(true);
        document.getElementById("search").value = "";
    }

    return (
        <>
            <Navigation/>
            <div className="topBar"></div>

            <div className="positionsLContainer">

                <div className="positionsInfoLContainer">
                    <div className="positionsInfoLWrapper">

                        <div className="searchUploadBar">
                            <div className="searchSide">
                                <h1 className="searchLTitle">Search for a position</h1>
                                <input type="text" className="searchLBox" placeholder="Search by module name or code" id="search" onChange={handleSearch}></input>
                                <button className="searchLButton" onClick={handleClearSearch}>Clear Search</button>
                            </div>
                            <hr className="verticalLine"/>
                            <div className="uploadSide">
                                <div className="uploadDivs">
                                    <h1 className="uploadTitle">Upload new position</h1>
                                </div>
                                <div className="uploadDivs">
                                    <Link to="/upload/position">
                                        <button className="newButton">NEW</button>
                                    </Link>
                                </div>
                            </div>
                        </div>

                        <div className="positions">
                            <div className="positionsLTitle">
                                <h1 className="positionsTitle">Uploaded Positions</h1>
                            </div>
                            <hr className="titleLine"/>

                            {pos &&
                            positions.map((position, index) => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                            {search &&
                            positions.filter(p => p.moduleTitle.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            p.moduleCode.toLowerCase().includes(searchTerm.toLowerCase())).map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                        </div>
                    </div>
                </div>
            </div>
        </>
    );

}

export default PositionsLecturer;
