import React, {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import AuthService from '../../../services/auth.service';
import PositionDataService from "../../../services/positions.service";
import Form from 'react-validation/build/form';

function PositionUpload() {

    const currentUser = AuthService.getCurrentUser();

    const [description, setDescription] = useState();
    const [moduleCode, setModuleCode] = useState();
    const [moduleTitle, setModuleTitle] = useState();
    const [school, setSchool] = useState("Chemistry");
    const [totalHours, setTotalHours] = useState();
    const [assignmentCorrections, setAssignmentCorrections] = useState(true);
    const [numTutors, setNumTutors] = useState();
    const [graduateLevel, setGraduateLevel] = useState("Undergraduate");
    const [semester, setSemester] = useState("Semester 1");
    const [location, setLocation] = useState("Online");
    const [daytimes, setDaytimes] = useState("Undecided");
    const [charCount, setCharCount] = useState(0);

    let history = useHistory();

    /* When component mounts */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user || !user.roles.includes("ROLE_LECTURER")) {
            AuthService.logout()
            history.push("/login");
        }
    },[history]);

    function handlePositionUpload() {

        var daytime = "";
        for (let i = 0; i < daytimes.length; i++) {
            if(i === daytimes.length-1) {
                daytime += daytimes[i].attributes.value.nodeValue;
            }
            else {
                daytime += daytimes[i].attributes.value.nodeValue + ", ";
            }
        }

        var data = {
            moduleCode : moduleCode,
            moduleTitle : moduleTitle,
            school : school,
            hours: totalHours,
            assignmentCorrections : assignmentCorrections,
            numTutors : numTutors,
            description : description,
            graduateLevel : graduateLevel,
            semester : semester,
            location: location,
            daytime: daytime
        }
        
        PositionDataService.createPosition(currentUser.id, data)
        .then(response  => {
            history.push("/position/details/"+response.data.positionId);
        })
        .catch(e => {
            console.log(e);
        });
    }

    function countChar(e) {
        var currentText = e.target.value;
        setCharCount(currentText.length);
    }

    return (
        <>
            <Navigation/>
            <div className="topBar"></div>
            <div className="positionDetailsWrapper">
                <Form className="positionDetailsContainer" onSubmit={handlePositionUpload}>
                    <div className="positionDetailsTitle">
                        <p className="detailsTitle">Upload Position</p>
                    </div>
                    
                    <hr className="titleUnderLine"/>

                    <div className="positionDetailsDescription">
                        <div className="section_header">
                            <p className="detailsSmallTitle">Description</p>
                        </div>
                        <p className="descriptionNote">The more detail given here the better the student recommendations will be. Minimum character count 300.</p>
                        <textarea 
                            id="description" 
                            className="description_textarea" 
                            rows="5"
                            onChange={e => setDescription(e.target.value)}
                            required
                            type="text"
                            minLength="300"
                            maxLength="10000"
                            onKeyUp={countChar}
                        />
                        <p className="character_text" id="characters">
                            {charCount} characters used
                        </p>
                    </div>
                    
                    <hr className="underLine"/>

                    <div className="detailsMainContainer">
                        <div className="section_header">
                            <p className="detailsSmallTitle">Position Details</p>
                        </div>

                        <div className="inputContainer">
                            <label className="inputLabel">School:</label>
                            <select required onChange={e => setSchool(e.target.value)} className="input">
                                <option value="Chemistry">Chemistry</option>
                                <option value="Computer Science">Computer Science</option>
                                <option value="Engineering">Engineering</option>
                                <option value="Mathematics, Statistics and Applied Mathematics">Mathematics, Statistics and Applied Mathematics</option>
                                <option value="Natural Sciences">Natural Sciences</option>
                                <option value="Physics">Physics</option>
                            </select>
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Semester:</label>
                            <select required onChange={e => setSemester(e.target.value)} className="input">
                                <option value="Semester 1">Semester 1</option>
                                <option value="Semester 2">Semester 2</option>
                                <option value="Semester 1 and Semester 2">Semester 1 and Semester 2</option>
                            </select>
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Module code:</label>
                            <input 
                                type="text"
                                required 
                                onChange={e => setModuleCode(e.target.value)}
                                className="input"
                            />
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Module title:</label>
                            <input 
                                type="text"
                                required 
                                onChange={e => setModuleTitle(e.target.value)}
                                className="input"
                            />
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Module level:</label>
                            <select required onChange={e => setGraduateLevel(e.target.value)} className="input">
                                <option value="Undergraduate">Undergraduate</option>
                                <option value="Postgraduate">Postgraduate</option>
                            </select>
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Location:</label>
                            <select required onChange={e => setLocation(e.target.value)} className="input">
                                <option value="Online">Online</option>
                                <option value="In Person">In Person</option>
                                <option value="Online and In Person">Online and In Person</option>
                            </select>
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Total hours per tutor:</label>
                            <input 
                                type="number"
                                required 
                                onChange={e => setTotalHours(e.target.value)}
                                className="input"
                            />
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Number of Tutors:</label>
                            <input 
                                type="number"
                                required 
                                onChange={e => setNumTutors(e.target.value)}
                                className="input"
                            />
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Assignments corrections?</label>
                            <select required onChange={e => setAssignmentCorrections(e.target.value)} className="input">
                                <option value="true">Yes</option>
                                <option value="false">No</option>
                            </select>
                        </div>
                        <div className="inputContainer">
                            <label className="inputLabel">Days and Times:</label>
                            <select onChange={e => setDaytimes(e.target.selectedOptions)} defaultValue={daytimes} className="input" size="3" multiple>
                                <option value="Undecided">Undecided</option>
                                <option value="Monday 9am">Monday 9am</option>
                                <option value="Monday 10am">Monday 10am</option>
                                <option value="Monday 11am">Monday 11am</option>
                                <option value="Monday 12pm">Monday 12am</option>
                                <option value="Monday 1pm">Monday 1pm</option>
                                <option value="Monday 2pm">Monday 2pm</option>
                                <option value="Monday 3pm">Monday 3pm</option>
                                <option value="Monday 4pm">Monday 4pm</option>
                                <option value="Monday 5pm">Monday 5pm</option>
                                <option value="Tuesday 9am">Tuesday 9am</option>
                                <option value="Tuesday 10am">Tuesday 10am</option>
                                <option value="Tuesday 11am">Tuesday 11am</option>
                                <option value="Tuesday 12pm">Tuesday 12am</option>
                                <option value="Tuesday 1pm">Tuesday 1pm</option>
                                <option value="Tuesday 2pm">Tuesday 2pm</option>
                                <option value="Tuesday 3pm">Tuesday 3pm</option>
                                <option value="Tuesday 4pm">Tuesday 4pm</option>
                                <option value="Tuesday 5pm">Tuesday 5pm</option>
                                <option value="Wednesday 9am">Wednesday 9am</option>
                                <option value="Wednesday 10am">Wednesday 10am</option>
                                <option value="Wednesday 11am">Wednesday 11am</option>
                                <option value="Wednesday 12pm">Wednesday 12am</option>
                                <option value="Wednesday 1pm">Wednesday 1pm</option>
                                <option value="Wednesday 2pm">Wednesday 2pm</option>
                                <option value="Wednesday 3pm">Wednesday 3pm</option>
                                <option value="Wednesday 4pm">Wednesday 4pm</option>
                                <option value="Wednesday 5pm">Wednesday 5pm</option>
                                <option value="Thursday 9am">Thursday 9am</option>
                                <option value="Thursday 10am">Thursday 10am</option>
                                <option value="Thursday 11am">Thursday 11am</option>
                                <option value="Thursday 12pm">Thursday 12am</option>
                                <option value="Thursday 1pm">Thursday 1pm</option>
                                <option value="Thursday 2pm">Thursday 2pm</option>
                                <option value="Thursday 3pm">Thursday 3pm</option>
                                <option value="Thursday 4pm">Thursday 4pm</option>
                                <option value="Thursday 5pm">Thursday 5pm</option>
                                <option value="Friday 9am">Friday 9am</option>
                                <option value="Friday 10am">Friday 10am</option>
                                <option value="Friday 11am">Friday 11am</option>
                                <option value="Friday 12pm">Friday 12am</option>
                                <option value="Friday 1pm">Fridayy 1pm</option>
                                <option value="Friday 2pm">Friday 2pm</option>
                                <option value="Friday 3pm">Friday 3pm</option>
                                <option value="Friday 4pm">Friday 4pm</option>
                                <option value="Friday 5pm">Friday 5pm</option>
                            </select>
                        </div>
                        <p className="labelnote">*Press CTRL/CMD and select all that apply</p>
                        <p className="skills_message">There will be a chance to add position skills after uploading.</p>
                    </div>
                    
                    <hr className="underLine"/>

                    <div className="buttonContainer">
                        <button type="submit" className="uploadButton">Upload</button>
                    </div>
                </Form>
            </div>
        </>
    )
}

export default PositionUpload;
