import React, {useState, useEffect} from 'react';
import {Link, useHistory} from 'react-router-dom';
import '../students/Students.css';
import Navigation from '../navigation/Navigation';
import PositionDataService from '../../../services/positions.service';
import AuthService from '../../../services/auth.service';
import ApplicationDataService from '../../../services/application.service';

function PositionRecommendations(props) {

    const [positionId] = useState(props.match.params.id);
    const [position, setPosition] = useState([]);
    const [list, setList] = useState(true);
    const [students, setStudents] = useState([]);
    let history = useHistory();

    /* When component mounts */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user || !user.roles.includes("ROLE_LECTURER")) {
            AuthService.logout()
            history.push("/login");
        }

        PositionDataService.checkRecommendations(positionId)
        .then(response => {
            if(response.data === false) {
                setList(false);
                PositionDataService.getRecommendationList(positionId)
                .then(r => {
                    setStudents(r.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

        PositionDataService.getPosition(positionId)
        .then(response => {
            setPosition(response.data);
        })
        .catch(e => {
            console.log(e);
        });

    },[history, positionId]);

    function generateList() {
        PositionDataService.generateRecommendationList(positionId)
        .then(response => {
            setStudents(response.data);
            history.push("/position/recommendations/"+positionId);
        })
        .catch(e => {
            console.log(e);
        });
    }

    function offerPosition(e) {
        var studentId = (e.target.name);
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();
        today = dd + '-' + mm + '-' + yyyy;

        let data = {
            dateApplied: today
        }

        ApplicationDataService.applicationExists(studentId, positionId)
        .then((response) => {
            if(response.data === true) {
                ApplicationDataService.findApplication(studentId, positionId)
                .then((response) => {
                    ApplicationDataService.updateStatus(response.data.applicationId, "offered")
                    .then(() => {
                        history.push("/position/applications/"+positionId+"/offered");
                    })
                    .catch(e => {
                        console.log(e);
                    });
                })
                .catch(e => {
                    console.log(e);
                });
            }
            else if(response.data === false) {
                ApplicationDataService.createApplication(studentId, positionId, data)
                .then((response) => {
                    ApplicationDataService.findApplication(studentId, positionId)
                    .then((response) => {
                        ApplicationDataService.updateStatus(response.data.applicationId, "offered")
                        .then(() => {
                            history.push("/position/applications/"+positionId+"/offered");
                            window.location.reload();
                        })
                        .catch(e => {
                            console.log(e);
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });
    }

    return (
        <>
            <Navigation/>
            <div className="top__bar"></div>

            <div className="students__list__container">
                <div className="students__list__wrapper">

                    <div className="students__">
                        <h1 className="students__title">Top Recommended Students - {position.moduleTitle}</h1>
                        <hr className="title__line"/>

                        {list ? (
                            <>
                                <p className="recTextB">Recommended Students haven't been generated.</p>
                                <p className="recText">Click on the button below to get a list of student profiles that match this position along with a similarity score.</p>
                                <button className="generateButton" onClick={generateList}>Generate Recommended Students</button>
                            </>
                        ) : (
                            <>
                                {students &&
                                students.map((student, index) => (
                                    <div key={index} className="student__container">
                                        <Link 
                                            to={{
                                                pathname: `/student/details/`+student.studentId
                                            }}
                                            className="student__link" 
                                        >
                                            <div className="details__container">
                                                <p className="p1">{student.name}</p>
                                                <p className="p2">{student.school} - {student.course}</p>
                                                <button className="profileBtn">View Profile</button>
                                            </div>
                                        </Link>
                                        <div className="recommendation__container">
                                            <p className="scoreText">Recommendation Score: {student.score}%</p>
                                            <button className="offerBtn" onClick={offerPosition} name={student.studentId}>Offer Position</button>
                                        </div>
                                        <hr className="underLine"/>
                                    </div>
                                ))}
                                <p className="recTextB">It is advised to regenerate this list frequently as students may have updated their profiles.</p>
                                <button className="generateButton" onClick={generateList}>Regenerate Recommended Students</button>
                            </>
                        )}

                    </div>
                </div>
            </div>
        </>
    )
}

export default PositionRecommendations;