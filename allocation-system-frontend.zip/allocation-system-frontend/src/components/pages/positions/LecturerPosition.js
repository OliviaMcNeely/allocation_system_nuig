import React from 'react';
import {Link, useHistory} from 'react-router-dom';
import './Positions.css';
import PositionDataService from '../../../services/positions.service';

function PositionLecturer(props) {

    let history = useHistory();

    /* Handle deleting the position */
    function deletePosition() {
        PositionDataService.deletePosition(props.positionId)
        .then(() => {
            history.push("/uploaded/positions");
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Handle displaying the right amount of characters for description */
    const MAX_LENGTH = 200;
    const description = props.description;

    return (
        <>
            <div className="positionContainer">
                <Link to={{pathname: `/position/details/`+props.positionId}} className="positionLink">
                    <div className="detailsLContainer">
                        <p>{props.moduleCode}</p>
                        <p className="detailsLTitle">{props.title}</p>
                    </div>
                </Link>
                <div className="descriptionContainer">
                    {description.length > MAX_LENGTH ? (
                        <Link to={{pathname: `/position/details/`+props.positionId}} className="positionLink">
                            <p>
                                {`${description.substring(0, MAX_LENGTH)}...`}
                            </p>
                        </Link>
                    ) : (
                        <Link to={{pathname: `/position/details/`+props.positionId}} className="positionLink">
                            <p>{description}</p>
                        </Link>
                    )}
                </div>
                <div>
                    <Link to={{pathname: `/position/applications/`+props.positionId+`/received`}}>
                        <button className="posBtn">View Applications</button>
                    </Link>
                    <Link to={{pathname: `/position/recommendations/`+props.positionId}}>
                        <button className="posBtn">View Recommended Students</button>
                    </Link>
                    <button className="posBtn" onClick={deletePosition}>Delete Position</button>
                </div>
                <hr className="underLine"/>
            </div>
        </>
    );
}

export default PositionLecturer;