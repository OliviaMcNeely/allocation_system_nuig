import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import './Positions.css';
import Navigation from '../navigation/Navigation';
import Position from './AllPosition';
import AuthService from '../../../services/auth.service';
import PositionDataService from '../../../services/positions.service';

function AllPositions(props) {

    const currentUser = AuthService.getCurrentUser();
    const [role, setRole] = useState("STUDENT");
    const [positions, setPositions] = useState([]);
    const [pos, setPos] = useState(true);
    const [cs, setCS] = useState(false);
    const [eng, setEng] = useState(false);
    const [chem, setChem] = useState(false);
    const [math, setMath] = useState(false);
    const [nat, setNat] = useState(false);
    const [phy, setPhy] = useState(false);
    let history = useHistory();

    /* When component mounts check the url for the right content and get all the positions */
    useEffect(() => {

        const user = AuthService.getCurrentUser();
        const {handle} = props.match.params;

        if(!user){
            AuthService.logout()
            history.push("/login");
        }
        else if(user.roles.includes("ROLE_STUDENT")) {
            setRole("STUDENT");

            if(handle === "likes") {
                document.getElementById("fpcheckbox").checked = true;
                handleFavCheck();
            }
            else if(handle === "offers") {
                document.getElementById("opcheckbox").checked = true;
                handleOfferCheck();
            }
            else if(handle === "applications") {
                document.getElementById("pacheckbox").checked = true;
                handleApplCheck();
            }
            else if(handle === "all") {
                document.getElementById("fpcheckbox").checked = false;
                document.getElementById("opcheckbox").checked = false;
                document.getElementById("pacheckbox").checked = false;
                PositionDataService.getAllPositions()
                .then(response => {
                    setPositions(response.data);
                    if(response.data === null) {
                        setPositions([]);
                    }
                })
                .catch(e => {
                    console.log(e);
                });
            }
        }
        else if(user.roles.includes("ROLE_LECTURER")) {
            setRole("LECTURER");
            PositionDataService.getAllPositions()
            .then(response => {
                setPositions(response.data);
                if(response.data === null) {
                    setPositions([]);
                }
            })
            .catch(e => {
                console.log(e);
            });
        }

    // eslint-disable-next-line react-hooks/exhaustive-deps
    },[props.match.params]);

    /* Handle open and close filters when in small screen */
    const [open, setOpen] = useState(false);
    function handleOpen() {
        setOpen(!open);
    }

    /* Handle setting the favourite filter */
    function handleFavCheck() {
        if(document.getElementById("fpcheckbox").checked === true) {
            document.getElementById("opcheckbox").checked = false;
            document.getElementById("pacheckbox").checked = false;
            document.getElementById("accheckbox").checked = false;
            document.getElementById("recheckbox").checked = false;
            document.getElementById("decheckbox").checked = false;
            PositionDataService.getAllFavouritedPositions(currentUser.id)
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        } else if(document.getElementById("fpcheckbox").checked === false) {
            PositionDataService.getAllPositions()
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle setting the offered filter */
    function handleOfferCheck() {
        if(document.getElementById("opcheckbox").checked === true) {
            document.getElementById("fpcheckbox").checked = false;
            document.getElementById("pacheckbox").checked = false;
            document.getElementById("accheckbox").checked = false;
            document.getElementById("recheckbox").checked = false;
            document.getElementById("decheckbox").checked = false;
            PositionDataService.getAllAppliedPositionsByStatus(currentUser.id, "offered")
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        } else if(document.getElementById("opcheckbox").checked === false) {
            PositionDataService.getAllPositions()
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle setting the applied filter */
    function handleApplCheck() {
        if(document.getElementById("pacheckbox").checked === true) {
            document.getElementById("fpcheckbox").checked = false;
            document.getElementById("opcheckbox").checked = false;
            document.getElementById("accheckbox").checked = false;
            document.getElementById("recheckbox").checked = false;
            document.getElementById("decheckbox").checked = false;
            PositionDataService.getAllAppliedPositionsByStatus(currentUser.id, "received")
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        } else if(document.getElementById("pacheckbox").checked === false) {
            PositionDataService.getAllPositions()
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle setting the applied filter */
    function handleAcceptedCheck() {
        if(document.getElementById("accheckbox").checked === true) {
            document.getElementById("fpcheckbox").checked = false;
            document.getElementById("opcheckbox").checked = false;
            document.getElementById("pacheckbox").checked = false;
            document.getElementById("recheckbox").checked = false;
            document.getElementById("decheckbox").checked = false;
            PositionDataService.getAllAppliedPositionsByStatus(currentUser.id, "accepted")
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        } else if(document.getElementById("accheckbox").checked === false) {
            PositionDataService.getAllPositions()
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle setting the applied filter */
    function handleRevokedCheck() {
        if(document.getElementById("recheckbox").checked === true) {
            document.getElementById("fpcheckbox").checked = false;
            document.getElementById("opcheckbox").checked = false;
            document.getElementById("accheckbox").checked = false;
            document.getElementById("pacheckbox").checked = false;
            document.getElementById("decheckbox").checked = false;
            PositionDataService.getAllAppliedPositionsByStatus(currentUser.id, "revoked")
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        } else if(document.getElementById("recheckbox").checked === false) {
            PositionDataService.getAllPositions()
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle setting the applied filter */
    function handleDeclinedCheck() {
        if(document.getElementById("decheckbox").checked === true) {
            document.getElementById("fpcheckbox").checked = false;
            document.getElementById("opcheckbox").checked = false;
            document.getElementById("accheckbox").checked = false;
            document.getElementById("recheckbox").checked = false;
            document.getElementById("pacheckbox").checked = false;
            PositionDataService.getAllAppliedPositionsByStatus(currentUser.id, "declined")
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        } else if(document.getElementById("decheckbox").checked === false) {
            PositionDataService.getAllPositions()
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle clear the filters */
    function handleClearFilters() {

        if(role === "STUDENT") {
            document.getElementById("fpcheckbox").checked = false;
            document.getElementById("opcheckbox").checked = false;
            document.getElementById("pacheckbox").checked = false;
            document.getElementById("accheckbox").checked = false;
            document.getElementById("recheckbox").checked = false;
            document.getElementById("decheckbox").checked = false;
        }

        document.getElementById("cscheckbox").checked = false;
        document.getElementById("echeckbox").checked = false;
        document.getElementById("ccheckbox").checked = false;
        document.getElementById("mcheckbox").checked = false;
        document.getElementById("ncheckbox").checked = false;
        document.getElementById("pcheckbox").checked = false;

        setCS(false);
        setEng(false);
        setChem(false);
        setMath(false);
        setNat(false);
        setPhy(false);
        setPos(true);

        PositionDataService.getAllPositions()
        .then(response => {
            setPositions(response.data);
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleSchoolFilters() {

        setSearch(false);
        document.getElementById("search").value = "";

        // Computer Science filters
        if(document.getElementById("cscheckbox").checked === true) {
            setPos(false);
            setCS(true);
        }
        else if(document.getElementById("cscheckbox").checked === false) {
            setCS(false);
        }

        // Engineering filters
        if(document.getElementById("echeckbox").checked === true) {
            setPos(false);
            setEng(true);
        }
        else if(document.getElementById("echeckbox").checked === false) {
            setEng(false);
        }

        // Chemistry filters
        if(document.getElementById("ccheckbox").checked === true) {
            setPos(false);
            setChem(true);
        }
        else if(document.getElementById("ccheckbox").checked === false) {
            setChem(false);
        }

        // Mathematics filters
        if(document.getElementById("mcheckbox").checked === true) {
            setPos(false);
            setMath(true);
        }
        else if(document.getElementById("mcheckbox").checked === false) {
            setMath(false);
        }

        // Natural Sci filters
        if(document.getElementById("ncheckbox").checked === true) {
            setPos(false);
            setNat(true);
        }
        else if(document.getElementById("ncheckbox").checked === false) {
            setNat(false);
        }

        // Physics filters
        if(document.getElementById("pcheckbox").checked === true) {
            setPos(false);
            setPhy(true);
        }
        else if(document.getElementById("pcheckbox").checked === false) {
            setPhy(false);
        }

        // Clear all filters
        if (document.getElementById("cscheckbox").checked === false &&
            document.getElementById("echeckbox").checked === false &&
            document.getElementById("ccheckbox").checked === false &&
            document.getElementById("mcheckbox").checked === false &&
            document.getElementById("ncheckbox").checked === false &&
            document.getElementById("pcheckbox").checked === false)
        {
            setPos(true);
            setCS(false);
            setEng(false);
            setChem(false);
            setMath(false);
            setNat(false);
            setPhy(false);
        }
    }

    /* Handle searching for positions */
    const [search, setSearch] = useState(false);
    const [searchTerm, setSearchTerm] = useState();
    function handleSearch() {
        if(document.getElementById("search").value === "") {
            setPos(true);
            setSearch(false);
        }
        else {
            setSearchTerm(document.getElementById("search").value);
            setSearch(true);
            setPos(false);
            setCS(false);
            setEng(false);
            setChem(false);
            setMath(false);
            setNat(false);
            setPhy(false);

            document.getElementById("cscheckbox").checked = false;
            document.getElementById("echeckbox").checked = false;
            document.getElementById("ccheckbox").checked = false;
            document.getElementById("mcheckbox").checked = false;
            document.getElementById("ncheckbox").checked = false;
            document.getElementById("pcheckbox").checked = false;
        }
    }

    /* Handle clearing the search bar */
    function handleClearSearch() {
        setSearch(false);
        setPos(true);
        document.getElementById("search").value = "";
    }


    return (
        <>
            <Navigation/>
            <div className="topBar"></div>

            <div className="positionsContainer">

                <div className="sideBar">
                    <div className="filters">
                        <h1 className="filterTitle">FILTER</h1>
                        <i className={ open ? "fas fa-times closeIcon" : "fas fa-chevron-circle-down closeIcon"} onClick={handleOpen}></i>
                    </div>
                    {role === "STUDENT" && (
                        <>
                            <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                                <input type="checkbox" className="checkbox" id="fpcheckbox" onChange={handleFavCheck}/>
                                <label htmlFor="checkbox"> Favourited Positions</label>
                            </p>
                            <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                                <input type="checkbox" className="checkbox" id="pacheckbox" onChange={handleApplCheck}/>
                                <label htmlFor="checkbox"> Positions Applied</label>
                            </p>
                            <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                                <input type="checkbox" className="checkbox" id="opcheckbox" onChange={handleOfferCheck}/>
                                <label htmlFor="checkbox"> Offered Positions</label>
                            </p>
                            <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                                <input type="checkbox" className="checkbox" id="accheckbox" onChange={handleAcceptedCheck}/>
                                <label htmlFor="checkbox"> Accepted Positions</label>
                            </p>
                            <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                                <input type="checkbox" className="checkbox" id="recheckbox" onChange={handleRevokedCheck}/>
                                <label htmlFor="checkbox"> Revoked Positions</label>
                            </p>
                            <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                                <input type="checkbox" className="checkbox" id="decheckbox" onChange={handleDeclinedCheck}/>
                                <label htmlFor="checkbox"> Declined Positions</label>
                            </p>
                            <h1 className={ open ? "filterTitle" : "filterTitle close"}>FILTER BY SCHOOL</h1>
                        </>
                    )}

                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="cscheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Computer Science</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="echeckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Engineering</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="ccheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Chemistry</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="mcheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Mathematics, Stat...</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="ncheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Natural Sciences</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="pcheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Physics</label>
                    </p>
                    <div className="filterBtns">
                        <button className={ open ? "filterBtn" : "filterBtn close"} onClick={handleClearFilters}>Clear filters</button>
                    </div>
                </div>

                <div className="positionsInfoContainer">
                    <div className="positionsInfoWrapper">

                        <div className="searchBar">
                            <h1 className="searchTitle">Search for a lab tutor position</h1>
                            <input type="text" className="searchBox" placeholder="Search by keyword" id="search" onChange={handleSearch}></input>
                            <button className="searchButton" onClick={handleClearSearch}>Clear Search</button> 
                        </div>

                        <div className="positions">
                            <h1 className="positionsTitle">Available Positions</h1>
                            <hr className="titleLine"/>
                            
                            {pos && positions &&
                            positions.map((position) => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                            {search &&
                            positions.filter(p => p.moduleTitle.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            p.moduleCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            p.description.toLowerCase().includes(searchTerm.toLowerCase())).map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                            {cs &&
                            positions.filter(p => p.school === "Computer Science").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                            {eng &&
                            positions.filter(p => p.school === "Engineering").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                            {chem &&
                            positions.filter(p => p.school === "Chemistry").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                            {math &&
                            positions.filter(p => p.school === "Mathematics, Statistics and Applied Mathematics").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                            {nat &&
                            positions.filter(p => p.school === "Natural Sciences").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                            {phy &&
                            positions.filter(p => p.school === "Physics").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                        role={role}
                                    />
                                </div>
                            ))}

                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default AllPositions;
