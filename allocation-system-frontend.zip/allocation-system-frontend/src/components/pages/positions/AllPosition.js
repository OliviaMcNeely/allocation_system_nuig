import React, {useState, useEffect} from 'react';
import {Link} from 'react-router-dom';
import './Positions.css';
import AuthService from '../../../services/auth.service';
import PositionLikesDataService from "../../../services/positionslikes.service";

function Position(props) {

    const currentUser = AuthService.getCurrentUser();
    const [favourite, setFavourited] = useState(false);

    /* When component mounts check to see check if the position is liked */
    useEffect(() => {

        if(currentUser.roles.includes("ROLE_STUDENT")) {
            PositionLikesDataService.checkLikePosition(currentUser.id, props.positionId)
            .then(response => {
                setFavourited(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }

    },[currentUser.id, currentUser.roles, props.positionId]);


    /* Handle when the student clicks the favourite button */
    function handleFavourited() {

        if(favourite) {
            PositionLikesDataService.unlikePosition(currentUser.id, props.positionId)
            .then(() => {
                setFavourited(false);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else {
            PositionLikesDataService.likePosition(currentUser.id, props.positionId)
            .then(() => {
                setFavourited(true);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle displaying the right amount of characters for description */
    const MAX_LENGTH = 200;
    const description = props.description;

    return (
        <>
            <div className="positionContainer">
                <Link 
                    to={{
                        pathname: `/position/details/`+props.positionId
                    }}
                    className="positionLink" 
                >
                    <div className="detailsContainer">
                        <p>{props.moduleCode}</p>
                        <p>{props.title}</p>
                        <p>Lecturer: {props.lecturer}</p>
                    </div>
                </Link>
                <div className="descriptionContainer">
                    {description.length > MAX_LENGTH ? (
                        <Link
                            to={{
                                pathname: `/position/details/`+props.positionId
                            }}
                            className="positionLink" 
                        >
                            <p>
                                {`${description.substring(0, MAX_LENGTH)}...`}
                            </p>
                        </Link>
                    ) : (
                        <Link
                            to={{
                                pathname: `/position/details/`+props.positionId
                            }}
                            className="positionLink"
                        >
                            <p>{description}</p>
                        </Link>
                    )}
                    {props.role === "STUDENT" && (
                        <>
                            <i className = { favourite ? "fas fa-heart heartIcon" : "far fa-heart heartIcon"} title="Favourite" onClick={handleFavourited}></i>
                        </>
                    )}
                </div>
                <hr className="underLine"/>
            </div>
        </>
    );
}

export default Position;
