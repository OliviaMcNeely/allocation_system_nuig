import React, {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import Application from './PositionApplication';
import PositionDataService from '../../../services/positions.service';
import ApplicationDataService from '../../../services/application.service';
import AuthService from '../../../services/auth.service';

function PositionApplications(props) {

    const positionId = props.match.params.id;
    const handle = props.match.params.handle;
    const [moduleCode, setModuleCode] = useState();
    const [moduleTitle, setModuleTitle] = useState();
    const [applications, setApplications] = useState([]);
    let history = useHistory();

    /* When the component mounts get the position info and the applications for the position */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user || !user.roles.includes("ROLE_LECTURER")) {
            AuthService.logout()
            history.push("/login");
        }

        PositionDataService.getPosition(positionId)
        .then(response => {
            setModuleCode(response.data.moduleCode);
            setModuleTitle(response.data.moduleTitle);
        })
        .catch(e => {
            console.log(e);
        });

        if(handle === "accepted") {
            ApplicationDataService.getPositionApplicationsByStatus(positionId, "accepted")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else if(handle === "offered") {
            ApplicationDataService.getPositionApplicationsByStatus(positionId, "offered")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else if(handle === "received") {
            ApplicationDataService.getPositionApplicationsByStatus(positionId, "revoked")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else if(handle === "declined") {
            ApplicationDataService.getPositionApplicationsByStatus(positionId, "declined")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }

    },[handle, history, positionId]);

    /* Function to open the accepted tab */
    function handleAcceptedOpen() {
        history.push("/position/applications/" + positionId + "/accepted");
    }

    /* Function to open the accepted tab */
    function handleOfferedOpen() {
        history.push("/position/applications/" + positionId + "/offered");
    }


    /* Function to open the received tab */
    function handleReceivedOpen() {
        history.push("/position/applications/" + positionId + "/received");
    }


    /* Function to open the revoked tab */
    function handleRevokedOpen() {
        history.push("/position/applications/" + positionId + "/revoked");
    }


    /* Function to open the declined tab */
    function handleDeclinedOpen() {
        history.push("/position/applications/" + positionId + "/declined");
    }


    return (
        <>
            <Navigation/>
            <div className="topBar"></div>
            <div className="appDetailsWrapper">
                <div className="appDetailsContainer">

                    <div className="appDetailsTitle">
                        <p className="aDetailsTitle">{moduleCode} - {moduleTitle} - Applications</p>
                    </div>
                    <p className="message">When the total number of accepted applications equals the required number of tutors, all other applications will automatically be declined!</p>

                    <div className="content_top">
                        <div className={handle === "accepted" ? "tab selected_tab info_tab" : "tab info_tab"} onClick={handleAcceptedOpen}>
                            <i className="fas fa-user-check"></i>
                            <p>ACCEPTED</p>
                        </div>
                        <div className={handle === "offered" ? "tab selected_tab" : "tab"} onClick={handleOfferedOpen}>
                            <i className="fas fa-user-check"></i>
                            <p>OFFERED</p>
                        </div>
                        <div className={handle === "received" ? "tab selected_tab" : "tab"} onClick={handleReceivedOpen}>
                            <i className="fas fa-file-signature"></i>
                            <p>RECEIVED</p>
                        </div>
                        <div className={handle === "revoked" ? "tab selected_tab" : "tab"} onClick={handleRevokedOpen}>
                            <i className="fas fa-file-excel"></i>
                            <p>REVOKED</p>
                        </div>
                        <div className={handle === "declined" ? "tab selected_tab grades_tab" : "tab grades_tab"} onClick={handleDeclinedOpen}>
                            <i className="far fa-file-excel"></i>
                            <p>DECLINED</p>
                        </div>
                    </div>

                    <div className="appDetailsAccepted">
                        <div className="section_header">
                            <p className="detailsSmallTitle">{handle} applications</p>
                        </div>
            
                        {applications ? (
                        applications.map((application, index) => (
                            <div key={index}>
                                <Application
                                    applicationId={application.applicationId}
                                    date={application.dateApplied}
                                    status={handle}
                                    positionId={positionId}
                                />
                            </div>
                        ))) : (
                            <>
                                <p className="notext">No applications</p>
                            </>
                        )}
                    </div>
                    
                </div>
            </div>
        </>
    )
}

export default PositionApplications;