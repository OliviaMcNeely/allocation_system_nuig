import React, {useEffect, useState} from 'react';
import {Link, useHistory} from 'react-router-dom';
import ApplicationDataService from '../../../services/application.service';

function PositionApplication(props) {

    const [studentInfo, setStudentInfo] = useState();
    let history = useHistory();

    /* When the component mounts get the student info for the application */
    useEffect(() => {

        ApplicationDataService.getApplicationStudent(props.applicationId)
        .then(response => {
            setStudentInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

    },[props.applicationId]);

    /* Handle accepting the application */
    function handleOffer() {

        ApplicationDataService.updateStatus(props.applicationId, "offered")
        .then(() => {
            history.push("/position/applications/"+props.positionId+"/offered");
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Handle declining the application */
    function handleDecline() {

        ApplicationDataService.updateStatus(props.applicationId, "declined")
        .then(() => {
            history.push("/position/applications/"+props.positionId+"/declined")
        })
        .catch(e => {
            console.log(e);
        });

    }

    return (
        <>
            <div className="appContainer">
                {studentInfo && (
                    <>
                        <div className="appStudentInfo">
                            <p className="boldText">{studentInfo.firstname} {studentInfo.surname}</p>
                            <p className="boldText">Application Date: {props.date}</p>
                            <Link to={{pathname: `/student/details/`+studentInfo.studentId}}>
                                <button className="appPBtn">View Profile</button>
                            </Link>
                        </div>
                        {props.status === "received" && (
                            <div>
                                <button className="appBtn" onClick={handleOffer}>Offer Position</button>
                                <button className="appBtn" onClick={handleDecline}>Decline Application</button>
                            </div>
                        )}
                    </>
                )}
            </div>
            <hr className="underLine"/>
            
        </>
    )
}

export default PositionApplication;
