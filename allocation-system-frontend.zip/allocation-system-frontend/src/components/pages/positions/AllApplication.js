import React, {useEffect, useState} from 'react';
import {Link, useHistory} from 'react-router-dom';
import ApplicationDataService from '../../../services/application.service';

function AllApplication(props) {

    const [studentInfo, setStudentInfo] = useState([]);
    const [positionInfo, setPositionInfo] = useState([]);
    let history = useHistory();

    /* When the component mounts get the student info and position info for the application */
    useEffect(() => {

        ApplicationDataService.getApplicationStudent(props.applicationId)
        .then(response => {
            setStudentInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        
        ApplicationDataService.getApplicationPosition(props.applicationId)
        .then(response => {
            setPositionInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

    },[props.applicationId]);

    /* Handle accepting the application */
    function handleOffer() {

        ApplicationDataService.updateStatus(props.applicationId, "offered")
        .then(() => {
            history.push("/all/applications/offered");
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Handle declining the application */
    function handleDecline() {

        ApplicationDataService.updateStatus(props.applicationId, "declined")
        .then(() => {
            history.push("/all/applications/declined");
        })
        .catch(e => {
            console.log(e);
        });

    }

    return (
        <>
            <div className="appContainer">
                {studentInfo && (
                    <>
                        <div>
                            <Link to={{pathname: `/position/details/`+positionInfo.positionId}}>
                                <p className="boldText text">{positionInfo.moduleCode} - {positionInfo.moduleTitle}</p>
                            </Link>
                        </div>
                        <div className="appStudentInfo">
                            <p className="boldText">{studentInfo.firstname} {studentInfo.surname}</p>
                            <p>Application Date: {props.date}</p>
                            <Link to={{pathname: `/student/details/`+studentInfo.studentId}}>
                                <button className="appPBtn">View Profile</button>
                            </Link>
                        </div>
                        {props.status === "received" && (
                            <div>
                                <button className="appBtn" onClick={handleOffer}>Offer Position</button>
                                <button className="appBtn" onClick={handleDecline}>Decline Application</button>
                            </div>
                        )}
                    </>
                )}
            </div>
            <hr className="underLine"/>
            
        </>
    )
}

export default AllApplication;