import React, {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import Application from './AllApplication';
import AuthService from '../../../services/auth.service';
import ApplicationDataService from '../../../services/application.service';

function AllApplications(props) {

    const [applications, setApplications] = useState([]);
    let history = useHistory();
    const handle = props.match.params.handle;

    /* When the component mounts get the position info and the applications for the position */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user.roles.includes("ROLE_LECTURER")) {
            AuthService.logout()
            history.push("/login");
        }

        if (handle === "accepted") {
            ApplicationDataService.getAllApplicationsByStatus(user.id, "accepted")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else if(handle === "offered") {
            ApplicationDataService.getAllApplicationsByStatus(user.id, "offered")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else if(handle === "received") {
            ApplicationDataService.getAllApplicationsByStatus(user.id, "received")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else if(handle === "revoked") {
            ApplicationDataService.getAllApplicationsByStatus(user.id, "revoked")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else if(handle === "declined") {
            ApplicationDataService.getAllApplicationsByStatus(user.id, "declined")
            .then(response => {
                setApplications(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }

    },[handle, history]);

    function handleAcceptedOpen() {
        history.push("/all/applications/accepted");
    }

    function handleOfferedOpen() {
        history.push("/all/applications/offered");
    }

    function handleReceivedOpen() {
        history.push("/all/applications/received");
    }

    function handleRevokedOpen() {
        history.push("/all/applications/revoked");
    }

    function handleDeclinedOpen() {
        history.push("/all/applications/declined");
    }


    return (
        <>
            <Navigation/>
            <div className="topBar"></div>
            <div className="appDetailsWrapper">
                <div className="appDetailsContainer">

                    <div className="appDetailsTitle">
                        <p className="aDetailsTitle">All Applications</p>
                    </div>

                    <div className="content_top">
                        <div className={handle === "accepted" ? "tab selected_tab info_tab" : "tab info_tab"} onClick={handleAcceptedOpen}>
                            <i className="fas fa-user-check"></i>
                            <p>ACCEPTED</p>
                        </div>
                        <div className={handle === "offered" ? "tab selected_tab" : "tab"} onClick={handleOfferedOpen}>
                            <i className="fas fa-user-check"></i>
                            <p>OFFERED</p>
                        </div>
                        <div className={handle === "received" ? "tab selected_tab" : "tab"} onClick={handleReceivedOpen}>
                            <i className="fas fa-file-signature"></i>
                            <p>RECEIVED</p>
                        </div>
                        <div className={handle === "revoked" ? "tab selected_tab" : "tab"} onClick={handleRevokedOpen}>
                            <i className="fas fa-file-excel"></i>
                            <p>REVOKED</p>
                        </div>
                        <div className={handle === "declined" ? "tab selected_tab grades_tab" : "tab grades_tab"} onClick={handleDeclinedOpen}>
                            <i className="far fa-file-excel"></i>
                            <p>DECLINED</p>
                        </div>
                    </div>

                    <div className="appDetailsAccepted">
                        <div className="section_header">
                            <p className="detailsSmallTitle">{handle} applications</p>
                        </div>
            
                        {applications ? (
                        applications.map((application, index) => (
                            <div key={index}>
                                <Application
                                    applicationId={application.applicationId}
                                    date={application.dateApplied}
                                    status={handle}
                                />
                            </div>
                        ))) : (
                            <>
                                <p className="notext">No applications {handle}</p>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </>
    )
}

export default AllApplications;