import React, {useState, useEffect} from 'react';
import {Link, useHistory} from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import Skill from './PositionDetailsSkill';
import AuthService from '../../../services/auth.service';
import PositionDataService from '../../../services/positions.service';
import SkillDataService from "../../../services/skills.service";
import PositionLikesDataService from '../../../services/positionslikes.service';
import ApplicationDataService from '../../../services/application.service';
import Form from 'react-validation/build/form';

function PositionDetails(props) {

    const currentUser = AuthService.getCurrentUser();
    const [role, setRole] = useState("NONE");
    const [positionId] = useState(props.match.params.id);
    const [charCount, setCharCount] = useState(0);

    const [description, setDescription] = useState();
    const [moduleCode, setModuleCode] = useState();
    const [moduleTitle, setModuleTitle] = useState();
    const [school, setSchool] = useState();
    const [totalHours, setTotalHours] = useState();
    const [assignmentCorrections, setAssignmentCorrections] = useState();
    const [assignmentCorrectionsString, setAssignmentCorrectionsString] = useState();
    const [numTutors, setNumTutors] = useState();
    const [graduateLevel, setGraduateLevel] = useState();
    const [semester, setSemester] = useState();
    const [location, setLocation] = useState();
    const [daytime, setDaytime] = useState();
    const [daytimes, setDaytimes] = useState();
    const [newDaytimes, setNewDaytimes] = useState();
    const [lecturerFirstname, setLecturerFirstname] = useState();
    const [lecturerSurname, setLecturerSurname] = useState();
    const [lecturerEmail, setLecturerEmail] = useState();

    const [skillsInfo, setSkillsInfo] = useState([]);
    const [favourite, setFavourited] = useState(false);
    const [applied, setApplied] = useState(false);
    const [application, setApplication] = useState([]);
    const [applicationStatus, setApplicationStatus] = useState("");
    let history = useHistory();

    /* When the component mounts check which role to display the right content.
    Then get position data, skills for the position. If the current user is a 
    student check if the position is favourited by the current user */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if (user) {
            if(user.roles.includes("ROLE_STUDENT")) {
                setRole("STUDENT");

                PositionLikesDataService.checkLikePosition(user.id, positionId)
                .then(response => {
                    setFavourited(response.data);
                })
                .catch(e => {
                    console.log(e);
                });

                ApplicationDataService.applicationExists(user.id, positionId)
                .then(response => {
                    setApplied(response.data);
                    if(response.data) {
                        ApplicationDataService.findApplication(user.id, positionId)
                        .then(response_ => {
                            setApplication(response_.data);
                            setApplicationStatus(response_.data.applicationStatus);
                        })
                        .catch(e => {
                            console.log(e);
                        });
                    }
                })
                .catch(e => {
                    console.log(e);
                });

            }
            else if(user.roles.includes("ROLE_LECTURER")) {

                PositionDataService.checkLecturerPosition(user.id, positionId)
                .then(response => {
                    if(response.data === true) {
                        setRole("LECTURER");
                    }
                    else {
                        setRole("VIEW");
                    }
                })
                .catch(e => {
                    console.log(e);
                });
            }
        }
        else {
            AuthService.logout()
            history.push("/login");
        }

        PositionDataService.getPosition(positionId)
        .then(response => {
            setModuleCode(response.data.moduleCode);
            setModuleTitle(response.data.moduleTitle);
            setSchool(response.data.school);
            setDescription(response.data.description);
            setCharCount(response.data.description.length);
            setTotalHours(response.data.hours);
            setAssignmentCorrections(response.data.assignmentCorrections);
            setGraduateLevel(response.data.graduateLevel);
            setSemester(response.data.semester);
            setLocation(response.data.location);
            setDaytime(response.data.daytime);
            
            var string = response.data.daytime;
            string = string.split(", ");
            var stringArray = [];
            for(var i =0; i < string.length; i++){
                stringArray.push(string[i]);
            }
            setDaytimes(stringArray);

            if(response.data.assignmentCorrections === true) {
                setAssignmentCorrectionsString("yes");
            }
            else {
                setAssignmentCorrectionsString("no")
            }
            setNumTutors(response.data.numTutors);
            setLecturerFirstname(response.data.responseLecturer.firstname);
            setLecturerSurname(response.data.responseLecturer.surname);
            setLecturerEmail(response.data.responseLecturer.email);
        })
        .catch(e => {
            console.log(e);
        });

        SkillDataService.getPositionSkills(positionId)
        .then(response => {
            setSkillsInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

    },[history, positionId]);


    /* Handle when the student clicks the favourite button */
    function handleFavourited() {

        if(favourite) {
            PositionLikesDataService.unlikePosition(currentUser.id, positionId)
            .then(() => {
                setFavourited(false);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else {
            PositionLikesDataService.likePosition(currentUser.id, positionId)
            .then(() => {
                setFavourited(true);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* handle editing the description */
    const [editDescription, setEditDescription] = useState(false);

    function handleEditDescription() {
        setEditDescription(true);
    }

    function handleDescriptionSave() {

        var des = document.getElementById("descriptionTextarea").value;

        PositionDataService.updatePositionDescription(positionId, des)
        .then(() => {
            setEditDescription(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
        
    }

    function handleDescriptionBack() {
        setEditDescription(false);
    }


    /* handle adding a skill */
    const [addSkill, setAddSkill] = useState(false);

    function handleAddSkill() {
        setAddSkill(true);
    }

    const [skill, setSkill] = useState();

    function handleSkillSave() {

        var data = {
            skill: skill
        };

        SkillDataService.createPositionSkill(positionId, data)
        .then(() => {
            setAddSkill(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleSkillBack() {
        setAddSkill(false);
    }


    /* handle editing the main details */
    const [editDetails, setEditDetails] = useState(false);

    function handleEditDetails() {
        setEditDetails(true);
    }

    function handleDetailsSave() {

        var day = "";
        if(newDaytimes !== undefined) {

            for (let i = 0; i < newDaytimes.length; i++) {
                if(i === newDaytimes.length-1) {
                    day += newDaytimes[i].attributes.value.nodeValue;
                }
                else {
                    day += newDaytimes[i].attributes.value.nodeValue + ", ";
                }
            }

            setDaytime(day);

            var string = day;
            string = string.split(", ");
            var stringArray = [];
            for(var j = 0; j < string.length; j++){
                stringArray.push(string[j]);
            }
            setDaytimes(stringArray);
        }
        else {
            day = daytime;
        }

        var data = {
            moduleCode: moduleCode,
            moduleTitle: moduleTitle,
            school: school,
            hours: totalHours,
            assignmentCorrections: assignmentCorrections,
            numTutors: numTutors,
            graduateLevel: graduateLevel,
            semester: semester,
            location: location,
            daytime: day
        };

        PositionDataService.updatePositionDetails(positionId, data)
        .then(() => {
            setEditDetails(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });

    }

    function handleDetailsBack() {
        setEditDetails(false);
    }


    /* Handle applying for the position */
    function applyPosition() {

        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();
        today = dd + '-' + mm + '-' + yyyy;

        let data = {
            dateApplied: today
        }

        ApplicationDataService.createApplication(currentUser.id, positionId, data)
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Handle revoking the position */
    function revokePosition() {

        ApplicationDataService.updateStatus(application.applicationId, "revoked")
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Handle reappling for the position */
    function reApplyPosition() {

        ApplicationDataService.updateStatus(application.applicationId, "received")
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* Handle accepting the position */
    function acceptPosition() {

        ApplicationDataService.updateStatus(application.applicationId, "accepted")
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    function countChar(e) {
        var currentText = e.target.value;
        setCharCount(currentText.length);
    }

    return (
        <>
            <Navigation/>
            <div className="topBar"></div>
            <div className="positionDetailsWrapper">
                <div className="positionDetailsContainer">

                    <div className="positionDetailsTitle">
                        <p className="detailsTitle">{moduleCode} - {moduleTitle}</p>
                        {role === "STUDENT" && (
                            <i 
                            className = { favourite ? "fas fa-heart heartIcon detailsIcon" : "far fa-heart heartIcon detailsIcon"} 
                            onClick={handleFavourited}
                            ></i>
                        )}
                    </div>
                    
                    <hr className="titleUnderLine"/>

                    <div className="positionDetailsDescription">
                        <div className="section_header">
                            <p className="detailsSmallTitle">Description</p>
                            {role === "LECTURER" && (
                                <i className="fas fa-pencil-alt edit_icon" onClick={handleEditDescription}></i>
                            )}
                        </div>
                        
                        {editDescription ? (
                            <Form onSubmit={handleDescriptionSave}>
                                <textarea 
                                    id="descriptionTextarea" 
                                    className="description_textarea" 
                                    rows="5"
                                    defaultValue={description}
                                    type="text"
                                    minLength="300"
                                    maxLength="10000"
                                    onKeyUp={countChar}
                                />
                                <div className="buttons">
                                    <button className="save_button" type="submit">Save</button>
                                    <button className="exit_button" onClick={handleDescriptionBack}>Back</button>
                                </div>
                                <p className="character_text" id="characters">
                                    {charCount} characters used
                                </p>
                            </Form>
                        ) : (
                            <p className="descriptionPara">{description}</p>
                        )}  
                    </div>
                    
                    <hr className="underLine"/>

                    <div className="positionDetailsSkills">
                        <div className="section_header">
                            <p className="detailsSmallTitle">Required Skills</p>
                            {role === "LECTURER" && (
                                <i className="fas fa-plus edit_icon" onClick={handleAddSkill}></i>
                            )}
                        </div>
                        <div className="positionSkills">
                            {skillsInfo &&
                            skillsInfo.map((s, index) => (
                                <div key={index} className="positionSkill">
                                    {role === "LECTURER" && (
                                        <Skill
                                            positionId={positionId}
                                            skillId={s.skillId}
                                            skill={s.skill}
                                        />
                                    )}
                                    {role === "STUDENT" && (
                                        <div className="skill">
                                            <p>{s.skill}</p>
                                        </div>
                                    )}
                                    {role === "VIEW" && (
                                        <div className="skill">
                                            <p>{s.skill}</p>
                                        </div>
                                    )}
                                    
                                </div>
                            ))}
                        </div>
                        {addSkill && (
                            <Form onSubmit={handleSkillSave}>
                                <input 
                                    type="text"                                                
                                    required 
                                    onChange={e => setSkill(e.target.value)}
                                    className="skill_input"
                                    placeholder="Skill"
                                />
                                <div className="skill_buttons">
                                    <button className="skill_save_button" type="submit">Save</button>
                                    <button className="skill_back_button" onClick={handleSkillBack}>Back</button>
                                </div>
                            </Form>
                        )}
                    </div>
                    
                    <hr className="underLine"/>

                    <div className="detailsMainContainer">
                        <div className="section_header">
                            <p className="detailsSmallTitle">Position Details</p>
                            {role === "LECTURER" && (
                                <i className="fas fa-pencil-alt edit_icon" onClick={handleEditDetails}></i>
                            )}
                        </div>

                        {editDetails ? (
                            <Form onSubmit={handleDetailsSave}>
                                <div className="inputContainer">
                                    <label className="inputLabel">School:</label>
                                    <select onChange={e => setSchool(e.target.value)} className="input" defaultValue={school}>
                                        <option value="Chemistry">Chemistry</option>
                                        <option value="Computer Science">Computer Science</option>
                                        <option value="Engineering">Engineering</option>
                                        <option value="Mathematics, Statistics and Applied Mathematics">Mathematics, Statistics and Applied Mathematics</option>
                                        <option value="Natural Sciences">Natural Sciences</option>
                                        <option value="Physics">Physics</option>
                                    </select>
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Semester:</label>
                                    <select required onChange={e => setSemester(e.target.value)} className="input">
                                        <option value="Semester 1">Semester 1</option>
                                        <option value="Semester 2">Semester 2</option>
                                        <option value="Both">Both</option>
                                    </select>
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Module code:</label>
                                    <input 
                                        type="text"
                                        required 
                                        onChange={e => setModuleCode(e.target.value)}
                                        className="input"
                                        defaultValue={moduleCode}
                                    />
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Module title:</label>
                                    <input 
                                        type="text"
                                        required 
                                        onChange={e => setModuleTitle(e.target.value)}
                                        className="input"
                                        defaultValue={moduleTitle}
                                    />
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Module level:</label>
                                    <select required onChange={e => setGraduateLevel(e.target.value)} className="input">
                                        <option value="Undergraduate">Undergraduate</option>
                                        <option value="Postgraduate">Postgraduate</option>
                                    </select>
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Location:</label>
                                    <select required onChange={e => setLocation(e.target.value)} className="input">
                                        <option value="Online">Online</option>
                                        <option value="In Person">In Person</option>
                                        <option value="Online and In Person">Online and In Person</option>
                                    </select>
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Total hours per tutor:</label>
                                    <input 
                                        type="number"
                                        required 
                                        onChange={e => setTotalHours(e.target.value)}
                                        className="input"
                                        defaultValue={totalHours}
                                    />
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Assignment corrections:</label>
                                    <select required onChange={e => setAssignmentCorrections(e.target.value)} className="input" defaultValue={assignmentCorrections}>
                                        <option value="true">Yes</option>
                                        <option value="false">No</option>
                                    </select>
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Number of Tutors:</label>
                                    <input 
                                        type="number"
                                        required 
                                        onChange={e => setNumTutors(e.target.value)}
                                        className="input"
                                        defaultValue={numTutors}
                                    />
                                </div>
                                <div className="inputContainer">
                                    <label className="inputLabel">Days and Times:</label>
                                    <select onChange={e => setNewDaytimes(e.target.selectedOptions)} defaultValue={daytimes} className="input" size="3" multiple>
                                        <option value="Undecided">Undecided</option>
                                        <option value="Monday 9am">Monday 9am</option>
                                        <option value="Monday 10am">Monday 10am</option>
                                        <option value="Monday 11am">Monday 11am</option>
                                        <option value="Monday 12pm">Monday 12am</option>
                                        <option value="Monday 1pm">Monday 1pm</option>
                                        <option value="Monday 2pm">Monday 2pm</option>
                                        <option value="Monday 3pm">Monday 3pm</option>
                                        <option value="Monday 4pm">Monday 4pm</option>
                                        <option value="Monday 5pm">Monday 5pm</option>
                                        <option value="Tuesday 9am">Tuesday 9am</option>
                                        <option value="Tuesday 10am">Tuesday 10am</option>
                                        <option value="Tuesday 11am">Tuesday 11am</option>
                                        <option value="Tuesday 12pm">Tuesday 12am</option>
                                        <option value="Tuesday 1pm">Tuesday 1pm</option>
                                        <option value="Tuesday 2pm">Tuesday 2pm</option>
                                        <option value="Tuesday 3pm">Tuesday 3pm</option>
                                        <option value="Tuesday 4pm">Tuesday 4pm</option>
                                        <option value="Tuesday 5pm">Tuesday 5pm</option>
                                        <option value="Wednesday 9am">Wednesday 9am</option>
                                        <option value="Wednesday 10am">Wednesday 10am</option>
                                        <option value="Wednesday 11am">Wednesday 11am</option>
                                        <option value="Wednesday 12pm">Wednesday 12am</option>
                                        <option value="Wednesday 1pm">Wednesday 1pm</option>
                                        <option value="Wednesday 2pm">Wednesday 2pm</option>
                                        <option value="Wednesday 3pm">Wednesday 3pm</option>
                                        <option value="Wednesday 4pm">Wednesday 4pm</option>
                                        <option value="Wednesday 5pm">Wednesday 5pm</option>
                                        <option value="Thursday 9am">Thursday 9am</option>
                                        <option value="Thursday 10am">Thursday 10am</option>
                                        <option value="Thursday 11am">Thursday 11am</option>
                                        <option value="Thursday 12pm">Thursday 12am</option>
                                        <option value="Thursday 1pm">Thursday 1pm</option>
                                        <option value="Thursday 2pm">Thursday 2pm</option>
                                        <option value="Thursday 3pm">Thursday 3pm</option>
                                        <option value="Thursday 4pm">Thursday 4pm</option>
                                        <option value="Thursday 5pm">Thursday 5pm</option>
                                        <option value="Friday 9am">Friday 9am</option>
                                        <option value="Friday 10am">Friday 10am</option>
                                        <option value="Friday 11am">Friday 11am</option>
                                        <option value="Friday 12pm">Friday 12am</option>
                                        <option value="Friday 1pm">Fridayy 1pm</option>
                                        <option value="Friday 2pm">Friday 2pm</option>
                                        <option value="Friday 3pm">Friday 3pm</option>
                                        <option value="Friday 4pm">Friday 4pm</option>
                                        <option value="Friday 5pm">Friday 5pm</option>
                                    </select>
                                </div>
                                <p className="labelnoteedit">*Press CTRL/CMD and select all that apply</p>
                                <div className="buttons">
                                    <button className="save_button" type="submit">Save</button>
                                    <button className="exit_button" onClick={handleDetailsBack}>Back</button>
                                </div>
                            </Form>
                        ) : (
                            <>
                                <div className="detailsItemContainer">
                                    <p className="detailTitle">School:</p>
                                    <p className="detailContent">{school}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Semester:</p>
                                    <p className="detailContent">{semester}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Module Code:</p>
                                    <p className="detailContent">{moduleCode}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Module title:</p>
                                    <p className="detailContent">{moduleTitle}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Module Level:</p>
                                    <p className="detailContent">{graduateLevel}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Location:</p>
                                    <p className="detailContent">{location}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Total hours:</p>
                                    <p className="detailContent">{totalHours}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Assignment Corrections:</p>
                                    <p className="detailContent">{assignmentCorrectionsString}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Number of Tutors:</p>
                                    <p className="detailContent">{numTutors}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Days and Times:</p>
                                    <p className="detailContent">{daytime}</p>
                                </div>
                            </>
                        )}
                        
                    </div>

                    {role === "STUDENT" && (
                        <>
                            <hr className="underLine"/>

                            <div className="detailsMainContainer">
                                <p className="detailsSmallTitle">Lecturer Details</p>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Name:</p>
                                    <p className="detailContent">{lecturerFirstname} {lecturerSurname}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Email:</p>
                                    <p className="detailContent">{lecturerEmail}</p>
                                </div>
                            </div>

                            <hr className="underLine"/>

                            {applied ? (
                                <>
                                    <p className="detailsSmallTitle">Application</p>
                                    <div className="detailsItemContainer">
                                        <p className="statusTitle">Status: </p>
                                        <p className="detailContent">{application.applicationStatus}</p>
                                    </div>
                                    {applicationStatus === "revoked" && (
                                        <button className="applyButton" onClick={reApplyPosition}>
                                            <p>Re-Apply</p>         
                                        </button>
                                    )}
                                    {applicationStatus === "received" && (
                                        <button className="applyButton" onClick={revokePosition}>
                                            <p>Revoke Application</p>
                                        </button>
                                    )}
                                    {applicationStatus === "offered" && (
                                        <button className="applyButton" onClick={acceptPosition}>
                                            <p>Accept Position</p>
                                        </button>
                                    )}
                                </>
                            ) : (
                                <>
                                    <button className="applyButton" onClick={applyPosition}>
                                        <div className="applyButtonItems">
                                            <i className="fas fa-file-signature applyIcon"></i>
                                            <p>Apply</p>
                                        </div>
                                    </button>
                                </>
                            )}
                            
                        </>
                    )}

                    {role === "LECTURER" && (
                        <>
                            <hr className="underLine"/>

                            <Link to={{pathname: `/position/applications/`+positionId+`/received`}}>
                                <button className="applyButton">View Applications</button>
                            </Link>
                            <Link to={{pathname: `/position/recommendations/`+positionId}}>
                                <button className="applyButton">Recommended Students</button>
                            </Link>
                        </>
                    )}

                    {role === "VIEW" && (
                        <>
                            <hr className="underLine"/>

                            <div className="detailsMainContainer">
                                <p className="detailsSmallTitle">Lecturer Details</p>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Name:</p>
                                    <p className="detailContent">{lecturerFirstname} {lecturerSurname}</p>
                                </div>

                                <div className="detailsItemContainer">
                                    <p className="detailTitle">Email:</p>
                                    <p className="detailContent">{lecturerEmail}</p>
                                </div>
                            </div>
                        </>
                    )}
                    
                </div>
            </div>
        </>
    )
}

export default PositionDetails;
