import React from 'react';
import {Link} from 'react-router-dom';
import './Home.css';

function MiniCard(props) {
    return (
        <>
            <div className={`mini_card ${props.name}`}>
                <Link className="mini_card_link" to={props.path}>
                    <i className={props.icon}></i>
                    <p>{props.text}</p>
                </Link>
            </div>
        </>
    )
}

export default MiniCard;