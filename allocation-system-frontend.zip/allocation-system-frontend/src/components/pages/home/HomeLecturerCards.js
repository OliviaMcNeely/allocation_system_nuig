import React, { useState, useEffect } from 'react';
import {Link, useHistory } from 'react-router-dom';
import './Home.css';
import CardBottom from './HomeCardBottom';
import CardPositionLine from './HomeCardPositionLine';
import CardMessageLine from './HomeCardMessageLine';
import MiniCard from './HomeMiniCard';
import AuthService from '../../../services/auth.service';
import LecturerDataService from '../../../services/lecturer.service';
import PositionDataService from '../../../services/positions.service';
import FileUploadDataService from "../../../services/fileupload.service";
import MessageDataService from '../../../services/message.service';

function Cards() {

    const currentUser = AuthService.getCurrentUser();
    const [lecturerInfo, setLecturerInfo] = useState([]);
    const [positions, setPositions] = useState([]);
    const [profilePicture, setProfilePicture] = useState();
    const [error, setError] = useState();
    const [uploadClick, setUploadClick] = useState(false);
    const [messages, setMessages] = useState([]);

    /* When component mounts get the lecturer data and 4 of the uploaded positions */
    useEffect(() => {

        PositionDataService.get4LecturerPositions(currentUser.id)
        .then(response => {
            setPositions(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        LecturerDataService.get(currentUser.id)
        .then(response => {
            setLecturerInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        MessageDataService.topFourReceivedMessages(currentUser.id)
        .then(response => {
            setMessages(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        FileUploadDataService.checkProfilePicture(currentUser.id)
        .then((r) => {
            if(r.data === false) {
                setProfilePicture(undefined);
            }
            else {
                FileUploadDataService.getProfilePicture(r.data)
                .then((response) => {
                    setProfilePicture(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[currentUser.id]);

    let history = useHistory();

    /* Function to signout of the application and clear the current user data */
    function signout() {
        AuthService.logout()
        history.push("/login");
    }

    /* Function to upload a new profile picture */
    function uploadPicture(event) {
        if(event.target.files === undefined) {
            console.log("No image selected");
        }
        else {
            let currentFile = event.target.files[0];
            console.log(currentFile);

            FileUploadDataService.uploadProfilePictureLecturer(currentUser.id, currentFile)
            .then(() => {
                setUploadClick(false);
                history.push("/home");
            })
            .catch(e => {
                console.log(e);
                setError("File too large: Limit 2MB")
            });
        }
    }

    function updateClick() {
        setUploadClick(true);
    }

    return (
        <>
            <div className="cards_container">
                <div className="cards_wrapper">
                    <div className="card_item">
                        <div className="card_bar">
                            <h2>
                                Welcome {lecturerInfo.firstname}
                            </h2>
                            <button className="btn" onClick={signout}>Sign Out</button>
                        </div>
                        <div className="card_content">
                            <div>
                            <div className="profile_image_container">
                                {profilePicture ? 
                                    <img className="profile_image" src={profilePicture.url} alt="profile" />
                                :
                                    <img src={"images/default_picture.jpg"} alt="profile" className="profile_image" />
                                }
                                </div>
                                <div className="profile_upload_button">
                                    {uploadClick ? 
                                        <input className="upload_button" type="file" accept="image/*" name="filename" onChange={uploadPicture}/>
                                    :
                                        <button className="upload_button" onClick={updateClick}>Upload Profile Picture</button>
                                    }
                                </div>
                                {error && (
                                    <p className="uploadError">{error}</p>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="card_item">
                        <div className="card_bar">
                            <h2>Uploaded Positions</h2>
                        </div>
                        <div>
                            {positions &&
                            positions.map((position, index) => (
                                <div className="position" key={position.positionId}>
                                    <CardPositionLine
                                        modulecode={position.moduleCode}
                                        title={position.moduleTitle}
                                        path={"/position/details/" + position.positionId}
                                        studentId={currentUser.id}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}
                        </div>
                        <div className="card_bottom">
                            <CardBottom
                                text="More"
                                path="/uploaded/positions"
                            />
                        </div>
                    </div>
                    <div className="card_item">
                        <div className="card_bar">
                            <h2>
                                <i className="fas fa-inbox mail_icon"></i>
                                Inbox
                            </h2>
                            <Link to="/new/message">
                                <button className="btn">New</button>
                            </Link>
                        </div>
                        <div>
                            {messages &&
                            messages.map((message) => (
                                <div className="message" key={message.messageId}>
                                    <CardMessageLine
                                        message={message.messageText}
                                        sender={message.rsender}
                                        path={"inbox/inbox/message/details/" + message.messageId}
                                        date={message.date}
                                        open={message.opened}
                                    />
                                </div>
                            ))}
                        </div>
                        <div className="card_bottom">
                            <CardBottom
                                text="More"
                                path="/inbox/inbox"
                            />
                        </div>
                    </div>
                    <div className="mini_cards_container">
                        <MiniCard
                            name="mini_one"
                            icon="fas fa-file-upload"
                            text="Upload New Position"
                            path="/upload/position"
                        />
                        <MiniCard
                            name="mini_one"
                            icon="fas fa-search"
                            text="Search Students"
                            path="/students"
                        />
                        <MiniCard
                            name="mini_one"
                            text="All Positions"
                            icon="fas fa-chalkboard-teacher"
                            path="/positions/all"
                        />
                        <MiniCard
                            name="mini_one"
                            text="All Applications"
                            icon="fas fa-file-signature"
                            path="/all/applications/received"
                        />
                    </div>
                </div>
            </div>
        </>
    );
}

export default Cards;