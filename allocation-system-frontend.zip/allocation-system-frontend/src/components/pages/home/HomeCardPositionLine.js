import React, {useState, useEffect} from 'react';
import {Link, useHistory} from 'react-router-dom';
import './Home.css';
import PositionLikesDataService from "../../../services/positionslikes.service";
import PositionDataService from '../../../services/positions.service';
import AuthService from '../../../services/auth.service';

function CardPositionLine(props) {

    const [role, setRole] = useState("NONE");
    let history = useHistory();

    /* When component mounts check to see if the student position displays and 
    check if the position is liked or the lecturer position line displays */
    useEffect(() => {

        const currentUser = AuthService.getCurrentUser();

        if (currentUser) {
            if(currentUser.roles.includes("ROLE_STUDENT")) {

                setRole("STUDENT");

                PositionLikesDataService.checkLikePosition(currentUser.id, props.positionId)
                .then(response => {
                    setFavourited(response.data);
                })
                .catch(e => {
                    console.log(e);
                });

            }
            else if(currentUser.roles.includes("ROLE_LECTURER")) {
                setRole("LECTURER");
            }
        }

    },[props.positionId]);
    
    const [options, setOptions] = useState(false);

    /* Display the options menu */
    const handleMouseOver = () => {
        setOptions(true);
    }

    /* Hide the options menu */
    const handleMouseLeave = () => {
        setOptions(false);
    }

    const [favourite, setFavourited] = useState(false);

    /* Handle when the student clicks the favourite button */
    function handleFavourited() {

        if(favourite) {
            PositionLikesDataService.unlikePosition(props.studentId, props.positionId)
            .then(() => {
                setFavourited(false);
            })
            .catch(e => {
                console.log(e);
            });
        }
        else {
            PositionLikesDataService.likePosition(props.studentId, props.positionId)
            .then(() => {
                setFavourited(true);
            })
            .catch(e => {
                console.log(e);
            });
        }
    }

    /* Handle deleting the position */
    function deletePosition() {
        PositionDataService.deletePosition(props.positionId)
        .then(() => {
            history.push("/home");
        })
        .catch(e => {
            console.log(e);
        });
    }

    var applylink = "/position/details/" + props.positionId;

    return (
        <>
            <div className="position_container">
                <Link className="position_link" to={props.path}>
                    <p>{props.modulecode}</p>
                </Link>
                <Link className="position_link" to={props.path}>
                    <p>{props.title}</p>
                </Link>
                <i className="fas fa-ellipsis-h options_icon" onMouseEnter={handleMouseOver} onMouseLeave={handleMouseLeave}></i>
            </div>

            {role === "STUDENT" && (
                <>
                    <div className={options ? "show_options" : "hide_options"} onMouseEnter={handleMouseOver} onMouseLeave={handleMouseLeave}>
                        <Link to={applylink} className="apply_link">
                            <i className="fas fa-file-signature" title="Apply"></i>
                        </Link>
                        <i className={favourite ? "fas fa-heart" : "far fa-heart"} onClick={handleFavourited} title="Favourite"></i>
                    </div>
                </>
            )}

            {role === "LECTURER" && (
                <>
                    <div className={options ? "show_options" : "hide_options"} onMouseEnter={handleMouseOver} onMouseLeave={handleMouseLeave}>
                        <Link to={"/position/details/"+props.positionId} className="apply_link">
                            <i className="far fa-edit" title="Edit"></i>
                        </Link>
                        <i className="far fa-trash-alt binIcon" onClick={deletePosition} title="Delete"></i>
                    </div>
                </>
            )}

            <div className="bottom_line_container">
                <hr className="bottom_line"/>
            </div>
        </>
    );
}

export default CardPositionLine;
