import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import StudentCards from './HomeStudentCards';
import LecturerCards from './HomeLecturerCards';
import AuthService from '../../../services/auth.service';

function Home() {

    const [role, setRole] = useState("NONE");
    let history = useHistory();

    /* When component mounts check the current user to display the correct home page */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if (user) {
            if(user.roles.includes("ROLE_STUDENT")) {
                setRole("STUDENT");
            }
            else if(user.roles.includes("ROLE_LECTURER")) {
                setRole("LECTURER");
            }
        }
        else {
            AuthService.logout()
            history.push("/login");
        }
        
    }, [history]);

    return (
        <>
            <Navigation/>
            <div className="topBar"></div>

            {role === "STUDENT" &&
                <StudentCards/>
            }

            {role === "LECTURER" &&
                <LecturerCards/>
            }

        </>
    );
}

export default Home;