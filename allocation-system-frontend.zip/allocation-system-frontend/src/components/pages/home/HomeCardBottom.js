import React from 'react';
import {Link} from 'react-router-dom';
import './Home.css';

function CardBottom(props) {
    return (
        <>
            <Link className="bottom_link" to={props.path}>
                <p>{props.text}</p>
                <i className="fas fa-chevron-right"></i>
            </Link>
        </>
    );
}

export default CardBottom;
