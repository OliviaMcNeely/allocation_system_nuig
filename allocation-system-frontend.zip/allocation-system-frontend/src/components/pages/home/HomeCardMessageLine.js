import React, {useState, useEffect} from 'react';
import {Link} from 'react-router-dom';
import './Home.css';
import FileUploadDataService from "../../../services/fileupload.service";

function CardMessageLine(props) {

    const [profilePicture, setProfilePicture] = useState();

    /* When the component mounts get the data */
    useEffect(() => {
        FileUploadDataService.checkProfilePicture(props.sender.userId)
        .then((r) => {
            if(r.data === false) {
                setProfilePicture(undefined);
            }
            else {
                FileUploadDataService.getProfilePicture(r.data)
                .then((response) => {
                    setProfilePicture(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[props.sender.userId]);

    /* Handle displaying the right amount of characters for message */
    const MAX_LENGTH = 30;

    const message = props.message;

    return (
        <>
            <div className="message_details">
                {profilePicture ? 
                    <img src={profilePicture.url} alt="profile" className="review_image" />
                    :
                    <img src={"images/default_picture.jpg"} alt="profile" className="review_image" />
                }
                <p className="message_date">{props.date}</p>
                <Link className="message_link" to={props.path}>
                    <p>{`${message.substring(0, MAX_LENGTH)}...`}</p>
                </Link>
            </div>
            <div className="bottom_line_container">
                <hr className="bottom_line"/>
            </div>
        </>
    );
}

export default CardMessageLine;
