import React, { useState, useEffect } from 'react';
import {Link, useHistory } from 'react-router-dom';
import './Home.css';
import CardBottom from './HomeCardBottom';
import CardPositionLine from './HomeCardPositionLine';
import CardMessageLine from './HomeCardMessageLine';
import MiniCard from './HomeMiniCard';
import AuthService from '../../../services/auth.service';
import StudentDataService from '../../../services/students.service';
import PositionDataService from '../../../services/positions.service';
import FileUploadDataService from "../../../services/fileupload.service";
import MessageDataService from '../../../services/message.service';

function Cards() {

    const currentUser = AuthService.getCurrentUser();
    const [profilePicture, setProfilePicture] = useState();
    const [studentInfo, setStudentInfo] = useState([]);
    const [positions, setPositions] = useState([]);
    const [error, setError] = useState();
    const [uploadClick, setUploadClick] = useState(false);
    const [messages, setMessages] = useState([]);

    /* When component mounts check get the 4 random positions and the student data */
    useEffect(() => {

        PositionDataService.get4RandomPositions()
        .then(response => {
            setPositions(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        StudentDataService.get(currentUser.id)
        .then(response => {
            setStudentInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        MessageDataService.topFourReceivedMessages(currentUser.id)
        .then(response => {
            setMessages(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        FileUploadDataService.checkProfilePicture(currentUser.id)
        .then((r) => {
            if(r.data === false) {
                setProfilePicture(undefined);
            }
            else {
                FileUploadDataService.getProfilePicture(r.data)
                .then((response) => {
                    setProfilePicture(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[currentUser.id]);

    let history = useHistory();

    /* Function to signout of the application and clear the current user data*/
    function signout() {
        AuthService.logout()
        history.push("/login");
    }

    /* Function to upload a new profile picture */
    function uploadPicture(event) {
        if(event.target.files === undefined) {
            console.log("No image selected");
        }
        else {
            let currentFile = event.target.files[0];
            console.log(currentFile);

            FileUploadDataService.uploadProfilePictureStudent(currentUser.id, currentFile)
            .then(() => {
                setUploadClick(false);
                history.push("/home");
            })
            .catch(e => {
                console.log(e);
                setError("File too large: Limit 2MB")
            });
        }
    }

    function updateClick() {
        setUploadClick(true);
    }

    return (
        <>
            <div className="cards_container">
                <div className="cards_wrapper">
                    <div className="card_item">
                        <div className="card_bar">
                            <h2>
                                Welcome {studentInfo.firstname}
                            </h2>
                            <button className="btn" onClick={signout}>Sign Out</button>
                        </div>
                        <div className="card_content">
                            <div>
                                <div className="profile_image_container">
                                    {profilePicture ? 
                                        <img className="profile_image" src={profilePicture.url} alt="profile" />
                                        :
                                        <img src={"images/default_picture.jpg"} alt="profile" className="profile_image" />
                                    }
                                </div>
                                <div className="profile_upload_button">
                                    {uploadClick ? 
                                        <input className="upload_button" type="file" accept="image/*" name="filename" onChange={uploadPicture}/>
                                    :
                                        <button className="upload_button" onClick={updateClick}>Upload Profile Picture</button>
                                    }
                                </div>
                                {error && (
                                    <p className="uploadError">{error}</p>
                                )}
                            </div>
                        </div>
                        <div className="card_bottom">
                            <div className="bottom_line_container">
                                <hr className="bottom_line"/>
                            </div>
                            <CardBottom
                                text="My Profile"
                                path="/student/profile/info"
                            />
                        </div>
                    </div>
                    <div className="card_item">
                        <div className="card_bar">
                            <h2>Available Positions</h2>
                        </div>
                        <div>
                            {positions &&
                            positions.map((position) => (
                                <div className="position" key={position.positionId}>
                                    <CardPositionLine
                                        modulecode={position.moduleCode}
                                        title={position.moduleTitle}
                                        path={"/position/details/" + position.positionId}
                                        studentId={currentUser.id}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}
                        </div>
                        <div className="card_bottom">
                            <CardBottom
                                text="More"
                                path="/positions/all"
                            />
                        </div>
                    </div>
                    <div className="card_item">
                        <div className="card_bar">
                            <h2>
                                <i className="fas fa-inbox mail_icon"></i>
                                Inbox
                            </h2>
                            <Link to="/new/message">
                                <button className="btn">New</button>
                            </Link>
                        </div>
                        <div>
                            {messages &&
                            messages.map((message) => (
                                <div className={message.opened ? "message" : "message messageNotOpen"} key={message.messageId}>
                                    <CardMessageLine
                                        message={message.messageText}
                                        sender={message.rsender}
                                        path={"inbox/inbox/message/details/" + message.messageId}
                                        date={message.date}
                                        open={message.opened}
                                    />
                                </div>
                            ))}
                        </div>
                        <div className="card_bottom">
                            <CardBottom
                                text="More"
                                path="/inbox/inbox"
                            />
                        </div>
                    </div>
                    <div className="mini_cards_container">
                        <MiniCard
                            name="mini_one"
                            icon="fas fa-file-contract"
                            text="My Offers"
                            path="/positions/offers"
                        />
                        <MiniCard
                            name="mini_one"
                            icon="fas fa-file-download"
                            text="Saved Positions"
                            path="/positions/likes"
                        />
                        <MiniCard
                            name="mini_one"
                            icon="fas fa-file-signature"
                            text="My Applications"
                            path="/positions/applications"
                        />
                        <MiniCard
                            name="mini_one"
                            icon="fas fa-thumbs-up"
                            text="My Reviews"
                            path="/student/profile/info"
                        />
                    </div>
                </div>
            </div>
        </>
    );
}

export default Cards;
