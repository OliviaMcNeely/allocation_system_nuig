import React from 'react';

function ReviewStar() {
    return (
        <>
            <i className="fas fa-star"></i>
        </>
    )
}

export default ReviewStar;
