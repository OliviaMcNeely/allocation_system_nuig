import React, {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import './StudentProfile.css';
import Navigation from '../navigation/Navigation';
import Review from './ProfileReview';
import ProfileResume from './ProfileResume';
import ProfileTimetable from './ProfileTimetable';
import ProfileGrades from './ProfileGrades';
import ExperienceItem from './ProfileExperienceItem';
import EducationItem from './ProfileEducationItem';
import SkillItem from './ProfileSkillItem';
import AuthService from "../../../services/auth.service";
import StudentDataService from "../../../services/students.service";
import ExperienceDataService from "../../../services/experience.service";
import EducationDataService from "../../../services/education.service";
import SkillDataService from "../../../services/skills.service";
import ReviewDataService from "../../../services/reviews.service";
import Form from 'react-validation/build/form';
import FileUploadDataService from "../../../services/fileupload.service";

function Profile(props) {

    const currentUser = AuthService.getCurrentUser();
    const [studentInfo, setStudentInfo] = useState([]);
    const [profilePicture, setProfilePicture] = useState();
    const [experienceInfo, setExperienceInfo] = useState([]);
    const [educationInfo, setEducationInfo] = useState([]);
    const [skillsInfo, setSkillsInfo] = useState([]);
    const [reviewsInfo, setReviewsInfo] = useState([]);
    let history = useHistory();

    /* When the component mounts get the student, experience, education and skills data */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user || !user.roles.includes("ROLE_STUDENT")) {
            AuthService.logout()
            history.push("/login");
        }

        const { handle } = props.match.params;

        if(handle === "info") {
            handleInfoOpen();
        }
        else if(handle === "timetable") {
            handleTimetableOpen();
        }
        else if(handle === "resume") {
            handleResumeOpen();
        }
        else if(handle === "grades") {
            handleGradesOpen();
        }

        setProfilePicture("/images/default_picture.jpg");

        StudentDataService.get(user.id)
        .then(response => {
            setStudentInfo(response.data);
            setCharCount(response.data.bio.length);
        })
        .catch(e => {
            console.log(e);
        });

        ExperienceDataService.getAllStudentExperience(user.id)
        .then(response => {
            setExperienceInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        EducationDataService.getAllStudentEducation(user.id)
        .then(response => {
            setEducationInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        SkillDataService.getStudentSkills(user.id)
        .then(response => {
            setSkillsInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        ReviewDataService.getAllStudentReviews(user.id)
        .then(response => {
            setReviewsInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        FileUploadDataService.checkProfilePicture(user.id)
        .then((r) => {
            if(r.data === false) {
                setProfilePicture(undefined);
            }
            else {
                FileUploadDataService.getProfilePicture(r.data)
                .then((response) => {
                    setProfilePicture(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[history, props.match.params]);


    const [currentMode, setCurrentMode] = useState();
    const [infoOpen, setInfoOpen] = useState(true);
    const [timetableOpen, setTimetableOpen] = useState(false);
    const [resumeOpen, setResumeOpen] = useState(false);
    const [gradesOpen, setGradesOpen] = useState(false);

    /* Function to open the info tab */
    function handleInfoOpen() {
        setInfoOpen(true)
        setTimetableOpen(false)
        setResumeOpen(false)
        setGradesOpen(false)
        setCurrentMode()
    }


    /* Function to open the timetable tab */
    function handleTimetableOpen() {
        setInfoOpen(false)
        setTimetableOpen(true)
        setResumeOpen(false)
        setGradesOpen(false)
        setCurrentMode('timetable')
    }


    /* Function to open the resume tab */
    function handleResumeOpen() {
        setInfoOpen(false)
        setTimetableOpen(false)
        setResumeOpen(true)
        setGradesOpen(false)
        setCurrentMode('resume')
    }


    /* Function to open the grades tab */
    function handleGradesOpen() {
        setInfoOpen(false)
        setTimetableOpen(false)
        setResumeOpen(false)
        setGradesOpen(true)
        setCurrentMode('grades')
    }


    /* Function to open the correct current tab */
    function getContent(current) {
        const content =  {
            timetable: <ProfileTimetable
                school={studentInfo.school}
            />,
            resume: <ProfileResume/>,
            grades: <ProfileGrades/>
        };

        return content[current];
    }


    /* handle opening and closing the delete dialog */
    const [open, setOpen] = useState(false);

    const handleOpenDialog = () => {
        setOpen(true);
    }

    const handleCloseDialog = () => {
        setOpen(false);
    }

    /* handle deleting profile */
    function handleDeleteProfile() {

        StudentDataService.delete(currentUser.id)
        .then(() => {
            AuthService.logout()
            history.push("/login");
        })
        .catch(e => {
            console.log(e);
        });
    }

    /* handle editing the name and course */
    const [editDetails, setEditDetails] = useState(false);

    function handleEditDetails() {
        setEditDetails(true);
    }

    function handleSaveDetails() {
        var firstname = document.getElementById("firstname").value;
        var surname = document.getElementById("surname").value;
        var course = document.getElementById("course").value;
        var level = document.getElementById("level").value;

        let data = {
            firstname: firstname,
            surname: surname,
            courseTitle : course,
            level: level
        }

        StudentDataService.updateStudentDetails(currentUser.id, data)
        .then(() => {
            setEditDetails(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }


    /* handle editing the about section */
    const [editAbout, setEditAbout] = useState(false);

    function handleEditAbout() {
        setEditAbout(true);
    }

    function handleAboutSave() {

        var bio = document.getElementById("aboutTextarea").value;

        StudentDataService.updateStudentBio(currentUser.id, bio)
        .then(() => {
            setEditAbout(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleAboutBack() {
        setEditAbout(false);
    }

    
    /* handle creating a new skill */
    const [newSkill, setNewSkill] = useState(false);

    function handleNewSkill() {
        setNewSkill(true);
    }

    const [skill, setSkill] = useState();

    function handleSkillSave() {

        var data = {
            skill: skill
        };

        SkillDataService.createStudentSkill(currentUser.id, data)
        .then(() => {
            setNewSkill(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleSkillBack() {
        setNewSkill(false);
    }


    /* handle creating a new experience item */
    const [newExperience, setNewExperience] = useState(false);

    function handleNewExperience() {
        setNewExperience(true);
    }

    const [company, setCompany] = useState();
    const [jobTitle, setJobTitle] = useState();
    const [description, setDescription] = useState();
    const [startDate, setStartDate] = useState();
    const [endDate, setEndDate] = useState();

    function handleExperienceSave() {

        const startDateF = startDate.substr(5, 2)+"/"+startDate.substr(0, 4);
        const endDateF = endDate.substr(5, 2)+"/"+endDate.substr(0, 4);

        var data = {
            jobTitle: jobTitle,
            company: company,
            description: description,
            startDate: startDateF,
            endDate: endDateF
        };

        ExperienceDataService.createExperience(currentUser.id, data)
        .then(() => {
            setNewExperience(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleExperienceBack() {
        setNewExperience(false);
    }


    /* handle creating a new education item */
    const [newEducation, setNewEducation] = useState(false);

    function handleNewEducation() {
        setNewEducation(true);
    }

    const [school, setSchool] = useState();
    const [courseTitle, setCourseTitle] = useState();
    const [startYear, setStartYear] = useState();
    const [endYear, setEndYear] = useState();

    function handleEducationSave() {

        const startYearF = startYear.substr(5, 2)+"/"+startYear.substr(0, 4);
        const endYearF = endYear.substr(5, 2)+"/"+endYear.substr(0, 4);

        var data = {
            schoolName: school,
            courseTitle: courseTitle,
            startYear: startYearF,
            endYear: endYearF
        };

        EducationDataService.createEducation(currentUser.id, data)
        .then(() => {
            setNewEducation(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleEducationBack() {
        setNewEducation(false);
    }

    const [charCount, setCharCount] = useState(0);

    function countChar(e) {
        var currentText = e.target.value;
        setCharCount(currentText.length);
    }
    
    return (
        <>
            <Navigation />
            <div className="top_bar">
                <div className="profile_picture">
                    {profilePicture ? 
                        <img src={profilePicture.url} alt="profile" />
                        :
                        <img src={"images/default_picture.jpg"} alt="profile" />
                    }
                </div>
                <div className="profile_info">
                    <div className="profile_title">
                        {editDetails ? (
                            <Form onSubmit={handleSaveDetails}>
                                <div className="name_inputs">
                                    <input 
                                        type="text" 
                                        className="firstname_edit_input" 
                                        placeholder="Firstname" 
                                        required 
                                        id="firstname"
                                        defaultValue={studentInfo.firstname}
                                    />
                                    <input 
                                        type="text" 
                                        className="surname_edit_input" 
                                        placeholder="Surname" 
                                        required 
                                        id="surname"
                                        defaultValue={studentInfo.surname}
                                    />
                                </div>
                                <div className="name_inputs">
                                    <select required className="schoolInput" defaultValue={studentInfo.level} id="level">
                                        <option value="PostGraduate Masters">PostGraduate Masters</option>
                                        <option value="PostGrdauate PHD">PostGrdauate PHD</option>
                                        <option value="UnderGraduate">UnderGraduate</option>
                                    </select>
                                </div>
                                <div className="name_inputs">
                                    <input 
                                        type="text" 
                                        className="course_edit_input" 
                                        placeholder="Course" 
                                        required 
                                        id="course"
                                        defaultValue={studentInfo.courseTitle}
                                    />
                                    <button className="details_edit_button" type="submit">Save</button>
                                </div>
                            </Form>
                        ) : (
                            <>
                                <h1>{studentInfo.firstname} {studentInfo.surname}</h1>
                                <p>{studentInfo.level}</p>
                                <div className="nameIconContainer">
                                    <p>{studentInfo.courseTitle}</p>
                                    <i className="fas fa-pencil-alt edit_name_icon" onClick={handleEditDetails}></i>
                                </div>
                            </>
                        )}
                        
                    </div>
                    <div className="delete_button">
                        <button onClick={handleOpenDialog}>Delete Profile</button>
                    </div>
                    <div className={open ? "dialog_open" : "dialog_close"}>
                        <p>Are you sure?</p>
                        <button className="ok_button" onClick={handleDeleteProfile}>OK</button>
                        <button className="cancel_button" onClick={handleCloseDialog}>Cancel</button>
                    </div>
                </div>
            </div>

            <div className="profile_container">
                <div className="side_bar">
                    <div className="review_title">
                        <i className="far fa-star"></i>
                        <p>REVIEWS</p>
                    </div>
                    <div className="reviews">
                        {reviewsInfo &&
                        reviewsInfo.map((review, index) => (
                            <div key={index}>
                                <Review
                                    lecturer={review.responseLecturer.lecturerId}
                                    review={review.reviewDescription}
                                    rating={review.rating}
                                />
                            </div>
                        ))}
                    </div>
                </div>

                <div className="main_area">
                    <div className="main_area_content">
                        <div className="content_top">
                            <div className={infoOpen ? "tab selected_tab info_tab" : "tab info_tab"} onClick={handleInfoOpen}>
                                <i className="fas fa-info-circle"></i>
                                <p>INFO</p>
                            </div>
                            <div className={timetableOpen ? "tab selected_tab" : "tab"} onClick={handleTimetableOpen}>
                                <i className="fas fa-calendar-alt"></i>
                                <p>TIMETABLE</p>
                            </div>
                            <div className={resumeOpen ? "tab selected_tab" : "tab"} onClick={handleResumeOpen}>
                                <i className="fas fa-file"></i>
                                <p>RESUME</p>
                            </div>
                            <div className={gradesOpen ? "tab selected_tab grades_tab" : "tab grades_tab"} onClick={handleGradesOpen}>
                                <i className="fas fa-poll-h"></i>
                                <p>GRADES</p>
                            </div>
                        </div>
                        
                        {infoOpen && (
                            <>
                                <div>
                                    <div className="section_header">
                                        <p>About</p>
                                        <i className="fas fa-pencil-alt edit_about_icon" onClick={handleEditAbout}></i>
                                    </div>
                                    {editAbout ? (
                                        <>
                                            <Form onSubmit={handleAboutSave}>
                                                <p className="descriptionNote">The more detail given here the higher your chance of getting recommended for a position. Minimum character count 300.</p>
                                                <textarea 
                                                    id="aboutTextarea" 
                                                    className="about_textarea" 
                                                    rows="5"
                                                    defaultValue={studentInfo.bio}
                                                    minLength="300"
                                                    maxLength="10000"
                                                    onKeyUp={countChar}
                                                />
                                                <div className="buttons">
                                                    <button type="submit" className="save_button">Save</button>
                                                    <button type="button" className="exit_button" onClick={handleAboutBack}>Back</button>
                                                </div>
                                                <p className="character_text" id="characters">
                                                    {charCount} characters used
                                                </p>
                                            </Form>
                                        </>
                                    ) : (
                                        <p className="about_para">
                                            {studentInfo.bio}
                                        </p>
                                    )}
                                    <hr className="section_break" />
                                </div>

                                <div className="skills_section">
                                    <div className="section_header">
                                        <p>Skills</p>
                                        <i className="fas fa-plus edit_about_icon" onClick={handleNewSkill}></i>
                                    </div>
                                    <div className="skills_items">
                                        {skillsInfo &&
                                        skillsInfo.map((s, index) => (
                                            <div key={s.skillId} className="skill_item">
                                                <SkillItem
                                                    studentId={currentUser.id}
                                                    skillId={s.skillId}
                                                    skill={s.skill}
                                                />
                                            </div>
                                        ))}
                                    </div>
                                    {newSkill && (
                                        <>
                                            <input 
                                                type="text"                                                
                                                required 
                                                onChange={e => setSkill(e.target.value)}
                                                className="skill_input"
                                                placeholder="Skill"
                                            />
                                            <div className="skill_buttons">
                                                <button className="skill_save_button" onClick={handleSkillSave}>Save</button>
                                                <button className="skill_back_button" onClick={handleSkillBack}>Back</button>
                                            </div>
                                        </>
                                    )}
                                    <hr className="section_break"/>
                                </div>

                                <div className="experience_section">
                                    <div className="section_header">
                                        <p>Experience</p>
                                        <i className="fas fa-plus edit_about_icon" onClick={handleNewExperience}></i>
                                    </div>
                                    <div className="experience_items">
                                        {experienceInfo &&
                                        experienceInfo.map((ex, index) => (
                                            <div key={ex.experienceId}>
                                                <ExperienceItem
                                                    company={ex.company}
                                                    jobTitle={ex.jobTitle}
                                                    description={ex.description}
                                                    startDate={ex.startDate}
                                                    endDate={ex.endDate}
                                                    experienceId={ex.experienceId}
                                                />
                                                {index+1 === experienceInfo.length ? 
                                                    <div></div> : 
                                                    <hr className="section_break"/>
                                                }
                                            </div>
                                        ))}
                                    </div>
                                    {newExperience && (
                                        <>
                                            <hr className="section_break" />
                                            <div className="new_experience_item">
                                                <Form onSubmit={handleExperienceSave}>
                                                    <div className="company_job_inputs">
                                                        <input 
                                                            type="text" 
                                                            required 
                                                            onChange={e => setCompany(e.target.value)}
                                                            className="company_input"
                                                            placeholder="Company"
                                                        />
                                                        <input 
                                                            type="text"                                                
                                                            required 
                                                            onChange={e => setJobTitle(e.target.value)}
                                                            className="job_input"
                                                            placeholder="Job Title"
                                                        />
                                                    </div>
                                                    <textarea  
                                                        rows="4"
                                                        required
                                                        onChange={e => setDescription(e.target.value)}
                                                        className="description_input"
                                                        placeholder="Decription"
                                                    />
                                                    <div className="date_inputs">
                                                        <input 
                                                            type="date"
                                                            pattern="[0-9]{4}/[0-9]{2}"
                                                            placeholder="2020/12"
                                                            min="1950-01"
                                                            max="2050-12"
                                                            className="startdate_input"
                                                            onChange={e => setStartDate(e.target.value)}
                                                            required
                                                        />
                                                        <input 
                                                            type="date"
                                                            pattern="[0-9]{4}/[0-9]{2}"
                                                            placeholder="2020/12"
                                                            min="1950-01"
                                                            max="2050-12"
                                                            className="enddate_input"
                                                            onChange={e => setEndDate(e.target.value)}
                                                            required
                                                        />
                                                    </div>
                                                    <div className="experience_buttons">
                                                        <button type="submit" className="s_button">Save</button>
                                                        <button type="button" className="e_button" onClick={handleExperienceBack}>Back</button>
                                                    </div>
                                                </Form>
                                            </div>
                                        </>
                                    )}
                                    <hr className="section_break" />
                                </div>

                                <div className="education_section">
                                    <div className="section_header">
                                        <p>Education</p>
                                        <i className="fas fa-plus edit_about_icon" onClick={handleNewEducation}></i>
                                    </div>
                                    <div className="education_items">
                                        {educationInfo &&
                                        educationInfo.map((ex, index) => (
                                            <div key={ex.educationId}>
                                                <EducationItem
                                                    school={ex.schoolName}
                                                    course={ex.courseTitle}
                                                    startYear={ex.startYear}
                                                    endYear={ex.endYear}
                                                    educationId={ex.educationId}
                                                />
                                                {index+1 === educationInfo.length ? 
                                                    <div></div> : 
                                                    <hr className="section_break"/>
                                                }
                                            </div>
                                        ))}
                                    </div>
                                    {newEducation && (
                                        <>
                                            <hr className="section_break" />
                                            <div className="new_education_item">
                                                <Form onSubmit={handleEducationSave}>
                                                    <div className="school_course_inputs">
                                                        <input 
                                                            type="text" 
                                                            required 
                                                            onChange={e => setSchool(e.target.value)}
                                                            className="school_input"
                                                            placeholder="School"
                                                        />
                                                        <input 
                                                            type="text"                                                
                                                            required 
                                                            onChange={e => setCourseTitle(e.target.value)}
                                                            className="course_input"
                                                            placeholder="Course Title"
                                                        />
                                                    </div>
                                                    <div className="year_inputs">
                                                        <input 
                                                            type="date"
                                                            pattern="[0-9]{4}/[0-9]{2}"
                                                            placeholder="2020/12"
                                                            min="1950-01"
                                                            max="2050-12"
                                                            required
                                                            className="startdate_input"
                                                            onChange={e => setStartYear(e.target.value)}
                                                        />
                                                        <input 
                                                            type="date"
                                                            pattern="[0-9]{4}/[0-9]{2}"
                                                            placeholder="2020/12"
                                                            min="1950-01"
                                                            max="2050-12"
                                                            required
                                                            className="enddate_input"
                                                            onChange={e => setEndYear(e.target.value)}
                                                        />
                                                    </div>
                                                    <div className="education_buttons">
                                                        <button type="submit" className="s_button">Save</button>
                                                        <button type="button" className="e_button" onClick={handleEducationBack}>Back</button>
                                                    </div>
                                                </Form>
                                            </div>
                                        </>
                                    )}
                                </div>

                            </>
                        )}

                        {getContent(currentMode)}

                    </div>
                </div>
            </div>
        </>
    );
}

export default Profile;