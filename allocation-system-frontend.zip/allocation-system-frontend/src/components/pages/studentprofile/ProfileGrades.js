import React, {useState, useEffect} from 'react';
import {useHistory } from 'react-router-dom';
import AuthService from "../../../services/auth.service";
import FileUploadDataService from "../../../services/fileupload.service";
import StudentDataService from "../../../services/students.service";
import {Document, Page, pdfjs} from 'react-pdf';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

function ProfileTimetable(props) {

    const currentUser = AuthService.getCurrentUser();
    const [student, setStudent] = useState(false);
    const [selectedFiles, setSelectedFiles] = useState(undefined);
    const [currentGrades, setCurrentGrades] = useState(undefined);
    const [error, setError] = useState();

    /* When the component mounts get grades report */
    useEffect(() => {

        let id;

        if(currentUser.roles.includes("ROLE_STUDENT")) {
            setStudent(true);
            id = currentUser.id;
        }
        else if(currentUser.roles.includes("ROLE_LECTURER")) {
            setStudent(false);
            id = props.studentId;
        }

        StudentDataService.checkGrades(id)
        .then((r) => {
            if(r.data === false) {
                setCurrentGrades(undefined);
            }
            else {
                FileUploadDataService.getGrades(r.data)
                .then((response) => {
                    setCurrentGrades(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[currentUser.id, currentUser.roles, props.studentId]);

    function selectFile(event) {
        setSelectedFiles(event.target.files);
    }

    let history = useHistory();

    /* handle uploading a new grades report */
    function handleUploadGrades() {

        if(selectedFiles === undefined) {
            console.log("No file selected");
        }
        else {
            let currentFile = selectedFiles[0];

            FileUploadDataService.uploadGrades(currentUser.id, currentFile)
            .then(() => {
                history.push("/student/profile/grades");
            })
            .catch(e => {
                console.log(e);
                setError("File too large: Limit 2MB")
            });
        }
    }

    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(1);

    function onDocumentLoadSuccess({numPages}) {
        setNumPages(numPages);
        setPageNumber(1);
    }

    function changePage(offset) {
        setPageNumber(prevPageNumber => prevPageNumber + offset);
    }
    
    function previousPage() {
        changePage(-1);
    }
    
    function nextPage() {
        changePage(1);
    }

    const options = {
        cMapUrl: 'cmaps/',
        cMapPacked: true,
        verbosity: 0,
    };

    return (
        <>
            <div className="resume_container">
                {student && (
                    <>
                        <div className="resume_upload_section">
                            <div className="resume_header">
                                <p>Upload Grades as PDF</p>
                            </div>
                            <div>
                                <input type="file" accept="application/pdf" name="filename" onChange={selectFile}/>
                            </div>
                            {error && (
                                <p className="uploadError">{error}</p>
                            )}
                            <button className="add_resume_btn" onClick={handleUploadGrades}>
                                <i className="fas fa-plus-circle add_icon"></i>
                                Upload Grades
                            </button>
                        </div>
                        <hr className="section_break"/>
                    </>
                )}
                <div className="resume_section">
                    <div className="resume_header">
                        <p>Grades Report</p>
                    </div>
                    {currentGrades ? (
                        <div className="resume_pdf_container">
                            <Document
                                file={currentGrades.url}
                                options={options}
                                onLoadSuccess={onDocumentLoadSuccess}
                            >
                                <Page className="pdf_page" pageNumber={pageNumber}/>
                            </Document>
                            <div className="resume_pdf_buttons">
                                <p>Page {pageNumber || (numPages ? 1 : "--")} of {numPages || "--"}</p>
                                <button className="pdf_btn" type="button" disabled={pageNumber <= 1} onClick={previousPage}>
                                    Previous
                                </button>
                                <button className="pdf_btn" type="button" disabled={pageNumber >= numPages} onClick={nextPage}>
                                    Next
                                </button>
                            </div>
                        </div>
                    ) : (
                        <p>No grade report uploaded</p>
                    )}
                </div>
            </div>
        </>
    );
}

export default ProfileTimetable;