import React, {useState, useEffect} from 'react';
import './StudentProfile.css';
import ReviewStar from './ReviewStar';
import FileUploadDataService from "../../../services/fileupload.service";

function Review(props) {

    const [rating] = useState(props.rating);
    const [profilePicture, setProfilePicture] = useState();

    /* When the component mounts get the student, experience, education and skills data */
    useEffect(() => {
        FileUploadDataService.checkProfilePicture(props.lecturer)
        .then((r) => {
            if(r.data === false) {
                setProfilePicture(undefined);
            }
            else {
                FileUploadDataService.getProfilePicture(r.data)
                .then((response) => {
                    setProfilePicture(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[props.lecturer]);

    return (
        <>
            <div className="review_item">
                <div className="review_image_container">
                    {profilePicture ? 
                        <img src={profilePicture.url} alt="profile" className="review_image" />
                        :
                        <img src={"images/default_picture.jpg"} alt="profile" className="review_image" />
                    }
                </div>
                <div className="review_details_container">
                    <p>{props.review}</p>
                    <div className="stars">
                        {rating && 
                        [...Array(rating)].map((star, index) => (
                            <div key={index}>
                                <ReviewStar/>
                            </div>
                        ))}
                    </div>
                </div>
                <hr className="section_break"/>
            </div>
        </>
    );
}

export default Review;
