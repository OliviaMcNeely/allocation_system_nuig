import React, {useState} from 'react';
import EducationDataService from "../../../services/education.service";
import Form from 'react-validation/build/form';

function EducationItem(props) {

    const [school, setSchool] = useState(props.school);
    const [courseTitle, setCourseTitle] = useState(props.course);
    const [startYear, setStartYear] = useState(props.startYear.substr(3, 4)+"-"+props.startYear.substr(0, 2));
    const [endYear, setEndYear] = useState(props.endYear.substr(3, 4)+"-"+props.endYear.substr(0, 2));

    /* handle editing the education item */
    const [editEducation, setEditEducation] = useState(false);

    function handleEditEducation() {
        setEditEducation(true);
    }

    function handleEducationSave() {

        const startDateF = startYear.substr(5, 2)+"/"+startYear.substr(0, 4);
        const endDateF = endYear.substr(5, 2)+"/"+endYear.substr(0, 4);

        var data = {
            schoolName: school,
            courseTitle: courseTitle,
            startYear: startDateF,
            endYear: endDateF
        };

        EducationDataService.updateEducation(props.educationId, data)
        .then(() => {
            setEditEducation(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }
    
    function handleEducationBack() {
        setSchool(props.school);
        setCourseTitle(props.course);
        setStartYear(props.startYear.substr(3, 4)+"-"+props.startYear.substr(0, 2));
        setEndYear(props.endYear.substr(3, 4)+"-"+props.endYear.substr(0, 2));
        setEditEducation(false);
    }


    /* handle deleting the education item */
    function handleDeleteEducation() {

        EducationDataService.deleteEducation(props.educationId)
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });

    }

    return (
        <>
            {editEducation ? (
                <>
                    <Form onSubmit={handleEducationSave}>
                        <div className="new_education_item">
                            <div className="school_course_inputs">
                                <input 
                                    type="text" 
                                    required 
                                    onChange={e => setSchool(e.target.value)}
                                    className="school_input"
                                    defaultValue={school} 
                                />
                                <input 
                                    type="text"                                                
                                    required 
                                    onChange={e => setCourseTitle(e.target.value)}
                                    className="course_input"
                                    placeholder="Course Title"
                                    defaultValue={courseTitle} 
                                />
                            </div>
                            <div className="year_inputs">
                                <input 
                                    type="month"
                                    className="startdate_input"
                                    onChange={e => setStartYear(e.target.value)}
                                    defaultValue={startYear} 
                                />
                                <input 
                                    type="month"
                                    className="enddate_input"
                                    onChange={e => setEndYear(e.target.value)}
                                    defaultValue={endYear} 
                                />
                            </div>
                            <div className="education_buttons">
                                <button type="submit" className="s_button">Save</button>
                                <button type="button" className="e_button" onClick={handleEducationBack}>Back</button>
                            </div>
                        </div>
                    </Form>
                </>
            ) : (
                <>
                    <div className="education_item">
                        <p className="item_title">{props.school}</p>
                        <p>{props.course}</p>
                        <p className="item_year">{props.startYear} - {props.endYear}</p>
                    </div>
                    <div className="edit_delete_icons">
                        <i className="fas fa-pencil-alt experience_icon" onClick={handleEditEducation}></i>
                        <i className="far fa-trash-alt experience_icon" onClick={handleDeleteEducation}></i>
                    </div>
                </>
            )}
        </>
    );
}

export default EducationItem;
