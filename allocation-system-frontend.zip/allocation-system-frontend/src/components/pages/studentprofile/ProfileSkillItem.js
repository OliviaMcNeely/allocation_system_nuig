import React from 'react';
import SkillDataService from "../../../services/skills.service";

function ProfileSkillItem(props) {

    /* handle deleting a skill item */
    function deleteSkill() {
        SkillDataService.removeStudentSkill(props.studentId, props.skillId)
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    return (
        <>
            <div className="skill">
                <p>{props.skill}</p>
                <div className="skill_icon_container">
                    <i className="far fa-times-circle skill_icon" onClick={deleteSkill}></i>
                </div>
            </div>
        </>
    )
}

export default ProfileSkillItem;
