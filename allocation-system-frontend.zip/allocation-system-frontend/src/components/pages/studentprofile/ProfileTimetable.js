import React, {useState, useEffect} from 'react';
import {useHistory } from 'react-router-dom';
import AuthService from "../../../services/auth.service";
import FileUploadDataService from "../../../services/fileupload.service";
import StudentDataService from "../../../services/students.service";
import {Document, Page, pdfjs} from 'react-pdf';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

function ProfileTimetable(props) {

    const currentUser = AuthService.getCurrentUser();
    const [selectedFiles, setSelectedFiles] = useState(undefined);
    const [currentTimetable, setCurrentTimetable] = useState(undefined);
    const [error, setError] = useState();
    const [timetableLink, setTimetableLink] = useState();

    /* When the component mounts get timetable */
    useEffect(() => {

        StudentDataService.checkTimetable(currentUser.id)
        .then((r) => {
            if(r.data === false) {
                setCurrentTimetable(undefined);
            }
            else {
                FileUploadDataService.getTimetable(r.data)
                .then((response) => {
                    setCurrentTimetable(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

        if(props.school === "Computer Science") {
            setTimetableLink("http://www.nuigalway.ie/science-engineering/school-of-computer-science/currentstudents/timetables/");
        }
        else if(props.school === "Chemistry") {
            setTimetableLink("https://www.nuigalway.ie/science-engineering/school-of-chemistry/student-information/studenttimetables/");
        }
        else if (props.school === "Engineering") {
            setTimetableLink("https://www.nuigalway.ie/science-engineering/engineering/currentstudentinformation/timetablesandsyllabus/");
        }
        else if(props.school === "Mathematics, Statistics and Applied Mathematics") {
            setTimetableLink("http://schoolmaster.nuigalway.ie/cohorts");
        }
        else if(props.school === "Physics") {
            setTimetableLink("http://www.nuigalway.ie/science-engineering/schoolofphysics/undergraduatecourses/");
        }
        else if(props.school === "Natural Sciences") {
            setTimetableLink("https://www.nuigalway.ie/science-engineering/studentinformation/undergraduatestudentinformation/undergraduatetimetables/");
        }

    },[currentUser.id, currentUser.roles, props.school, props.studentId]);

    function selectFile(event) {
        setSelectedFiles(event.target.files);
    }

    let history = useHistory();

    /* handle uploading a new timetable */
    function handleUploadTimetable() {

        if(selectedFiles === undefined) {
            console.log("No file selected");
        }
        else {
            let currentFile = selectedFiles[0];

            FileUploadDataService.uploadTimetable(currentUser.id, currentFile)
            .then(() => {
                history.push("/student/profile/timetable");
            })
            .catch(e => {
                console.log(e);
                setError("File too large: Limit 2MB")
            });
        }
    }

    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(1);

    function onDocumentLoadSuccess({numPages}) {
        setNumPages(numPages);
        setPageNumber(1);
    }

    function changePage(offset) {
        setPageNumber(prevPageNumber => prevPageNumber + offset);
    }
    
    function previousPage() {
        changePage(-1);
    }
    
    function nextPage() {
        changePage(1);
    }

    const options = {
        cMapUrl: 'cmaps/',
        cMapPacked: true,
        verbosity: 0,
    };

    return (
        <>
            <div className="resume_container">
                <div className="resume_upload_section">
                    <div className="resume_header">
                        <p>Upload Timetable as PDF</p>
                    </div>
                    <div>
                        <input type="file" accept="application/pdf" name="filename" onChange={selectFile}/>
                    </div>
                    {error && (
                        <p className="uploadError">{error}</p>
                    )}
                    <button className="add_resume_btn" onClick={handleUploadTimetable}>
                        <i className="fas fa-plus-circle add_icon"></i>
                        Upload Timetable
                    </button>
                    <a className="timetableLink" href={timetableLink}>Click here to view timetables</a>
                </div>
                <hr className="section_break"/>
                <div className="resume_section">
                    <div className="resume_header">
                        <p>Timetable</p>
                    </div>
                    {currentTimetable ? (
                        <div className="resume_pdf_container">
                            <Document
                                file={currentTimetable.url}
                                options={options}
                                onLoadSuccess={onDocumentLoadSuccess}
                            >
                                <Page className="pdf_page" pageNumber={pageNumber}/>
                            </Document>
                            <div className="resume_pdf_buttons">
                                <p>Page {pageNumber || (numPages ? 1 : "--")} of {numPages || "--"}</p>
                                <button className="pdf_btn" type="button" disabled={pageNumber <= 1} onClick={previousPage}>
                                    Previous
                                </button>
                                <button className="pdf_btn" type="button" disabled={pageNumber >= numPages} onClick={nextPage}>
                                    Next
                                </button>
                            </div>
                        </div>
                    ) : (
                        <p>No timetable uploaded</p>
                    )}
                </div>
            </div>
        </>
    );
}

export default ProfileTimetable;