import React, {useState} from 'react';
import ExperienceDataService from "../../../services/experience.service";
import Form from 'react-validation/build/form';

function ExperienceItem(props) {

    const [company, setCompany] = useState(props.company);
    const [jobTitle, setJobTitle] = useState(props.jobTitle);
    const [description, setDescription] = useState(props.description);
    const [startDate, setStartDate] = useState(props.startDate.substr(3, 4)+"-"+props.startDate.substr(0, 2));
    const [endDate, setEndDate] = useState(props.endDate.substr(3, 4)+"-"+props.endDate.substr(0, 2));

    /* handle editing the experience item */
    const [editExperience, setEditExperience] = useState(false);

    function handleEditExperience() {
        setEditExperience(true);
    }

    function handleExperienceSave() {

        const startDateF = startDate.substr(5, 2)+"/"+startDate.substr(0, 4);
        const endDateF = endDate.substr(5, 2)+"/"+endDate.substr(0, 4);

        var data = {
            jobTitle: jobTitle,
            company: company,
            description: description,
            startDate: startDateF,
            endDate: endDateF
        };

        ExperienceDataService.updateExperience(props.experienceId, data)
        .then(() => {
            setEditExperience(false);
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }
    
    function handleExperienceBack() {
        setCompany(props.company);
        setJobTitle(props.jobTitle);
        setDescription(props.description);
        setStartDate(props.startDate.substr(3, 4)+"-"+props.startDate.substr(0, 2));
        setEndDate(props.endDate.substr(3, 4)+"-"+props.endDate.substr(0, 2));
        setEditExperience(false);
    }


    /* handle deleting the experience item */
    function handleDeleteExperience() {

        ExperienceDataService.deleteExperience(props.experienceId)
        .then(() => {
            window.location.reload();
        })
        .catch(e => {
            console.log(e);
        });
    }

    return (
        <>
            {editExperience ? (
                <>
                    <Form onSubmit={handleExperienceSave}>
                        <div className="company_job_inputs">
                            <input 
                                type="text" 
                                defaultValue={props.company} 
                                required 
                                onChange={e => setCompany(e.target.value)}
                                className="company_input"
                            />
                            <input 
                                type="text" 
                                defaultValue={props.jobTitle} 
                                required 
                                onChange={e => setJobTitle(e.target.value)}
                                className="job_input"
                            />
                        </div>
                        <textarea  
                            rows="4"
                            defaultValue={props.description}
                            required
                            onChange={e => setDescription(e.target.value)}
                            className="description_input"
                        />
                        <div className="date_inputs">
                            <input 
                                type="month"
                                defaultValue={startDate}
                                className="startdate_input"
                                onChange={e => setStartDate(e.target.value)}
                                required
                            />
                            <input 
                                type="month"
                                defaultValue={endDate}
                                className="enddate_input"
                                onChange={e => setEndDate(e.target.value)}
                                required
                            />
                        </div>
                        <div className="experience_buttons">
                            <button type="submit" className="s_button">Save</button>
                            <button type="button" className="e_button" onClick={handleExperienceBack}>Back</button>
                        </div>
                    </Form>
                </>
            ) : (
                <>
                    <div className="experience_item">
                        <p className="item_title">{props.company} : {props.jobTitle}</p>
                        <p className="description_para">{props.description}</p>
                        <p className="item_year">{props.startDate} - {props.endDate}</p>
                    </div>
                    <div className="edit_delete_icons">
                        <i className="fas fa-pencil-alt experience_icon" onClick={handleEditExperience}></i>
                        <i className="far fa-trash-alt experience_icon" onClick={handleDeleteExperience}></i>
                    </div>
                </>
            )}
        </>
    );
}

export default ExperienceItem;
