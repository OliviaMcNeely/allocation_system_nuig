import React from 'react';
import {Link} from 'react-router-dom';

function Student(props) {

    /* Handle displaying the right amount of characters for bio */
    const MAX_LENGTH = 200;
    const bio = props.bio;

    return (
        <>
            <div className="student__container">
                <Link 
                    to={{
                        pathname: `/student/details/`+ props.studentId
                    }}
                    className="student__link" 
                >
                    <div className="details__container">
                        <p className="p1">{props.firstname} {props.surname}</p>
                        <p className="p2">{props.courseTitle}</p>
                        <button className="profileBtn">View Profile</button>
                    </div>
                    <div className="bio__container">
                        {bio.length > MAX_LENGTH ? (
                            <p>
                                {`${bio.substring(0, MAX_LENGTH)}...`}
                            </p>
                        ) : (
                            <p>{bio}</p>
                        )}
                    </div>
                </Link>
                
                <hr className="underLine"/>
            </div>
        </>
    )
}

export default Student;
