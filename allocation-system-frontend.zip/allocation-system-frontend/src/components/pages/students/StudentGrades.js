import React, {useState, useEffect} from 'react';
import AuthService from "../../../services/auth.service";
import FileUploadDataService from "../../../services/fileupload.service";
import StudentDataService from "../../../services/students.service";
import {Document, Page, pdfjs} from 'react-pdf';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

function ProfileTimetable(props) {

    const currentUser = AuthService.getCurrentUser();
    const [currentGrades, setCurrentGrades] = useState(undefined);

    /* When the component mounts get grades report */
    useEffect(() => {

        StudentDataService.checkGrades(props.studentId)
        .then((r) => {
            if(r.data === false) {
                setCurrentGrades(undefined);
            }
            else {
                FileUploadDataService.getGrades(r.data)
                .then((response) => {
                    setCurrentGrades(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[currentUser.id, props.studentId]);

    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(1);

    function onDocumentLoadSuccess({numPages}) {
        setNumPages(numPages);
        setPageNumber(1);
    }

    function changePage(offset) {
        setPageNumber(prevPageNumber => prevPageNumber + offset);
    }
    
    function previousPage() {
        changePage(-1);
    }
    
    function nextPage() {
        changePage(1);
    }

    const options = {
        cMapUrl: 'cmaps/',
        cMapPacked: true,
        verbosity: 0,
    };

    return (
        <>
            <div className="resume_container">
                <div className="resume_section">
                    <div className="resume_header">
                        <p>Grades Report</p>
                    </div>
                    {currentGrades ? (
                        <div className="resume_pdf_container">
                            <Document
                                file={currentGrades.url}
                                options={options}
                                onLoadSuccess={onDocumentLoadSuccess}
                            >
                                <Page className="pdf_page" pageNumber={pageNumber}/>
                            </Document>
                            <div className="resume_pdf_buttons">
                                <p>Page {pageNumber || (numPages ? 1 : "--")} of {numPages || "--"}</p>
                                <button className="pdf_btn" type="button" disabled={pageNumber <= 1} onClick={previousPage}>
                                    Previous
                                </button>
                                <button className="pdf_btn" type="button" disabled={pageNumber >= numPages} onClick={nextPage}>
                                    Next
                                </button>
                            </div>
                        </div>
                    ) : (
                        <p>No grade report uploaded</p>
                    )}
                </div>
            </div>
        </>
    );
}

export default ProfileTimetable;