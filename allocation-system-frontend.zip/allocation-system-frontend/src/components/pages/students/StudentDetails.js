import React, {useState, useEffect} from 'react';
import {Link , useHistory} from 'react-router-dom';
import '../studentprofile/StudentProfile.css';
import Navigation from '../navigation/Navigation';
import Review from '../studentprofile/ProfileReview';
import StudentResume from './StudentResume';
import StudentTimetable from './StudentTimetable';
import StudentGrades from './StudentGrades';
import StudentDataService from "../../../services/students.service";
import ExperienceDataService from "../../../services/experience.service";
import EducationDataService from "../../../services/education.service";
import SkillDataService from "../../../services/skills.service";
import ReviewDataService from "../../../services/reviews.service";
import FileUploadDataService from "../../../services/fileupload.service";
import Form from 'react-validation/build/form';
import AuthService from '../../../services/auth.service';

function StudentDetails(props) {
    
    const currentUser = AuthService.getCurrentUser();
    const [studentInfo, setStudentInfo] = useState([]);
    const [experienceInfo, setExperienceInfo] = useState([]);
    const [educationInfo, setEducationInfo] = useState([]);
    const [skillsInfo, setSkillsInfo] = useState([]);
    const [reviewsInfo, setReviewsInfo] = useState([]);
    const [profilePicture, setProfilePicture] = useState();
    const [review, setReview] = useState();
    const [rating, setRating] = useState(1);
    let history = useHistory();

    /* When the component mounts get the student, experience, education and skills data */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user || !user.roles.includes("ROLE_LECTURER")) {
            AuthService.logout()
            history.push("/login");
        }

        const { handle } = props.match.params;

        StudentDataService.get(handle)
        .then(response => {
            setStudentInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        ExperienceDataService.getAllStudentExperience(handle)
        .then(response => {
            setExperienceInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        EducationDataService.getAllStudentEducation(handle)
        .then(response => {
            setEducationInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        SkillDataService.getStudentSkills(handle)
        .then(response => {
            setSkillsInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        ReviewDataService.getAllStudentReviews(handle)
        .then(response => {
            setReviewsInfo(response.data);
        })
        .catch(e => {
            console.log(e);
        });

        FileUploadDataService.checkProfilePicture(handle)
        .then((r) => {
            if(r.data === false) {
                setProfilePicture(undefined);
            }
            else {
                FileUploadDataService.getProfilePicture(r.data)
                .then((response) => {
                    setProfilePicture(response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            }
        })
        .catch(e => {
            console.log(e);
        });

    },[history, props.match.params]);


    const [currentMode, setCurrentMode] = useState();
    const [infoOpen, setInfoOpen] = useState(true);
    const [timetableOpen, setTimetableOpen] = useState(false);
    const [resumeOpen, setResumeOpen] = useState(false);
    const [gradesOpen, setGradesOpen] = useState(false);

    /* Function to open the info tab */
    function handleInfoOpen() {
        setInfoOpen(true)
        setTimetableOpen(false)
        setResumeOpen(false)
        setGradesOpen(false)
        setCurrentMode()
    }


    /* Function to open the timetable tab */
    function handleTimetableOpen() {
        setInfoOpen(false)
        setTimetableOpen(true)
        setResumeOpen(false)
        setGradesOpen(false)
        setCurrentMode('timetable')
    }


    /* Function to open the resume tab */
    function handleResumeOpen() {
        setInfoOpen(false)
        setTimetableOpen(false)
        setResumeOpen(true)
        setGradesOpen(false)
        setCurrentMode('resume')
    }


    /* Function to open the grades tab */
    function handleGradesOpen() {
        setInfoOpen(false)
        setTimetableOpen(false)
        setResumeOpen(false)
        setGradesOpen(true)
        setCurrentMode('grades')
    }


    /* Function to open the correct current tab */
    function getContent(current) {
        const content =  {
            timetable: <StudentTimetable
                studentId={studentInfo.studentId}
            />,
            resume: <StudentResume
                studentId={studentInfo.studentId}
            />,
            grades: <StudentGrades
                studentId={studentInfo.studentId}
            />
        };

        return content[current];
    }

    function handleReview() {

        let data = {
            reviewDescription: review,
            rating: rating
        }

        ReviewDataService.createReview(studentInfo.studentId, currentUser.id, data)
        .then(() => {
            history.push("student/details/info");
        })
        .catch(e => {
            console.log(e);
        });
    }
    
    return (
        <>
            <Navigation />
            <div className="top_bar">
                <div className="profile_picture">
                    {profilePicture ? 
                        <img src={profilePicture.url} alt="profile" />
                    :
                        <img src={"images/default_picture.jpg"} alt="profile" />
                    }
                </div>
                <div className="profile_info">
                    <div className="profile_title">
                        <h1>{studentInfo.firstname} {studentInfo.surname}</h1>
                        <p>{studentInfo.courseTitle}</p>
                    </div>
                </div>
                <Link to={{pathname: `/student/applications/`+studentInfo.studentId}}>
                    <button className="posappBtn">View Positions Applied</button>
                </Link>
            </div>

            <div className="profile_container">
                <div className="side_bar">
                    <div className="review_title">
                        <i className="far fa-star"></i>
                        <p>REVIEWS</p>
                    </div>
                    <div className="reviews">
                        {reviewsInfo &&
                        reviewsInfo.map((review, index) => (
                            <div key={index}>
                                <Review
                                    lecturer={review.responseLecturer.lecturerId}
                                    review={review.reviewDescription}
                                    rating={review.rating}
                                />
                            </div>
                        ))}
                        <Form onSubmit={handleReview}>
                            <div className="review_form">
                                <input 
                                    type="text" 
                                    className="descriptionInput" 
                                    placeholder="Review Comment" 
                                    required 
                                    onChange={e => setReview(e.target.value)}
                                />
                                <select required onChange={e => setRating(e.target.value)} className="ratingInput">
                                    <option value="1">1 Star</option>
                                    <option value="2">2 Star</option>
                                    <option value="3">3 Star</option>
                                    <option value="4">4 Star</option>
                                    <option value="5">5 Star</option>
                                </select>
                                <button className="reviewButton">Submit Review</button>
                            </div>
                        </Form>
                    </div>
                </div>

                <div className="main_area">
                    <div className="main_area_content">
                        <div className="content_top">
                            <div className={infoOpen ? "tab selected_tab info_tab" : "tab info_tab"} onClick={handleInfoOpen}>
                                <i className="fas fa-info-circle"></i>
                                <p>INFO</p>
                            </div>
                            <div className={timetableOpen ? "tab selected_tab" : "tab"} onClick={handleTimetableOpen}>
                                <i className="fas fa-calendar-alt"></i>
                                <p>TIMETABLE</p>
                            </div>
                            <div className={resumeOpen ? "tab selected_tab" : "tab"} onClick={handleResumeOpen}>
                                <i className="fas fa-file"></i>
                                <p>RESUME</p>
                            </div>
                            <div className={gradesOpen ? "tab selected_tab grades_tab" : "tab grades_tab"} onClick={handleGradesOpen}>
                                <i className="fas fa-poll-h"></i>
                                <p>GRADES</p>
                            </div>
                        </div>
                        
                        {infoOpen && (
                            <>
                                <div>
                                    <div className="section_header">
                                        <p>About</p>
                                    </div>
                                    
                                    <p className="about_para">
                                        {studentInfo.bio}
                                    </p>

                                    <hr className="section_break" />
                                </div>

                                <div className="skills_section">
                                    <div className="section_header">
                                        <p>Skills</p>
                                    </div>
                                    <div className="skills_items">
                                        {skillsInfo &&
                                        skillsInfo.map((s, index) => (
                                            <div key={s.skillId} className="skill_item">
                                                <div className="skill">
                                                    <p>{s.skill}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                    <hr className="section_break"/>
                                </div>

                                <div className="experience_section">
                                    <div className="section_header">
                                        <p>Experience</p>
                                    </div>
                                    <div className="experience_items">
                                        {experienceInfo &&
                                        experienceInfo.map((ex, index) => (
                                            <div key={ex.experienceId}>
                                                <div className="experience_item">
                                                    <p className="item_title">{ex.company} : {ex.jobTitle}</p>
                                                    <p className="description_para">{ex.description}</p>
                                                    <p className="item_year">{ex.startDate} - {ex.endDate}</p>
                                                </div>
                                                {index+1 === experienceInfo.length ? 
                                                    <div></div> : 
                                                    <hr className="section_break"/>
                                                }
                                            </div>
                                        ))}
                                    </div>
                                    <hr className="section_break" />
                                </div>

                                <div className="education_section">
                                    <div className="section_header">
                                        <p>Education</p>
                                    </div>
                                    <div className="education_items">
                                        {educationInfo &&
                                        educationInfo.map((ex, index) => (
                                            <div key={ex.educationId}>
                                                <div className="education_item">
                                                    <p className="item_title">{ex.schoolName}</p>
                                                    <p>{ex.courseTitle}</p>
                                                    <p className="item_year">{ex.startYear} - {ex.endYear}</p>
                                                </div>
                                                {index+1 === educationInfo.length ? 
                                                    <div></div> : 
                                                    <hr className="section_break"/>
                                                }
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </>
                        )}

                        {getContent(currentMode)}

                    </div>
                </div>
            </div>
        </>
    );
}

export default StudentDetails;