import React, {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import './Students.css';
import Navigation from '../navigation/Navigation';
import Student from './Student';
import StudentDataService from '../../../services/students.service';
import AuthService from '../../../services/auth.service';

function Students() {

    const [students, setStudents] = useState([]);
    const [stu, setStu] = useState(true);
    const [cs, setCS] = useState(false);
    const [eng, setEng] = useState(false);
    const [chem, setChem] = useState(false);
    const [math, setMath] = useState(false);
    const [nat, setNat] = useState(false);
    const [phy, setPhy] = useState(false);
    let history = useHistory();

    /* When component mounts check get the 4 random positions and the student data */
    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user || !user.roles.includes("ROLE_LECTURER")) {
            AuthService.logout()
            history.push("/login");
        }

        StudentDataService.getAllStudents()
        .then(response => {
            setStudents(response.data);
        })
        .catch(e => {
            console.log(e);
        });

    },[history]);

    /* Handle open and close filters when in small screen */
    const [open, setOpen] = useState(false);
    const handleOpen = () => {
        setOpen(!open);
    }

    /* Handle clear the filters */
    function handleClearFilters() {

        document.getElementById("cscheckbox").checked = false;
        document.getElementById("echeckbox").checked = false;
        document.getElementById("ccheckbox").checked = false;
        document.getElementById("mcheckbox").checked = false;
        document.getElementById("ncheckbox").checked = false;
        document.getElementById("pcheckbox").checked = false;

        setCS(false);
        setEng(false);
        setChem(false);
        setMath(false);
        setNat(false);
        setPhy(false);
        setStu(true);

        StudentDataService.getAllStudents()
        .then(response => {
            setStudents(response.data);
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleSchoolFilters() {
        
        setSearch(false);
        document.getElementById("search").value = "";

        // Computer Science filters
        if(document.getElementById("cscheckbox").checked === true) {
            setStu(false);
            setCS(true);
        }
        else if(document.getElementById("cscheckbox").checked === false) {
            setCS(false);
        }

        // Engineering filters
        if(document.getElementById("echeckbox").checked === true) {
            setStu(false);
            setEng(true);
        }
        else if(document.getElementById("echeckbox").checked === false) {
            setEng(false);
        }

        // Chemistry filters
        if(document.getElementById("ccheckbox").checked === true) {
            setStu(false);
            setChem(true);
        }
        else if(document.getElementById("ccheckbox").checked === false) {
            setChem(false);
        }

        // Mathematics filters
        if(document.getElementById("mcheckbox").checked === true) {
            setStu(false);
            setMath(true);
        }
        else if(document.getElementById("mcheckbox").checked === false) {
            setMath(false);
        }

        // Natural Sci filters
        if(document.getElementById("ncheckbox").checked === true) {
            setStu(false);
            setNat(true);
        }
        else if(document.getElementById("ncheckbox").checked === false) {
            setNat(false);
        }

        // Physics filters
        if(document.getElementById("pcheckbox").checked === true) {
            setStu(false);
            setPhy(true);
        }
        else if(document.getElementById("pcheckbox").checked === false) {
            setPhy(false);
        }

        // Clear all filters
        if (document.getElementById("cscheckbox").checked === false &&
            document.getElementById("echeckbox").checked === false &&
            document.getElementById("ccheckbox").checked === false &&
            document.getElementById("mcheckbox").checked === false &&
            document.getElementById("ncheckbox").checked === false &&
            document.getElementById("pcheckbox").checked === false)
        {
            setStu(true);
            setCS(false);
            setEng(false);
            setChem(false);
            setMath(false);
            setNat(false);
            setPhy(false);
        }
    }

    /* Handle searching for students */
    const [search, setSearch] = useState(false);
    const [searchTerm, setSearchTerm] = useState();
    function handleSearch() {
        if(document.getElementById("search").value === "") {
            setStu(true);
            setSearch(false);
        }
        else {
            setSearchTerm(document.getElementById("search").value);
            setSearch(true);
            setStu(false);
            setCS(false);
            setEng(false);
            setChem(false);
            setMath(false);
            setNat(false);
            setPhy(false);

            document.getElementById("cscheckbox").checked = false;
            document.getElementById("echeckbox").checked = false;
            document.getElementById("ccheckbox").checked = false;
            document.getElementById("mcheckbox").checked = false;
            document.getElementById("ncheckbox").checked = false;
            document.getElementById("pcheckbox").checked = false;
        }
    }

    /* Handle clearing the search bar */
    function handleClearSearch() {
        setSearch(false);
        setStu(true);
        document.getElementById("search").value = "";
    }

    return (
        <>
            <Navigation/>
            <div className="top__bar"></div>

            <div className="students__container">

                <div className="side__bar">
                    <div className="filters__">
                        <h1 className="filter__title">FILTER BY SCHOOL</h1>
                        <i className={ open ? "fas fa-times close__icon" : "fas fa-chevron-circle-down close__icon"} onClick={handleOpen}></i>
                    </div>
                    <p className={ open ? "filter__checkbox" : "filter__checkbox close"}>
                        <input type="checkbox" className="checkbox" id="cscheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Computer Science</label>
                    </p>
                    <p className={ open ? "filter__checkbox" : "filter__checkbox close"}>
                        <input type="checkbox" className="checkbox" id="echeckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Engineering</label>
                    </p>
                    <p className={ open ? "filter__checkbox" : "filter__checkbox close"}>
                        <input type="checkbox" className="checkbox" id="ccheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Chemistry</label>
                    </p>
                    <p className={ open ? "filter__checkbox" : "filter__checkbox close"}>
                        <input type="checkbox" className="checkbox" id="mcheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Mathematics, Stat...</label>
                    </p>
                    <p className={ open ? "filter__checkbox" : "filter__checkbox close"}>
                        <input type="checkbox" className="checkbox" id="ncheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Natural Sciences</label>
                    </p>
                    <p className={ open ? "filter__checkbox" : "filter__checkbox close"}>
                        <input type="checkbox" className="checkbox" id="pcheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Physics</label>
                    </p>
                    <div className="filterBtns">
                        <button className={ open ? "filterBtn" : "filterBtn close"} onClick={handleClearFilters}>Clear filters</button>
                    </div>
                </div>

                <div className="students__list__container">
                    <div className="students__list__wrapper">

                        <div className="searchBar">
                            <h1 className="searchTitle">Search for a Student</h1>
                            <input type="text" className="searchBox" placeholder="Search by name" id="search" onChange={handleSearch}></input>
                            <button className="searchButton" onClick={handleClearSearch}>Clear Search</button> 
                        </div>

                        <div className="students__">
                            <h1 className="students__title">Students</h1>
                            <hr className="title__line"/>

                            {stu &&
                            students.map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}

                            {search &&
                            students.filter(s => (s.firstname.toLowerCase() + " " + s.surname.toLowerCase()).includes(searchTerm.toLowerCase())).map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}         

                            {cs &&
                            students.filter(s => s.school === "Computer Science").map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}

                            {eng &&
                            students.filter(s => s.school === "Engineering").map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}

                            {chem &&
                            students.filter(s => s.school === "Chemistry").map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}

                            {math &&
                            students.filter(s => s.school === "Mathematics, Statistics and Applied Mathematics").map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}

                            {nat &&
                            students.filter(s => s.school === "Natural Sciences").map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}

                            {phy &&
                            students.filter(s => s.school === "Physics").map((student, index) => (
                                <div key={index}>
                                    <Student
                                        studentId={student.studentId}
                                        firstname={student.firstname}
                                        surname={student.surname}
                                        courseTitle={student.courseTitle}
                                        school={student.school}
                                        bio={student.bio}
                                    />
                                </div>
                            ))}

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Students;
