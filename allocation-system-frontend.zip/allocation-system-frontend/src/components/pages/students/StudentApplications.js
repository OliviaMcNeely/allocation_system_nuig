import React, { useState, useEffect } from 'react';
import {Link , useHistory} from 'react-router-dom';
import Navigation from '../navigation/Navigation';
import AuthService from '../../../services/auth.service';
import PositionDataService from '../../../services/positions.service';
import Position from '../positions/AllPosition';
import StudentDataService from "../../../services/students.service";

function StudentApplications(props) {

    const {id} = props.match.params;
    const [studentInfo, setStudentInfo] = useState([]);
    const [positions, setPositions] = useState([]);
    const [pos, setPos] = useState(true);
    const [cs, setCS] = useState(false);
    const [eng, setEng] = useState(false);
    const [chem, setChem] = useState(false);
    const [math, setMath] = useState(false);
    const [nat, setNat] = useState(false);
    const [phy, setPhy] = useState(false);
    let history = useHistory();

    useEffect(() => {

        const user = AuthService.getCurrentUser();

        if(!user || !user.roles.includes("ROLE_LECTURER")){
            AuthService.logout()
            history.push("/login");
        }
        else {
            PositionDataService.getAllAppliedOfferedAcceptedPositions(id)
            .then(response => {
                setPositions(response.data);
            })
            .catch(e => {
                console.log(e);
            });

            StudentDataService.get(id)
            .then(response => {
                setStudentInfo(response.data);
            })
            .catch(e => {
                console.log(e);
            });
        }

    },[history, id, props.match.params]);

    /* Handle open and close filters when in small screen */
    const [open, setOpen] = useState(false);
    function handleOpen() {
        setOpen(!open);
    }

    /* Handle clear the filters */
    function handleClearFilters() {

        document.getElementById("cscheckbox").checked = false;
        document.getElementById("echeckbox").checked = false;
        document.getElementById("ccheckbox").checked = false;
        document.getElementById("mcheckbox").checked = false;
        document.getElementById("ncheckbox").checked = false;
        document.getElementById("pcheckbox").checked = false;

        setCS(false);
        setEng(false);
        setChem(false);
        setMath(false);
        setNat(false);
        setPhy(false);
        setPos(true);

        PositionDataService.getAllAppliedPositionsByStatus(id, "received")
        .then(response => {
            setPositions(response.data);
        })
        .catch(e => {
            console.log(e);
        });
    }

    function handleSchoolFilters() {

        // Computer Science filters
        if(document.getElementById("cscheckbox").checked === true) {
            setPos(false);
            setCS(true);
        }
        else if(document.getElementById("cscheckbox").checked === false) {
            setCS(false);
        }

        // Engineering filters
        if(document.getElementById("echeckbox").checked === true) {
            setPos(false);
            setEng(true);
        }
        else if(document.getElementById("echeckbox").checked === false) {
            setEng(false);
        }

        // Chemistry filters
        if(document.getElementById("ccheckbox").checked === true) {
            setPos(false);
            setChem(true);
        }
        else if(document.getElementById("ccheckbox").checked === false) {
            setChem(false);
        }

        // Mathematics filters
        if(document.getElementById("mcheckbox").checked === true) {
            setPos(false);
            setMath(true);
        }
        else if(document.getElementById("mcheckbox").checked === false) {
            setMath(false);
        }

        // Natural Sci filters
        if(document.getElementById("ncheckbox").checked === true) {
            setPos(false);
            setNat(true);
        }
        else if(document.getElementById("ncheckbox").checked === false) {
            setNat(false);
        }

        // Physics filters
        if(document.getElementById("pcheckbox").checked === true) {
            setPos(false);
            setPhy(true);
        }
        else if(document.getElementById("pcheckbox").checked === false) {
            setPhy(false);
        }

        // Clear all filters
        if (document.getElementById("cscheckbox").checked === false &&
            document.getElementById("echeckbox").checked === false &&
            document.getElementById("ccheckbox").checked === false &&
            document.getElementById("mcheckbox").checked === false &&
            document.getElementById("ncheckbox").checked === false &&
            document.getElementById("pcheckbox").checked === false)
        {
            setPos(true);
            setCS(false);
            setEng(false);
            setChem(false);
            setMath(false);
            setNat(false);
            setPhy(false);
        }
    }

    return (
        <>
            <Navigation/>
            <div className="topBar"></div>

            <div className="positionsContainer">

                <div className="sideBar">
                    <div className="filters">
                        <h1 className="filterTitle">FILTER</h1>
                        <i className={ open ? "fas fa-times closeIcon" : "fas fa-chevron-circle-down closeIcon"} onClick={handleOpen}></i>
                    </div>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="cscheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Computer Science</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="echeckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Engineering</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="ccheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Chemistry</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="mcheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Mathematics, Stat...</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="ncheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Natural Sciences</label>
                    </p>
                    <p className={ open ? "filterCheckbox" : "filterCheckbox close"}>
                        <input type="checkbox" className="checkbox" id="pcheckbox" onChange={handleSchoolFilters}/>
                        <label htmlFor="checkbox"> Physics</label>
                    </p>
                    <div className="filterBtns">
                        <button className={ open ? "filterBtn" : "filterBtn close"} onClick={handleClearFilters}>Clear filters</button>
                    </div>
                </div>

                <div className="positionsInfoContainer">
                    <div className="positionsInfoWrapper">
                        <div className="positions">
                            <div className="titlebar">
                                <h1 className="postitle">{studentInfo.firstname} {studentInfo.surname}'s Applied Positions</h1>
                                <Link to={{pathname: `/student/details/`+studentInfo.studentId}}>
                                    <button className="proBtn">Back to Profile</button>
                                </Link>
                            </div>
                            <hr className="titleLine"/>
                            
                            {pos && positions &&
                            positions.map((position) => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                            {cs &&
                            positions.filter(p => p.school === "Computer Science").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                            {eng &&
                            positions.filter(p => p.school === "Engineering").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                            {chem &&
                            positions.filter(p => p.school === "Chemistry").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                            {math &&
                            positions.filter(p => p.school === "Mathematics, Statistics and Applied Mathematics").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                            {nat &&
                            positions.filter(p => p.school === "Natural Sciences").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                            {phy &&
                            positions.filter(p => p.school === "Physics").map(position => (
                                <div className="position" key={position.positionId}>
                                    <Position
                                        moduleCode={position.moduleCode}
                                        title={position.moduleTitle}
                                        lecturer={position.responseLecturer.firstname + " " + position.responseLecturer.surname}
                                        description={position.description}
                                        positionId={position.positionId}
                                    />
                                </div>
                            ))}

                        </div>
                    </div>
                </div>
            </div>
            
        </>
    )
}

export default StudentApplications;
