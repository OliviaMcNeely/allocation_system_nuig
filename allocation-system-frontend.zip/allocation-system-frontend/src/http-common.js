import axios from "axios";

export default axios.create({
    /*baseURL: "http://localhost:5000/allocationapp",*/
    baseURL: "http://tutorallocationapp-env.eba-dqz2hgia.eu-west-1.elasticbeanstalk.com/allocationapp",
    headers: {
        "Content-type": "application/json"
    }
});