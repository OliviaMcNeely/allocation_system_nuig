import React from 'react';
import {HashRouter, Switch, Route} from 'react-router-dom';
import './App.css';
import Login from './components/pages/login/Login';
import Register from './components/pages/register/Register';
import Home from './components/pages/home/Home';
import StudentProfile from './components/pages/studentprofile/StudentProfile';
import Inbox from './components/pages/inbox/Inbox';
import AllPositions from './components/pages/positions/AllPositions';
import LecturerPositions from './components/pages/positions/LecturerPositions';
import PositionDetails from './components/pages/positions/PositionDetails';
import PositionApplications from './components/pages/positions/PositionApplications';
import PositionRecommendations from './components/pages/positions/PositionRecommendations';
import PositionUpload from './components/pages/positions/PositionUpload';
import Students from './components/pages/students/Students';
import StudentDetails from './components/pages/students/StudentDetails';
import AllApplications from './components/pages/positions/AllApplications';
import StudentApplications from './components/pages/students/StudentApplications';
import InboxMessageDetails from './components/pages/inbox/InboxMessageDetails';
import SentMessageDetails from './components/pages/inbox/SentMessageDetails';
import NewMessage from './components/pages/inbox/NewMessage';

function App() {

    return (
        <HashRouter>
            <Switch>
                <Route path={["/", "/login"]} exact component={Login}/>
                <Route path="/register" exact component={Register}/>
                <Route path="/home" exact component={Home}/>
                <Route path="/inbox/:handle" exact component={Inbox}/>
                <Route path="/inbox/inbox/message/details/:id" exact component={InboxMessageDetails}/>
                <Route path="/inbox/sent/message/details/:id" exact component={SentMessageDetails}/>
                <Route path="/new/message" exact component={NewMessage}/>
                <Route path="/student/profile/:handle" exact component={StudentProfile}/>
                <Route path="/positions/:handle" exact component={AllPositions}/>
                <Route path="/uploaded/positions" exact component={LecturerPositions}/>
                <Route path="/position/details/:id" exact component={PositionDetails}/>
                <Route path="/position/applications/:id/:handle" exact component={PositionApplications}/>
                <Route path="/position/recommendations/:id" exact component={PositionRecommendations}/>
                <Route path="/upload/position" exact component={PositionUpload}/>
                <Route path="/students" exact component={Students}/>
                <Route path="/student/details/:handle" exact component={StudentDetails}/>
                <Route path="/all/applications/:handle" exact component={AllApplications}/>
                <Route path="/student/applications/:id" exact component={StudentApplications}/>
            </Switch>
        </HashRouter>
    );
}

export default App;