import http from "../http-common";

class AuthenticationDataService {

    registerStudent(data) {
        return http.post("/signup/student", data);
    }

    registerLecturer(data) {
        return http.post("/signup/lecturer", data);
    }

    login(username, password) {
        return http.post("/signin", {
            username, 
            password
        })
        .then((response) => {
            if (response.data.accessToken) {
                localStorage.setItem("user", JSON.stringify(response.data));
            }
    
            return response.data;
        });
    }

    logout() {
        localStorage.removeItem("user");
    }

    getCurrentUser() {
        return JSON.parse(localStorage.getItem("user"));
    }
  
}

export default new AuthenticationDataService();