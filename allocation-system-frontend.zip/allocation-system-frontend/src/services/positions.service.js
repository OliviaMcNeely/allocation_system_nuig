import http from "../http-common";

class PositionDataService {

    getAllPositions() {
        return http.get("/all/positions");
    }
  
    getPosition(positionId) {
        return http.get(`/position/${positionId}`);
    }
  
    createPosition(lecturerId, data) {
        return http.post(`/position/create/${lecturerId}`, data);
    }
  
    updatePositionDetails(positionId, data) {
        return http.put(`/position/update/details/${positionId}`, data);
    }

    updatePositionDescription(positionId, description) {
        return http.put(`/position/update/description/${positionId}`, description);
    }
  
    deletePosition(positionId) {
        return http.delete(`/position/delete/${positionId}`);
    }

    get4RandomPositions() {
        return http.get("/positions/random");
    }

    get4LecturerPositions(lecturerId) {
        return http.get(`/positions/four/${lecturerId}`);
    }

    getAllLecturerPositions(lecturerId) {
        return http.get(`/positions/${lecturerId}`);
    }

    checkLecturerPosition(lecturerId, positionId) {
        return http.get(`/check/position/${lecturerId}/${positionId}`);
    }

    getAllFavouritedPositions(studentId) {
        return http.get(`/positions/favourite/${studentId}`);
    }

    getAllAppliedPositionsByStatus(studentId, status) {
        return http.put(`/positions/applied/${studentId}`, status);
    }

    getAllAppliedOfferedAcceptedPositions(studentId) {
        return http.put(`/positions/applied/offered/accepted/${studentId}`);
    }

    checkRecommendations(positionId) {
        return http.get(`/check/recommendations/${positionId}`);
    }

    getRecommendationList(positionId) {
        return http.get(`/student/list/${positionId}`);
    }

    generateRecommendationList(positionId) {
        return http.get(`/generate/student/list/${positionId}`);
    }
  
  }
  
  export default new PositionDataService();