import http from "../http-common";

class ReviewsDataService {

    getAllStudentReviews(studentId) {
        return http.get(`${studentId}/reviews`);
    }

    createReview(studentId, lecturerId, data) {
        return http.post(`/review/${studentId}/${lecturerId}`, data);
    }
  
  }
  
  export default new ReviewsDataService();