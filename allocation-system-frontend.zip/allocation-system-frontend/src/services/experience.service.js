import http from "../http-common";

class ExperienceDataService {

    getAllStudentExperience(studentId) {
        return http.get(`${studentId}/experience`);
    }

    createExperience(studentId, data) {
        return http.post(`/experience/${studentId}`, data);
    }

    updateExperience(experienceId, data) {
        return http.put(`/experience/${experienceId}`, data);
    }
  
    deleteExperience(experienceId) {
        return http.delete(`/experience/${experienceId}`);
    }
  
  }
  
  export default new ExperienceDataService();