import http from "../http-common";

class PositionLikesDataService {

    checkLikePosition(studentId, positionId) {
        return http.get(`/${studentId}/${positionId}/checklike`);
    }

    likePosition(studentId, positionId) {
        return http.post(`/${studentId}/${positionId}/like`);
    }

    unlikePosition(studentId, positionId) {
        return http.delete(`/${studentId}/${positionId}/unlike`);
    }
  
  }
  
  export default new PositionLikesDataService();