import http from "../http-common";

class SkillDataService {

    getSkill(skillId) {
        return http.get(`/skill/${skillId}`);
    }

    getStudentSkills(studentId) {
        return http.get(`/student/skill/${studentId}`);
    }

    createStudentSkill(studentId, data) {
        return http.post(`/student/skill/create/${studentId}`, data);
    }

    removeStudentSkill(studentId, skillId) {
        return http.delete(`/student/skill/remove/${studentId}/${skillId}`);
    }

    getPositionSkills(positionId) {
        return http.get(`/position/skill/${positionId}`);
    }

    createPositionSkill(positionId, data) {
        return http.post(`/position/skill/create/${positionId}`, data);
    }

    removePositionSkill(positionId, skillId) {
        return http.delete(`/position/skill/remove/${positionId}/${skillId}`);
    }
  
  }
  
  export default new SkillDataService();