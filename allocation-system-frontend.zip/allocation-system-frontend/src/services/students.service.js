import http from "../http-common";
import authHeader from "./auth.header";

class StudentDataService {

    getAllStudents() {
        return http.get("/students");
    }
  
    get(studentId) {
        return http.get(`/student/${studentId}`, { headers: authHeader() });
    }

    updateStudentBio(studentId, bio) {
        return http.put(`/student/updatebio/${studentId}`, bio);
    }

    updateStudentDetails(studentId, data) {
        return http.put(`/student/updatedetails/${studentId}`, data);
    }
  
    delete(studentId) {
        return http.delete(`/student/delete/${studentId}`);
    }

    checkResume(studentId) {
        return http.get(`/resume/check/${studentId}`);
    }

    checkTimetable(studentId) {
        return http.get(`/timetable/check/${studentId}`);
    }

    checkGrades(studentId) {
        return http.get(`/gradereport/check/${studentId}`);
    }
  
  }
  
  export default new StudentDataService();