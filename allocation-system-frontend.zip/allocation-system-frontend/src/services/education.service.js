import http from "../http-common";

class EducationDataService {

    getAllStudentEducation(studentId) {
        return http.get(`${studentId}/education`);
    }

    createEducation(studentId, data) {
        return http.post(`/education/${studentId}`, data);
    }

    updateEducation(educationId, data) {
        return http.put(`/education/${educationId}`, data);
    }
  
    deleteEducation(educationId) {
        return http.delete(`/education/${educationId}`);
    }
  
}
  
export default new EducationDataService();