import http from "../http-common";
import authHeader from "./auth.header";

class LecturerDataService {

    getAllLecturers() {
        return http.get("/lecturers");
    }

    get(lecturerId) {
        return http.get(`/lecturer/${lecturerId}`, { headers: authHeader() });
    }
  
    update(lecturerId, data) {
        return http.put(`/lecturer/update/${lecturerId}`, data);
    }
  
    delete(lecturerId) {
        return http.delete(`/lecturer/delete/${lecturerId}`);
    }
  
  }
  
  export default new LecturerDataService();