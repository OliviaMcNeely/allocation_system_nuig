import http from "../http-common";

class ApplicationDataService {

    getAllApplicationsByStatus(lecturerId, status) {
        return http.put(`/applications/${lecturerId}`, status);
    }

    createApplication(studentId, positionId, data) {
        return http.post(`/application/${studentId}/${positionId}`, data);
    }

    getPositionApplicationsByStatus(positionId, status) {
        return http.put(`/position/applications/${positionId}`, status);
    }

    getAllStudentApplications(studentId) {
        return http.get(`/student/applications/${studentId}`);
    }

    getApplicationStudent(applicationId) {
        return http.get(`application/student/${applicationId}`);
    }

    getApplicationPosition(applicationId) {
        return http.get(`application/position/${applicationId}`);
    }

    updateStatus(applicationId, status) {
        return http.put(`application/status/${applicationId}`, status);
    }

    applicationExists(studentId, positionId) {
        return http.get(`application/check/${studentId}/${positionId}`);
    }

    findApplication(studentId, positionId) {
        return http.get(`application/${studentId}/${positionId}`);
    }
  
}
  
export default new ApplicationDataService();