import http from "../http-common";

class FileUploadDataService {

    checkProfilePicture(userId) {
        return http.get(`/profile/picture/check/${userId}`);
    }

    uploadProfilePictureStudent(studentId, file) {
        let formData = new FormData();
        formData.append("file", file);
        return http.post(`/upload/profile/picture/student/${studentId}`, formData);
    }

    uploadProfilePictureLecturer(lecturerId, file) {
        let formData = new FormData();
        formData.append("file", file);
        return http.post(`/upload/profile/picture/lecturer/${lecturerId}`, formData);
    }

    getProfilePicture(id) {
        return http.get(`/profile/picture/${id}`);
    }

    uploadResume(studentId, file) {
        let formData = new FormData();
        formData.append("file", file);
        return http.post(`/upload/resume/${studentId}`, formData);
    }

    getResume(id) {
        return http.get(`/resume/${id}`);
    }

    uploadTimetable(studentId, file) {
        let formData = new FormData();
        formData.append("file", file);
        return http.post(`/upload/timetable/${studentId}`, formData);
    }

    getTimetable(id) {
        return http.get(`/timetable/${id}`);
    }

    uploadGradeReport(studentId, file) {
        let formData = new FormData();
        formData.append("file", file);
        return http.post(`/upload/gradereport/${studentId}`, formData);
    }

    getGradeReport(id) {
        return http.get(`/gradereport/${id}`);
    }
  
}

export default new FileUploadDataService();