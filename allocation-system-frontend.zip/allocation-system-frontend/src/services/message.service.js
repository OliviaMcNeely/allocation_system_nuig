import http from "../http-common";

class MessageDataService {

    createMessage(senderId, recipientId, data) {
        return http.post(`/new/message/${senderId}/${recipientId}`, data);
    }

    handleOpen(messageId) {
        return http.put(`/handle/opened/${messageId}`);
    }

    getMessage(messageId) {
        return http.get(`/message/${messageId}`);
    }

    getAllSentMessages(userId) {
        return http.get(`/${userId}/sent/messages`);
    }

    topFourReceivedMessages(userId) {
        return http.get(`/${userId}/received/messages/four`);
    }

    getAllReceivedMessages(userId) {
        return http.get(`/${userId}/received/messages`);
    }

    deleteSentMessage(messageId, userId) {
        return http.delete(`/delete/sent/message/${messageId}/${userId}`);
    }

    deleteReceivedMessage(messageId, userId) {
        return http.delete(`/delete/received/message/${messageId}/${userId}`);
    }
}

export default new MessageDataService();