package com.nuig.allocation_system.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.nuig.allocation_system.message.ResponseUser;

@Entity
@Table(name = "messages")
public class Message implements Comparable<Message> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "messageId")
    private long messageId;

    @Column(name = "messageText", length = 2000)
    private String messageText;

    @JsonFormat(pattern="dd-MM-yyyy")
    @Column(name = "date")
    private Date date;

    @Column(name = "opened")
    private Boolean opened = false;

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="senderId")
    private User sender;

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="recipientId")
    private User recipient;

    @Transient
    private ResponseUser rSender;
    
    @Transient
    private ResponseUser rRecipient;

    @Column(name = "senderDelete")
    private Boolean senderDelete;

    @Column(name = "recipientDelete")
    private Boolean recipientDelete;

    public Message() {     
    }

    public Message(String messageText, Date date, User sender, User recipient) {
        this.messageText = messageText;
        this.date = date;
        this.sender = sender;
        this.recipient = recipient;
        this.senderDelete = false;
        this.recipientDelete = false;
    }

    public Message(String messageText, Date date, ResponseUser rSender, ResponseUser rRecipient) {
        this.messageText = messageText;
        this.date = date;
        this.rSender = rSender;
        this.rRecipient = rRecipient;
    }

    public long getMessageId() {
        return messageId;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Boolean isOpened() {
        return opened;
    }

    public void setOpened(Boolean opened) {
        this.opened = opened;
    }

    public User getSender() {
        return sender;
    }

    public void setSender(User sender) {
        this.sender = sender;
    }

    public User getRecipient() {
        return recipient;
    }

    public void setRecipient(User recipient) {
        this.recipient = recipient;
    }

    public ResponseUser getRSender() {
        return rSender;
    }

    public void setRSender(ResponseUser rSender) {
        this.rSender = rSender;
    }

    public ResponseUser getRRecipient() {
        return rRecipient;
    }

    public void setRRecipient(ResponseUser rRecipient) {
        this.rRecipient = rRecipient;
    }

    public Boolean getSenderDelete() {
        return senderDelete;
    }

    public void setSenderDelete(Boolean delete) {
        this.senderDelete = delete;
    }

    public Boolean getRecipientDelete() {
        return recipientDelete;
    }

    public void setRecipientDelete(Boolean delete) {
        this.recipientDelete = delete;
    }

    @Override
	public int compareTo(Message m) {
		return m.getDate().compareTo(this.getDate());
	}
    
}
