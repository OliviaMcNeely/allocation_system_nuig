package com.nuig.allocation_system.message;

public class ResponseLecturer {

    private long lecturerId;

    private String firstname;

    private String surname;

    private String school;

    private String email;

    public ResponseLecturer() {
    }

    public ResponseLecturer(long lecturerId, String firstname, String surname, String school, String email) {
        this.lecturerId = lecturerId;
        this.firstname = firstname;
        this.surname = surname;
        this.school = school;
        this.email = email;
    }

    public long getLecturerId() {
        return lecturerId;
    }

    public void setLecturerId(long lecturerId) {
        this.lecturerId = lecturerId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
}
