package com.nuig.allocation_system.repository;

import java.util.Optional;

import com.nuig.allocation_system.model.Student;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {

    Optional<Student> findByUsername(String username);

	Boolean existsByUsername(String username);

	Boolean existsByEmail(String email);
    
}
