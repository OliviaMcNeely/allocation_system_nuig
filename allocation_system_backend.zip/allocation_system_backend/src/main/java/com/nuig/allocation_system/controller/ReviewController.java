package com.nuig.allocation_system.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.nuig.allocation_system.message.ResponseLecturer;
import com.nuig.allocation_system.model.Lecturer;
import com.nuig.allocation_system.model.Review;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.LecturerRepository;
import com.nuig.allocation_system.repository.ReviewRepository;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class ReviewController {

    @Autowired
    ReviewRepository reviewRepository;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    LecturerRepository lecturerRepository;

    @GetMapping("/{studentId}/reviews")
    public ResponseEntity<?> getAllStudentReviews(@PathVariable("studentId") long studentId) {

        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                List<Review> reviews = new ArrayList<>();
                for(Review r : student.getReviews()) {
                    ResponseLecturer responseLecturer = new ResponseLecturer(r.getLecturer().getUserId(), r.getLecturer().getFirstname(),
                    r.getLecturer().getSurname(), r.getLecturer().getSchool(), r.getLecturer().getEmail());
                    r.setResponseLecturer(responseLecturer);
                    reviews.add(r);
                }
                return new ResponseEntity<>(reviews, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/review/{studentId}/{lecturerId}")
    public ResponseEntity<?> createReview(@PathVariable("studentId") long studentId, @PathVariable("lecturerId") long lecturerId, @RequestBody Review r) {

        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            Optional<Lecturer> lecturerData = lecturerRepository.findById(lecturerId);

            if(studentData.isPresent() && lecturerData.isPresent()) {

                Student student = studentData.get();
                Lecturer lecturer = lecturerData.get();

                Review review = new Review(r.getReviewDescription(), r.getRating(), lecturer, student);
                reviewRepository.save(review);

                student.getReviews().add(review);
                studentRepository.save(student);

                lecturer.getReviews().add(review);
                lecturerRepository.save(lecturer);

                return new ResponseEntity<>(new MessageResponse("Review created successfully"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student or Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception ex){
            return new ResponseEntity<>(new MessageResponse("Error: " + ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
}
