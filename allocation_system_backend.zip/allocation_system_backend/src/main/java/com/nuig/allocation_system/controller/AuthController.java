package com.nuig.allocation_system.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nuig.allocation_system.exception.TokenRefreshException;
import com.nuig.allocation_system.model.ERole;
import com.nuig.allocation_system.model.Lecturer;
import com.nuig.allocation_system.model.RefreshToken;
import com.nuig.allocation_system.model.Role;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.request.LoginRequest;
import com.nuig.allocation_system.payload.request.SignupRequest;
import com.nuig.allocation_system.payload.request.TokenRefreshRequest;
import com.nuig.allocation_system.payload.response.JwtResponse;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.payload.response.TokenRefreshResponse;
import com.nuig.allocation_system.repository.LecturerRepository;
import com.nuig.allocation_system.repository.RoleRepository;
import com.nuig.allocation_system.repository.StudentRepository;
import com.nuig.allocation_system.security.jwt.JwtUtils;
import com.nuig.allocation_system.security.services.RefreshTokenService;
import com.nuig.allocation_system.security.services.UserDetailsImpl;


@RestController
@RequestMapping("/allocationapp")
public class AuthController {
    
    @Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	StudentRepository studentRepository;

    @Autowired
	LecturerRepository lecturerRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtUtils jwtUtils;

    @Autowired
    RefreshTokenService refreshTokenService;

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

        try {

            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

            SecurityContextHolder.getContext().setAuthentication(authentication);
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            String jwt = jwtUtils.generateJwtToken(userDetails);
            	
            List<String> roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toList());

            RefreshToken refreshToken = refreshTokenService.createRefreshToken(userDetails.getUserId());

            return ResponseEntity.ok(new JwtResponse(jwt,
                                    refreshToken.getToken(),
                                    userDetails.getUserId(), 
                                    userDetails.getUsername(), 
                                    userDetails.getEmail(), 
                                    roles));
        
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/refreshtoken")
    public ResponseEntity<?> refreshtoken(@Valid @RequestBody TokenRefreshRequest request) {
        String requestRefreshToken = request.getRefreshToken();

        return refreshTokenService.findByToken(requestRefreshToken)
            .map(refreshTokenService::verifyExpiration)
            .map(RefreshToken::getUser)
            .map(user -> {
                String token = jwtUtils.generateTokenFromUsername(user.getUsername());
                return ResponseEntity.ok(new TokenRefreshResponse(token, requestRefreshToken));
            })
            .orElseThrow(() -> new TokenRefreshException(requestRefreshToken,
                "Refresh token is not in database!"));
    }

	@PostMapping("/signup/student")
	public ResponseEntity<?> registerStudent(@Valid @RequestBody SignupRequest signUpRequest) {
        
        try {

            if (studentRepository.existsByUsername(signUpRequest.getUsername())) {
                return new ResponseEntity<>(new MessageResponse("Error: ID is already in use!"), HttpStatus.IM_USED);
            }

            if (studentRepository.existsByEmail(signUpRequest.getEmail())) {
                return new ResponseEntity<>(new MessageResponse("Error: Email is already in use!"), HttpStatus.IM_USED);
            }

            Student student = new Student(
                            signUpRequest.getUsername(), 
                            signUpRequest.getEmail(),
                            encoder.encode(signUpRequest.getPassword()),
                            signUpRequest.getFirstname(),
                            signUpRequest.getSurname(),
                            signUpRequest.getSchool(),
                            signUpRequest.getLevel());

            Role role = roleRepository.findByName(ERole.ROLE_STUDENT)
                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            

            student.setRole(role);
            studentRepository.save(student);

            return ResponseEntity.ok(new MessageResponse("Student registered successfully!"));

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error:" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
	}

    @PostMapping("/signup/lecturer")
	public ResponseEntity<?> registerLecturer(@Valid @RequestBody SignupRequest signUpRequest) {
        
        try {

            if (lecturerRepository.existsByUsername(signUpRequest.getUsername())) {
                return new ResponseEntity<>(new MessageResponse("Error: ID is already in use!"), HttpStatus.IM_USED);
            }

            if (lecturerRepository.existsByEmail(signUpRequest.getEmail())) {
                return new ResponseEntity<>(new MessageResponse("Error: Email is already in use!"), HttpStatus.IM_USED);
            }

            Lecturer lecturer = new Lecturer(
                            signUpRequest.getUsername(), 
                            signUpRequest.getEmail(),
                            encoder.encode(signUpRequest.getPassword()),
                            signUpRequest.getFirstname(),
                            signUpRequest.getSurname(),
                            signUpRequest.getSchool());

            Role role = roleRepository.findByName(ERole.ROLE_LECTURER)
                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            

            lecturer.setRole(role);
            lecturerRepository.save(lecturer);

            return ResponseEntity.ok(new MessageResponse("Lecturer registered successfully!"));

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
	}
    
}
