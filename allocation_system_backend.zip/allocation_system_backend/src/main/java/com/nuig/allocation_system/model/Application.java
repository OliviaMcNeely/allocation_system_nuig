package com.nuig.allocation_system.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Application {
    
    @Id
    @Column(name = "applicationId")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long applicationId;

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="studentId")
	private Student student;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "positionId")
    private Position position;

    @Column(name = "applicationStatus")
    @Size(max = 20)
    private String applicationStatus;

    @JsonFormat(pattern="dd-MM-yyyy")
    @Column(name = "dateApplied")
    private Date dateApplied;

    public Application() {
    }

    public Application(Date dateApplied) {
        this.applicationStatus = "received";
        this.dateApplied = dateApplied;
    }

    public long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(long applicationId) {
        this.applicationId = applicationId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public Date getDateApplied() {
        return dateApplied;
    }

    public void setDateApplied(Date dateApplied) {
        this.dateApplied = dateApplied;
    }
    
}
