package com.nuig.allocation_system.message;

public class ResponseRecommendation {

    private long studentId;

    private String name;

    private double score;

    private String course;

    private String school;

    public ResponseRecommendation() {
    }

    public ResponseRecommendation(long studentId, String name, double score, String course, String school) {
        this.studentId = studentId;
        this.name = name;
        this.score = score;
        this.course = course;
        this.school = school;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
    
    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }
}
