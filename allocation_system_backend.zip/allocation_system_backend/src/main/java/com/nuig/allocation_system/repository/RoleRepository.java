package com.nuig.allocation_system.repository;

import java.util.Optional;

import com.nuig.allocation_system.model.ERole;
import com.nuig.allocation_system.model.Role;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByName(ERole name);
    
}
