package com.nuig.allocation_system.model;

public enum ERole {
	ROLE_STUDENT,
    ROLE_LECTURER
}
