package com.nuig.allocation_system.model;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "resumes")
public class Resume extends File {

    @OneToOne(mappedBy = "resume")
    private Student student;

    public Resume() {
    }

    public Resume(String name, String type, byte[] data, Student student) {
        super(name, type, data);
        this.student = student;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    
}
