package com.nuig.allocation_system.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "students")
public class Student extends User {

    @Column(name = "level", length = 100)
    private String level;

    @Column(name = "courseTitle", length = 100)
    private String courseTitle;

    @Column(name = "bio", length = 2000)
    private String bio;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "resumeId", referencedColumnName = "fileId")
    private Resume resume;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "gradeReportId", referencedColumnName = "fileId")
    private GradeReport gradeReport;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "timetableId", referencedColumnName = "fileId")
    private Timetable timetable;

    @JsonIgnore
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
        name = "studentsSkills",
        joinColumns = @JoinColumn(name = "userId"),
        inverseJoinColumns = @JoinColumn(name = "skillId")
    )
    private List<Skill> skills = new ArrayList<>();

    @JsonIgnore
    @ManyToMany(cascade = CascadeType.PERSIST)
    @JoinTable(
        name = "studentPositionsLikes", 
        joinColumns = @JoinColumn(name = "studentId"), 
        inverseJoinColumns = @JoinColumn(name = "positionId")
    )
    private List<Position> positionsLikes = new ArrayList<>();

    @OneToMany(mappedBy="student", cascade = CascadeType.ALL)
    private List<Experience> experience = new ArrayList<>();

    @OneToMany(mappedBy="student", cascade = CascadeType.ALL)
    private List<Education> education = new ArrayList<>();

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL)
    private List<Application> applications = new ArrayList<>();

    @JsonIgnore
    @OneToMany(mappedBy="student", cascade = CascadeType.ALL)
    private List<Review> reviews = new ArrayList<>();

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL)
    private List<Recommendations> recommendations = new ArrayList<>();

    public Student() {
    }

    public Student(String username, String email, String password, String firstname, String surname, String school, String level) {
        super(username, email, password, firstname, surname, school);
        this.level = level;
        this.courseTitle = "Course not set";
        this.bio = "";
        this.resume = null;
        this.gradeReport = null;
        this.timetable = null;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public Resume getResume() {
        return resume;
    }

    public void setResume(Resume resume) {
        this.resume = resume;
    }

    public GradeReport getGradereport() {
        return gradeReport;
    }

    public void setGradeReport(GradeReport gradeReport) {
        this.gradeReport = gradeReport;
    }

    public Timetable getTimetable() {
        return timetable;
    }

    public void setTimetable(Timetable timetable) {
        this.timetable = timetable;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    public List<Position> getPositionsLikes() {
        return positionsLikes;
    }

    public void setPositionsLikes(List<Position> positionsLikes) {
        this.positionsLikes = positionsLikes;
    }

    public List<Experience> getExperience() {
        return experience;
    }

    public void setExperience(List<Experience> experience) {
        this.experience = experience;
    }

    public List<Education> getEducation() {
        return education;
    }

    public void setEducation(List<Education> education) {
        this.education = education;
    }

    public List<Application> getApplications() {
        return applications;
    }

    public void setApplications(List<Application> applications) {
        this.applications = applications;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    public List<Recommendations> getRecommendations() {
        return recommendations;
    }

    public void setRecommendations(List<Recommendations> recommendations) {
        this.recommendations = recommendations;
    }

}
