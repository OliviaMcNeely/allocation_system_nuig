package com.nuig.allocation_system.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.nuig.allocation_system.message.ResponseLecturer;

@Entity
@Table(name = "positions")
public class Position {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "positionId")
    private long positionId;

    @Column(name = "moduleCode", length = 10)
    private String moduleCode;

    @Column(name = "moduleTitle", length = 100)
    private String moduleTitle;

    @Column(name = "school", length = 100)
    private String school;

    @Column(name = "hours")
    private int hours;

    @Column(name = "assignmentCorrections", nullable = false, columnDefinition="boolean default false")
    private Boolean assignmentCorrections;

    @Column(name = "numTutors")
    private int numTutors;

    @Column(name = "positionDescription")
    private String description;

    @Column(name = "graduateLevel")
    private String graduateLevel;

    @Column(name = "semester")
    private String semester;

    @Column(name = "location")
    private String location;

    @Column(name = "daytime")
    private String daytime;

    @JsonIgnore
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
        name = "positionSkills", 
        joinColumns = @JoinColumn(name = "positionId"), 
        inverseJoinColumns = @JoinColumn(name = "skillId")
    )
    private List<Skill> skills = new ArrayList<>();

    @JsonIgnore
    @ManyToMany(cascade = CascadeType.PERSIST, mappedBy = "positionsLikes")
    private List<Student> studentsLikes = new ArrayList<>();

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="lecturerId")
	private Lecturer lecturer;

    @OneToMany(mappedBy = "position", cascade = CascadeType.ALL)
    private List<Application> applications = new ArrayList<>();

    @OneToMany(mappedBy = "position", cascade = CascadeType.ALL)
    private List<Recommendations> recommendations = new ArrayList<>();

    @Column(name = "filled", nullable = false, columnDefinition="boolean default false")
    private Boolean filled;

    @Column(name = "acceptances")
    private int acceptances;

    @Transient
    private ResponseLecturer responseLecturer;

    public Position() {
    }

    public Position(String moduleCode, String moduleTitle, String school, int hours, 
    boolean assignmentCorrections, int numTutors, String description, String graduateLevel, 
    String semester, String location, String daytime, Lecturer lecturer) {
        this.moduleCode = moduleCode;
        this.moduleTitle = moduleTitle;
        this.school = school;
        this.hours = hours;
        this.assignmentCorrections = assignmentCorrections;
        this.numTutors = numTutors;
        this.description = description;
        this.graduateLevel = graduateLevel;
        this.semester = semester;
        this.location = location;
        this.daytime = daytime;
        this.lecturer = lecturer;
        this.filled = false;
        this.acceptances = 0;
    }

    public long getPositionId() {
        return positionId;
    }

    public void setPositionId(long positionId) {
        this.positionId = positionId;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    public String getModuleTitle() {
        return moduleTitle;
    }

    public void setModuleTitle(String moduleTitle) {
        this.moduleTitle = moduleTitle;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public boolean getAssignmentCorrections() {
        return assignmentCorrections;
    }

    public void setAssignmentCorrections(boolean assignmentCorrections) {
        this.assignmentCorrections = assignmentCorrections;
    }

    public int getNumTutors() {
        return numTutors;
    }

    public void setNumTutors(int numTutors) {
        this.numTutors = numTutors;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGraduateLevel() {
        return graduateLevel;
    }

    public void setGraduateLevel(String graduateLevel) {
        this.graduateLevel = graduateLevel;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDaytime() {
        return daytime;
    }

    public void setDaytime(String daytime) {
        this.daytime = daytime;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    public List<Student> getStudentsLikes() {
        return studentsLikes;
    }

    public void setStudentsLikes(List<Student> studentsLikes) {
        this.studentsLikes = studentsLikes;
    }

    public Lecturer getLecturer() {
        return lecturer;
    }

    public void setLecturer(Lecturer lecturer) {
        this.lecturer = lecturer;
    }

    public List<Application> getApplications() {
        return applications;
    }

    public void setApplications(List<Application> applications) {
        this.applications = applications;
    }

    public List<Recommendations> getRecommendations() {
        return recommendations;
    }

    public void setRecommendations(List<Recommendations> recommendations) {
        this.recommendations = recommendations;
    }

    public Boolean getFilled() {
        return filled;
    }

    public void setFilled(Boolean filled) {
        this.filled = filled;
    }

    public int getAcceptances() {
        return acceptances;
    }

    public void setAcceptances(int acceptances) {
        this.acceptances = acceptances;
    }

    public ResponseLecturer getResponseLecturer() {
        return responseLecturer;
    }

    public void setResponseLecturer(ResponseLecturer responseLecturer) {
        this.responseLecturer = responseLecturer;
    }
    
}
