package com.nuig.allocation_system.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class User {

    @Id
    @Column(name = "userId")
    @GeneratedValue(strategy = GenerationType.TABLE)
    private Long userId;

    @Column(name = "username", length = 20)
	private String username;

    @Column(name = "email", length = 50)
    private String email;

    @Column(name = "password", length = 100)
    private String password;

    @Column(name = "firstname", length = 50)
    private String firstname;

    @Column(name = "surname", length = 50)
    private String surname;

    @Column(name = "school", length = 50)
    private String school;

    @ManyToOne
	@JoinColumn(name ="roleId")
    private Role role;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "pictureId", referencedColumnName = "fileId")
    private ProfilePicture profilePicture;

    @OneToMany(mappedBy="sender", cascade = CascadeType.ALL)
    private List<Message> sentMessages = new ArrayList<>();

    @OneToMany(mappedBy="recipient", cascade = CascadeType.ALL)
    private List<Message> receivedMessages = new ArrayList<>();
    
    protected User() {
    }

    protected User(String username, String email, String password, String firstname, String surname, String school ) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.firstname = firstname;
        this.surname = surname;
        this.school = school;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public ProfilePicture getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(ProfilePicture profilePicture) {
        this.profilePicture = profilePicture;
    }

    public List<Message> getSentMessages() {
        return sentMessages;
    }

    public void setSentMessages(List<Message> sentMessages) {
        this.sentMessages = sentMessages;
    }

    public List<Message> getReceivedMessages() {
        return receivedMessages;
    }

    public void setReceivedMessages(List<Message> receiveMessages) {
        this.receivedMessages = receiveMessages;
    }
    
}
