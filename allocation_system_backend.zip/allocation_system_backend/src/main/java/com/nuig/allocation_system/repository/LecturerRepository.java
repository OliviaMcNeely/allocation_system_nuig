package com.nuig.allocation_system.repository;

import java.util.Optional;

import com.nuig.allocation_system.model.Lecturer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LecturerRepository extends JpaRepository<Lecturer, Long> {

    Optional<Lecturer> findByUsername(String username);

	Boolean existsByUsername(String username);

	Boolean existsByEmail(String email);
    
}
