package com.nuig.allocation_system.model;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "profilePictures")
public class ProfilePicture extends File {

    @OneToOne(mappedBy = "profilePicture")
    private User user;

    public ProfilePicture() {
    }

    public ProfilePicture(String name, String type, byte[] data, User user) {
        super(name, type, data);
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
}
