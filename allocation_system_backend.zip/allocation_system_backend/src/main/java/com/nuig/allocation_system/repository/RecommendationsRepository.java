package com.nuig.allocation_system.repository;

import com.nuig.allocation_system.model.Recommendations;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RecommendationsRepository extends JpaRepository<Recommendations, String> {
}
