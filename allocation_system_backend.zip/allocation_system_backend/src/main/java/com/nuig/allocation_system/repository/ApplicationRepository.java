package com.nuig.allocation_system.repository;

import java.util.Optional;

import com.nuig.allocation_system.model.Application;
import com.nuig.allocation_system.model.Position;
import com.nuig.allocation_system.model.Student;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicationRepository extends JpaRepository<Application, Long> {

    Boolean existsByStudent(Student student);

    Boolean existsByPosition(Position position);

    Optional<Application> findByPositionAndStudent(Position position, Student student);
    
}