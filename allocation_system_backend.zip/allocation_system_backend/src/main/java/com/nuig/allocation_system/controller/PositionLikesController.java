package com.nuig.allocation_system.controller;

import java.util.Optional;

import com.nuig.allocation_system.model.Position;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.PositionRepository;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class PositionLikesController {

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    PositionRepository positionRepository;

    @GetMapping("/{studentId}/{positionId}/checklike")
    public ResponseEntity<?> checkLikePosition(@PathVariable("studentId") long studentId, @PathVariable("positionId") long positionId) {
        
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            Optional<Position> positionData = positionRepository.findById(positionId);

            if(studentData.isPresent() && positionData.isPresent()) {
                Student student = studentData.get();
                Position position = positionData.get();
                if(student.getPositionsLikes().contains(position)) {
                    return new ResponseEntity<>(true, HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(false, HttpStatus.OK);
                } 
            } else {
                return new ResponseEntity<>(new MessageResponse("Student or position doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping("/{studentId}/{positionId}/like")
    public ResponseEntity<?> likePosition(@PathVariable("studentId") long studentId, @PathVariable("positionId") long positionId) {
        
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            Optional<Position> positionData = positionRepository.findById(positionId);

            if(studentData.isPresent() && positionData.isPresent()) {
                Student student = studentData.get();
                Position position = positionData.get();
                student.getPositionsLikes().add(position);
                position.getStudentsLikes().add(student);
                studentRepository.save(student);
                
                return new ResponseEntity<>(new MessageResponse("Position liked successfully!"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student or position doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{studentId}/{positionId}/unlike")
    public ResponseEntity<?> unlikePosition(@PathVariable("studentId") long studentId, @PathVariable("positionId") long positionId) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            Optional<Position> positionData = positionRepository.findById(positionId);

            if(studentData.isPresent() && positionData.isPresent()) {
                Student student = studentData.get();
                Position position = positionData.get();
                student.getPositionsLikes().remove(position);
                position.getStudentsLikes().remove(student);
                studentRepository.save(student);
                return new ResponseEntity<>(new MessageResponse("Position unliked successfully!"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student or position doesn't exist"), HttpStatus.NOT_FOUND);
            }
            
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
}
