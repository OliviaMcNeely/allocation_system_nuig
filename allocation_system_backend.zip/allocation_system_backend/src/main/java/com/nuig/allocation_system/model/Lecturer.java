package com.nuig.allocation_system.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "lecturers")
public class Lecturer extends User {

    @JsonIgnore
    @OneToMany(mappedBy="lecturer", cascade = CascadeType.ALL)
    private List<Position> position = new ArrayList<>();

    @JsonIgnore
    @OneToMany(mappedBy="lecturer", cascade = CascadeType.ALL)
    private List<Review> reviews = new ArrayList<>();

    public Lecturer() {
    }

    public Lecturer(String username, String email, String password, String firstname, 
    String surname, String school) {
        super(username, email, password, firstname, surname, school);
    }

    public List<Position> getPosition() {
        return position;
    }

    public void setPosition(List<Position> position) {
        this.position = position;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

}
