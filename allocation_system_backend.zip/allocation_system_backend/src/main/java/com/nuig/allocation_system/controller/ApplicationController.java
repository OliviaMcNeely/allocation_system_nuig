package com.nuig.allocation_system.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.nuig.allocation_system.message.ResponseStudent;
import com.nuig.allocation_system.model.Application;
import com.nuig.allocation_system.model.Lecturer;
import com.nuig.allocation_system.model.Position;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.ApplicationRepository;
import com.nuig.allocation_system.repository.LecturerRepository;
import com.nuig.allocation_system.repository.PositionRepository;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class ApplicationController {

    @Autowired
    ApplicationRepository applicationRepository;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    LecturerRepository lecturerRepository;

    @Autowired
    PositionRepository positionRepository;

    @PutMapping("/applications/{lecturerId}")
    public ResponseEntity<?> getAllApplicationsByStatus(@PathVariable("lecturerId") long lecturerId, @RequestBody String status) {
        try {

            Optional<Lecturer> lecturerData = lecturerRepository.findById(lecturerId);
            if(lecturerData.isPresent()) {
                Lecturer lecturer = lecturerData.get();

                List<Application> applications = new ArrayList<>();

                for(Position p : lecturer.getPosition()) {
                    for(Application a : p.getApplications()) {
                        if(a.getApplicationStatus().equals(status)) {
                            applications.add(a);
                        }
                    }
                }
                
                if(applications.isEmpty()) {
                    return new ResponseEntity<>(false, HttpStatus.OK);
                }
                return new ResponseEntity<>(applications, HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/position/applications/{positionId}")
    public ResponseEntity<?> getPositionApplicationsByStatus(@PathVariable("positionId") long positionId, @RequestBody String status) {
        try {

            Optional<Position> positionData = positionRepository.findById(positionId);
            if(positionData.isPresent()) {
                Position position = positionData.get();

                List<Application> applications = new ArrayList<>();

                for(Application a : position.getApplications()) {
                    if(a.getApplicationStatus().equals(status)) {
                        applications.add(a);
                    }
                }

                if(applications.isEmpty()) {
                    return new ResponseEntity<>(false, HttpStatus.OK);
                }
                
                return new ResponseEntity<>(applications, HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/application/student/{applicationId}")
    public ResponseEntity<?> getApplicationStudent(@PathVariable("applicationId") long applicationId) {
        try {

            Optional<Application> applicationData = applicationRepository.findById(applicationId);

            if(applicationData.isPresent()) {
                Application application = applicationData.get();
                Student student = application.getStudent();
                ResponseStudent responseStudent = new ResponseStudent(student.getUserId(), student.getFirstname(), student.getSurname(), 
                student.getSchool(), student.getCourseTitle(), student.getBio(), student.getLevel());
                return new ResponseEntity<>(responseStudent, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Application doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/application/position/{applicationId}")
    public ResponseEntity<?> getApplicationPosition(@PathVariable("applicationId") long applicationId) {
        try {

            Optional<Application> applicationData = applicationRepository.findById(applicationId);

            if(applicationData.isPresent()) {
                Application application = applicationData.get();
                Position position = application.getPosition();
                return new ResponseEntity<>(position, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Application doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/application/{studentId}/{positionId}")
    public ResponseEntity<?> createApplication(@PathVariable("studentId") long studentId, 
    @PathVariable("positionId") long positionId, @RequestBody Application a) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            if(studentData.isPresent()) {
                Student student = studentData.get();

                Optional<Position> positionData = positionRepository.findById(positionId);
                if(positionData.isPresent()) {
                    Position position = positionData.get();
                    Application application = new Application(a.getDateApplied());
                    application.setStudent(student);
                    application.setPosition(position);

                    applicationRepository.save(application);
                    return new ResponseEntity<>(new MessageResponse("Application created successfully"), HttpStatus.CREATED);
                }
                else {
                    return new ResponseEntity<>(new MessageResponse("Position does not exist"), HttpStatus.NOT_FOUND);
                }
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Student does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Exception: " + e),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/application/status/{applicationId}")
    public ResponseEntity<?> updateStatus(@PathVariable("applicationId") long applicationId, @RequestBody String status) {
        try {
            Optional<Application> applicationData = applicationRepository.findById(applicationId);

            if(applicationData.isPresent()) {
                Application application = applicationData.get();
                application.setApplicationStatus(status);
                applicationRepository.save(application);

                Position position = application.getPosition();
                if(status.equals("accepted")) {
                    position.setAcceptances(position.getAcceptances()+1);
                    if(position.getAcceptances() == position.getNumTutors()) {
                        position.setFilled(true);
                        for(Application a : position.getApplications()) {
                            if(!a.getApplicationStatus().equals("accepted")) {
                                a.setApplicationStatus("declined");
                                applicationRepository.save(a);
                            }
                        }
                    }
                }

                positionRepository.save(position);

                return new ResponseEntity<>(new MessageResponse("Application updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Application doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/application/check/{studentId}/{positionId}")
    public ResponseEntity<?> applicationExists(@PathVariable("studentId") long studentId, @PathVariable("positionId") long positionId) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            if(studentData.isPresent()) {

                Optional<Position> positionData = positionRepository.findById(positionId);
                if(positionData.isPresent()) {
                    Position position = positionData.get();

                    List<Application> applications = position.getApplications();
                    for(Application a : applications) {
                        if(a.getStudent().getUserId() == studentId) {
                            return new ResponseEntity<>(true, HttpStatus.OK);
                        }
                    }
                    return new ResponseEntity<>(false, HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(new MessageResponse("Position does not exist"), HttpStatus.NOT_FOUND);
                }
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Student does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Exception: " + e),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/application/{studentId}/{positionId}")
    public ResponseEntity<?> findApplication(@PathVariable("studentId") long studentId, @PathVariable("positionId") long positionId) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            if(studentData.isPresent()) {
                Student student = studentData.get();

                Optional<Position> positionData = positionRepository.findById(positionId);
                if(positionData.isPresent()) {
                    Position position = positionData.get();

                    Optional<Application> applicationData = applicationRepository.findByPositionAndStudent(position, student);
                    if(applicationData.isPresent()) {
                        Application application = applicationData.get();
                        return new ResponseEntity<>(application, HttpStatus.OK);
                    }
                    else {
                        return new ResponseEntity<>(new MessageResponse("Application does not exist"), HttpStatus.NOT_FOUND);
                    }
                }
                else {
                    return new ResponseEntity<>(new MessageResponse("Position does not exist"), HttpStatus.NOT_FOUND);
                }
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Student does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Exception: " + e),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
