package com.nuig.allocation_system.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.nuig.allocation_system.message.ResponseLecturer;
import com.nuig.allocation_system.model.Lecturer;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.LecturerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class LecturerController {

    @Autowired
    LecturerRepository lecturerRepository;

    @GetMapping("/lecturers")
    public ResponseEntity<?> getAllLecturers() {

        try {

            List<Lecturer> lecturers = new ArrayList<>();

            lecturerRepository.findAll().forEach(lecturers::add);

            if(lecturers.isEmpty()) {
                return new ResponseEntity<>(new MessageResponse("No lecturers"), HttpStatus.NO_CONTENT);
            }
            else {
                List<ResponseLecturer> responseLecturers = new ArrayList<>();

                for(Lecturer lecturer : lecturers) {
                    responseLecturers.add(new ResponseLecturer(lecturer.getUserId(), lecturer.getFirstname(), lecturer.getSurname(), 
                    lecturer.getSchool(), lecturer.getEmail()));
                }
                
                return new ResponseEntity<>(responseLecturers, HttpStatus.OK);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/lecturer/{userId}")
    public ResponseEntity<?> getLecturerById(@PathVariable("userId") long userId) {
        try{
            Optional<Lecturer> lecturerData = lecturerRepository.findById(userId);

            if(lecturerData.isPresent()) {
                Lecturer lecturer = lecturerData.get();
                ResponseLecturer responseLecturer = new ResponseLecturer(lecturer.getUserId(), lecturer.getFirstname(), 
                lecturer.getSurname(), lecturer.getSchool(), lecturer.getEmail());
                return new ResponseEntity<>(responseLecturer, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/lecturer/update/{id}")
    public ResponseEntity<?> updateLecturer(@PathVariable("usserId") long userId, @RequestBody Lecturer l) {
        try{

            Optional<Lecturer> lecturerData = lecturerRepository.findById(userId);

            if(lecturerData.isPresent()) {
                Lecturer lecturer = lecturerData.get();
                lecturer.setFirstname(l.getFirstname());
                lecturer.setSurname(l.getSurname());
                lecturer.setPassword(l.getPassword());
                lecturerRepository.save(lecturer);

                return new ResponseEntity<>(new MessageResponse("Lecturer updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/lecturer/delete/{id}")
    public ResponseEntity<?> deleteLecturer(@PathVariable("userId") long userId) {
        try {
            lecturerRepository.deleteById(userId);
            return new ResponseEntity<>(new MessageResponse("Lecturer deleted successfully"), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
