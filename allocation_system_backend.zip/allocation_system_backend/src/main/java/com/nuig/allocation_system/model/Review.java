package com.nuig.allocation_system.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.nuig.allocation_system.message.ResponseLecturer;

@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "reviewId")
    private long reviewId;

    @Column(name = "reviewDescription")
    private String reviewDescription;

    @Column(name = "rating")
    private int rating;

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="lecturerId")
    private Lecturer lecturer;

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="studentId")
    private Student student;

    @Transient
    private ResponseLecturer responseLecturer;

    public Review() {
    }

    public Review(String reviewDescription, int rating, Lecturer lecturer, Student student) {
        this.reviewDescription = reviewDescription;
        this.rating = rating;
        this.lecturer = lecturer;
        this.student = student;
    }

    public Review(String reviewDescription, int rating, ResponseLecturer responseLecturer) {
        this.reviewDescription = reviewDescription;
        this.rating = rating;
        this.responseLecturer = responseLecturer;
    }

    public long getReviewId() {
        return reviewId;
    }

    public void setReviewId(long reviewId) {
        this.reviewId = reviewId;
    }

    public String getReviewDescription() {
        return reviewDescription;
    }

    public void setReviewDescription(String reviewDescription) {
        this.reviewDescription = reviewDescription;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Lecturer getLecturer() {
        return lecturer;
    }

    public void setLecturer(Lecturer lecturer) {
        this.lecturer = lecturer;
    }
    
    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    
    public ResponseLecturer getResponseLecturer() {
        return responseLecturer;
    }

    public void setResponseLecturer(ResponseLecturer responseLecturer) {
        this.responseLecturer = responseLecturer;
    }
}
