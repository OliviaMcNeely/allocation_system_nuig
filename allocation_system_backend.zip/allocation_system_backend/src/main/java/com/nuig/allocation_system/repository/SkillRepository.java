package com.nuig.allocation_system.repository;

import com.nuig.allocation_system.model.Skill;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillRepository extends JpaRepository<Skill, Long> {
    
    Boolean existsBySkill(String skill);

    Skill findBySkill(String skill);

}
