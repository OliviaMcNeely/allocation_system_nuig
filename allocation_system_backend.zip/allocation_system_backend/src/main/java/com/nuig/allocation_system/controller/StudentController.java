package com.nuig.allocation_system.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.nuig.allocation_system.message.ResponseStudent;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class StudentController {
    
    @Autowired
    StudentRepository studentRepository;

    @GetMapping("/students")
    public ResponseEntity<?> getAllStudents() {

        try {

            List<Student> students = new ArrayList<>();

            studentRepository.findAll().forEach(students::add);

            if(students.isEmpty()) {
                return new ResponseEntity<>(new MessageResponse("No students"), HttpStatus.NO_CONTENT);
            }
            else {
                List<ResponseStudent> responseStudents = new ArrayList<>();

                for(Student student : students) {
                    responseStudents.add(new ResponseStudent(student.getUserId(), student.getFirstname(), student.getSurname(), 
                    student.getSchool(), student.getCourseTitle(), student.getBio(), student.getLevel()));
                }
                
                return new ResponseEntity<>(responseStudents, HttpStatus.OK);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/student/{userId}")
    public ResponseEntity<?> getStudentInfoById(@PathVariable("userId") long userId) {
        
        try {

            Optional<Student> studentData = studentRepository.findById(userId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                ResponseStudent responseStudent = new ResponseStudent(student.getUserId(), student.getFirstname(), student.getSurname(), 
                student.getSchool(), student.getCourseTitle(), student.getBio(), student.getLevel());
                return new ResponseEntity<>(responseStudent, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/student/updatebio/{userId}")
    public ResponseEntity<?> updateStudentBio(@PathVariable("userId") long userId, @RequestBody String bio) {

        try {

            Optional<Student> studentData = studentRepository.findById(userId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                student.setBio(bio);
                studentRepository.save(student);
                return new ResponseEntity<>(new MessageResponse("Student bio updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/student/updatedetails/{userId}")
    public ResponseEntity<?> updateStudentDetails(@PathVariable("userId") long userId, @RequestBody Student s) {

        try {

            Optional<Student> studentData = studentRepository.findById(userId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                student.setFirstname(s.getFirstname());
                student.setSurname(s.getSurname());
                student.setCourseTitle(s.getCourseTitle());
                student.setLevel(s.getLevel());
                studentRepository.save(student);
                return new ResponseEntity<>(new MessageResponse("Student details updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/student/delete/{userId}")
    public ResponseEntity<?> deleteStudent(@PathVariable("userId") long userId) {

        try {
            Optional<Student> studentData = studentRepository.findById(userId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                student.setEmail("");
                student.setUsername("");
                student.setPassword("");
                studentRepository.save(student);
                return new ResponseEntity<>(new MessageResponse("Student deleted successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }
            
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/resume/check/{userId}")
    public ResponseEntity<?> checkIfResume(@PathVariable("userId") long userId) {
        
        try {

            Optional<Student> studentData = studentRepository.findById(userId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                if(student.getResume() == null) {
                    return new ResponseEntity<>(false, HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(student.getResume().getFileId(), HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/timetable/check/{userId}")
    public ResponseEntity<?> checkIfTimetable(@PathVariable("userId") long userId) {
        
        try {

            Optional<Student> studentData = studentRepository.findById(userId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                if(student.getTimetable() == null) {
                    return new ResponseEntity<>(false, HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(student.getTimetable().getFileId(), HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/gradereport/check/{userId}")
    public ResponseEntity<?> checkIfGradeReport(@PathVariable("userId") long userId) {
        
        try {

            Optional<Student> studentData = studentRepository.findById(userId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                if(student.getGradereport() == null) {
                    return new ResponseEntity<>(false, HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(student.getGradereport().getFileId(), HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
