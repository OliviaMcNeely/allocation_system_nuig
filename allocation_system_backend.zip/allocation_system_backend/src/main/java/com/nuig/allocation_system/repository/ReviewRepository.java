package com.nuig.allocation_system.repository;

import com.nuig.allocation_system.model.Review;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    
}
