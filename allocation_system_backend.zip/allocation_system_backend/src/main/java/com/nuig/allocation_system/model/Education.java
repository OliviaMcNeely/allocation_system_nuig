package com.nuig.allocation_system.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "education")
public class Education {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "educationId")
    private long educationId;

    @Column(name = "schoolName", length = 100)
    private String schoolName;

    @Column(name = "courseTitle", length = 100)
    private String courseTitle;

    @JsonFormat(pattern="MM/yyyy")
    @Column(name = "startYear")
    private Date startYear;

    @JsonFormat(pattern="MM/yyyy")
    @Column(name = "endYear")
    private Date endYear;

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="studentId")
	private Student student;

    public Education() { 
    }

    public Education(String schoolName, String courseTitle, Date startYear, Date endYear, Student student) {
        this.schoolName = schoolName;
        this.courseTitle = courseTitle;
        this.startYear = startYear;
        this.endYear = endYear;
        this.student = student;
    }

    public long getEducationId() {
        return educationId;
    }

    public void setEducationId(long educationId) {
        this.educationId = educationId;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public Date getStartYear() {
        return startYear;
    }

    public void setStartYear(Date startYear) {
        this.startYear = startYear;
    }

    public Date getEndYear() {
        return endYear;
    }

    public void setEndYear(Date endYear) {
        this.endYear = endYear;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
