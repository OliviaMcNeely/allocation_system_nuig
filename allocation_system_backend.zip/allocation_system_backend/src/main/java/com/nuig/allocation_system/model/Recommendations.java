package com.nuig.allocation_system.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "recommendations")
public class Recommendations {

    @Id
    @Column(name = "recommendationId")
    private String recommendationId;

    @JsonIgnore
    @ManyToOne
	@JoinColumn(name ="studentId")
	private Student student;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "positionId")
    private Position position;

    @Column(name = "score")
    private double score;

    public Recommendations() {
    }

    public Recommendations(Position position, Student student, double score) {
        this.position = position;
        this.student = student;
        this.recommendationId = student.getUserId() + "" + position.getPositionId();
        this.score = score;
    }

    public String getRecommendationId() {
        return recommendationId;
    }

    public void setRecommendationId(String recommendationId) {
        this.recommendationId = recommendationId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
    
}
