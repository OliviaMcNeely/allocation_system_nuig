package com.nuig.allocation_system.repository;

import java.util.Optional;

import com.nuig.allocation_system.model.RefreshToken;
import com.nuig.allocation_system.model.User;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

    @Override
    Optional<RefreshToken> findById(Long id);

    Optional<RefreshToken> findByToken(String token);

    int deleteByUser(User user);
    
}
