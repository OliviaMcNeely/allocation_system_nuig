package com.nuig.allocation_system.controller;

import java.util.Optional;

import com.nuig.allocation_system.model.Experience;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.ExperienceRepository;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class ExperienceController {

    @Autowired
    ExperienceRepository experienceRepository;

    @Autowired
    StudentRepository studentRepository;

    @GetMapping("/{studentId}/experience")
    public ResponseEntity<?> getAllStudentExperience(@PathVariable("studentId") long studentId) {

        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                return new ResponseEntity<>(student.getExperience(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/experience/{studentId}")
    public ResponseEntity<?> createExperience(@PathVariable("studentId") long studentId, @RequestBody Experience e) {

        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {

                Student student = studentData.get();

                experienceRepository.save(new Experience(e.getJobTitle(), e.getCompany(), e.getDescription(), e.getStartDate(), e.getEndDate(), student));

                return new ResponseEntity<>(new MessageResponse("Experience created successfully"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception ex){
            return new ResponseEntity<>(new MessageResponse("Error: " + ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/experience/{experienceId}")
    public ResponseEntity<?> updateExperience(@PathVariable("experienceId") long id, @RequestBody Experience e) {

        try {

            Optional<Experience> experienceData = experienceRepository.findById(id);

            if(experienceData.isPresent()) {
                Experience experience = experienceData.get();
                experience.setJobTitle(e.getJobTitle());
                experience.setCompany(e.getCompany());
                experience.setDescription(e.getDescription());
                experience.setStartDate(e.getStartDate());
                experience.setEndDate(e.getEndDate());
                experienceRepository.save(experience);

                return new ResponseEntity<>(new MessageResponse("Experience updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Experience doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception ex) {
            return new ResponseEntity<>(new MessageResponse("Error: " + ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/experience/{experienceId}")
    public ResponseEntity<?> deleteExperience(@PathVariable("experienceId") long id) {

        try {

            experienceRepository.deleteById(id);
            return new ResponseEntity<>(new MessageResponse("Experience deleted successfully"), HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
}
