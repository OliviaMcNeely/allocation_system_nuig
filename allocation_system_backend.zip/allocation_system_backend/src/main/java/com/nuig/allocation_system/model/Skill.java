package com.nuig.allocation_system.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "skills")
public class Skill {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="skillId")
    private long skillId;

    @Column(name="skill")
    private String skill;

    @OneToMany(mappedBy = "skills", cascade=CascadeType.ALL)
    private List<Student> students = new ArrayList<>();

    @ManyToMany(mappedBy = "skills", cascade=CascadeType.ALL)
    private List<Position> positions = new ArrayList<>();

    public Skill() {
    }

    public Skill(String skill) {
        this.skill = skill;
    }

    public long getSkillId() {
        return skillId;
    }

    public void setSkillId(long skillId) {
        this.skillId = skillId;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public List<Position> getPositions() {
        return positions;
    }

    public void setPositions(List<Position> positions) {
        this.positions = positions;
    }
    
}
