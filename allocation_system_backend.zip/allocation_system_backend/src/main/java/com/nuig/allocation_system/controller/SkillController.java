package com.nuig.allocation_system.controller;

import java.util.Optional;

import com.nuig.allocation_system.model.Position;
import com.nuig.allocation_system.model.Skill;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.PositionRepository;
import com.nuig.allocation_system.repository.SkillRepository;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class SkillController {

    @Autowired
    SkillRepository skillRepository;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    PositionRepository positionRepository;

    @GetMapping("/skill/{skillId}")
    public ResponseEntity<?> getSkillById(@PathVariable("skillId") long skillId) {
        try {

            Optional<Skill> skillData = skillRepository.findById(skillId);

            if(skillData.isPresent()) {
                return new ResponseEntity<>(skillData.get(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Skill doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/student/skill/{studentId}")
    public ResponseEntity<?> getStudentSkills(@PathVariable("studentId") long studentId) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                return new ResponseEntity<>(student.getSkills(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/student/skill/create/{studentId}")
    public ResponseEntity<?> createStudentSkill(@PathVariable("studentId") long studentId, @RequestBody Skill skill) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {
                Student student = studentData.get();

                if(skillRepository.existsBySkill(skill.getSkill())) {
                    Skill originalSkill = skillRepository.findBySkill(skill.getSkill());
                    originalSkill.getStudents().add(student);
                    student.getSkills().add(originalSkill);
                    skillRepository.save(originalSkill);
                    studentRepository.save(student);
                    return new ResponseEntity<>(new MessageResponse("Skill assigned to student successfully"), HttpStatus.CREATED);
                }
                else {
                    skill.getStudents().add(student);
                    skillRepository.save(skill);
                    student.getSkills().add(skill);
                    studentRepository.save(student);
                    return new ResponseEntity<>(new MessageResponse("Skill created and assigned to student successfully"), HttpStatus.CREATED);
                }
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/student/skill/remove/{studentId}/{skillId}")
    public ResponseEntity<?> removeStudentSkill(@PathVariable("studentId") long studentId, @PathVariable("skillId") long skillId) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {
                Student student = studentData.get();

                Optional<Skill> skillData = skillRepository.findById(skillId);

                if(skillData.isPresent()) {
                    Skill skill = skillData.get();

                    skill.getStudents().remove(student);
                    skillRepository.save(skill);

                    student.getSkills().remove(skill);
                    studentRepository.save(student);

                    return new ResponseEntity<>(new MessageResponse("Skill unassigned from student successfully"), HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(new MessageResponse("Skill doesn't exist"), HttpStatus.NOT_FOUND);
                }
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/position/skill/{positionId}")
    public ResponseEntity<?> getPositionSkills(@PathVariable("positionId") long positionId) {
        try {

            Optional<Position> positionData = positionRepository.findById(positionId);

            if(positionData.isPresent()) {
                Position position = positionData.get();
                return new ResponseEntity<>(position.getSkills(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/position/skill/create/{positionId}")
    public ResponseEntity<?> createPositionSkill(@PathVariable("positionId") long positionId, @RequestBody Skill skill) {
        try {

            Optional<Position> positionData = positionRepository.findById(positionId);

            if(positionData.isPresent()) {
                Position position = positionData.get();

                if(skillRepository.existsBySkill(skill.getSkill())) {
                    Skill originalSkill = skillRepository.findBySkill(skill.getSkill());
                    originalSkill.getPositions().add(position);
                    position.getSkills().add(originalSkill);
                    skillRepository.save(originalSkill);
                    positionRepository.save(position);
                    return new ResponseEntity<>(new MessageResponse("Skill assigned to position successfully"), HttpStatus.CREATED);
                }
                else {
                    skill.getPositions().add(position);
                    skillRepository.save(skill);
                    position.getSkills().add(skill);
                    positionRepository.save(position);
                    return new ResponseEntity<>(new MessageResponse("Skill created and assigned to position successfully"), HttpStatus.CREATED);
                }
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/position/skill/remove/{positionId}/{skillId}")
    public ResponseEntity<?> removePositionSkill(@PathVariable("positionId") long positionId, @PathVariable("skillId") long skillId) {
        try {

            Optional<Position> positionData = positionRepository.findById(positionId);

            if(positionData.isPresent()) {
                Position position = positionData.get();

                Optional<Skill> skillData = skillRepository.findById(skillId);

                if(skillData.isPresent()) {
                    Skill skill = skillData.get();

                    skill.getPositions().remove(position);
                    skillRepository.save(skill);

                    position.getSkills().remove(skill);
                    positionRepository.save(position);

                    return new ResponseEntity<>(new MessageResponse("Skill unassigned from position successfully"), HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(new MessageResponse("Skill doesn't exist"), HttpStatus.NOT_FOUND);
                }
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Error" + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
}
