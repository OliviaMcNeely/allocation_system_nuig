package com.nuig.allocation_system.repository;

import com.nuig.allocation_system.model.Message;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Long> {
    
}
