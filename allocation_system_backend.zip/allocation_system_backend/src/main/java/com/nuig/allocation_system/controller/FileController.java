package com.nuig.allocation_system.controller;

import java.util.Optional;

import com.nuig.allocation_system.message.ResponseFile;
import com.nuig.allocation_system.message.ResponseMessage;
import com.nuig.allocation_system.model.GradeReport;
import com.nuig.allocation_system.model.Lecturer;
import com.nuig.allocation_system.model.ProfilePicture;
import com.nuig.allocation_system.model.Resume;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.model.Timetable;
import com.nuig.allocation_system.model.User;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.GradeReportRepository;
import com.nuig.allocation_system.repository.LecturerRepository;
import com.nuig.allocation_system.repository.ProfilePictureRepository;
import com.nuig.allocation_system.repository.ResumeRepository;
import com.nuig.allocation_system.repository.StudentRepository;
import com.nuig.allocation_system.repository.TimetableRepository;
import com.nuig.allocation_system.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.util.StringUtils;


@Controller
@RequestMapping("/allocationapp")
public class FileController {

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private TimetableRepository timetableRepository;

    @Autowired
    private GradeReportRepository gradeReportRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private LecturerRepository lecturerRepository;

    @Autowired
    private ProfilePictureRepository profilePictureRepository;

    @GetMapping("/profile/picture/check/{userId}")
    public ResponseEntity<?> checkIfProfilePicture(@PathVariable("userId") long userId) {
        
        try {

            Optional<User> userData = userRepository.findById(userId);

            if(userData.isPresent()) {
                User user = userData.get();
                if(user.getProfilePicture() == null) {
                    return new ResponseEntity<>(false, HttpStatus.OK);
                }
                else {
                    return new ResponseEntity<>(user.getProfilePicture().getFileId(), HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<>(new MessageResponse("User doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/upload/profile/picture/student/{studentId}")
    public ResponseEntity<?> uploadProfilePictureStudent(@PathVariable("studentId") long studentId, @RequestParam("file") MultipartFile file) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            if(studentData.isPresent()) {

                Student student = studentData.get();

                if(student.getProfilePicture() != null) {
                    profilePictureRepository.deleteById(student.getProfilePicture().getFileId());
                }

                String fileName = StringUtils.cleanPath(file.getOriginalFilename());
                ProfilePicture picture = new ProfilePicture(fileName, file.getContentType(), file.getBytes(), student);
                profilePictureRepository.save(picture);

                student.setProfilePicture(picture);
                studentRepository.save(student);

                return new ResponseEntity<>(new ResponseMessage("Uploaded profile picture successfully: " + file.getOriginalFilename()), HttpStatus.OK);
                
            } else {
                return new ResponseEntity<>(new ResponseMessage("Student does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Could not upload the profile picture: " + e), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PostMapping("/upload/profile/picture/lecturer/{lecturerId}")
    public ResponseEntity<?> uploadProfilePictureLecturer(@PathVariable("lecturerId") long lecturerId, @RequestParam("file") MultipartFile file) {
        try {

            Optional<Lecturer> lecturerData = lecturerRepository.findById(lecturerId);
            if(lecturerData.isPresent()) {

                Lecturer lecturer = lecturerData.get();

                if(lecturer.getProfilePicture() != null) {
                    profilePictureRepository.deleteById(lecturer.getProfilePicture().getFileId());
                }

                String fileName = StringUtils.cleanPath(file.getOriginalFilename());
                ProfilePicture picture = new ProfilePicture(fileName, file.getContentType(), file.getBytes(), lecturer);
                profilePictureRepository.save(picture);

                lecturer.setProfilePicture(picture);
                lecturerRepository.save(lecturer);

                return new ResponseEntity<>(new ResponseMessage("Uploaded profile picture successfully: " + file.getOriginalFilename()), HttpStatus.OK);
                
            } else {
                return new ResponseEntity<>(new ResponseMessage("Lecturer does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Could not upload the profile picture: " + e), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @GetMapping("profile/picture/{pictureId}")
    public ResponseEntity<?> getProfilePicture(@PathVariable long pictureId) {

        try {

            Optional<ProfilePicture> pictureData = profilePictureRepository.findById(pictureId);
            if(pictureData.isPresent()) {

                ProfilePicture picture = pictureData.get();

                String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("allocationapp/picture/download/")
                    .path(String.valueOf(picture.getFileId()))
                    .toUriString();

                ResponseFile responseFile = new ResponseFile(picture.getName(), fileDownloadUri, picture.getType(), picture.getData().length);

                return new ResponseEntity<>(responseFile, HttpStatus.OK);

            } else {
                return new ResponseEntity<>(new ResponseMessage("Could not find picture"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Could not get the profile picture: " + e), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @GetMapping("/picture/download/{fileId}")
    public ResponseEntity<?> downloadProfilePicture(@PathVariable long fileId) {
        try {
            Optional<ProfilePicture> pictureData = profilePictureRepository.findById(fileId);

            if(pictureData.isPresent()) {
                ProfilePicture picture = pictureData.get();

                return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + picture.getName() + "\"")
                .body(picture.getData());
            }
            else {
                return new ResponseEntity<>(new ResponseMessage("Profile picture does not exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/upload/resume/{studentId}")
    public ResponseEntity<?> uploadResume(@PathVariable("studentId") long studentId, @RequestParam("file") MultipartFile file) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            if(studentData.isPresent()) {

                Student student = studentData.get();

                String fileName = StringUtils.cleanPath(file.getOriginalFilename());
                Resume resume = new Resume(fileName, file.getContentType(), file.getBytes(), student);
                resumeRepository.save(resume);

                student.setResume(resume);
                studentRepository.save(student);

                return new ResponseEntity<>(new ResponseMessage("Uploaded resume successfully: " + file.getOriginalFilename()), HttpStatus.OK);
                
            } else {
                return new ResponseEntity<>(new ResponseMessage("Student does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Could not upload the resume: " + e), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @GetMapping("/resume/{fileId}")
    public ResponseEntity<?> getResume(@PathVariable long fileId) {

        try {

            Optional<Resume> resumeData = resumeRepository.findById(fileId);

            if(resumeData.isPresent()) {
                Resume resume = resumeData.get();

                String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("allocationapp/resume/download/")
                    .path(String.valueOf(resume.getFileId()))
                    .toUriString();

                ResponseFile responseFile = new ResponseFile(resume.getName(), fileDownloadUri, resume.getType(), resume.getData().length);

                return new ResponseEntity<>(responseFile, HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(new ResponseMessage("Could not find the resume"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Error: " + e), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/resume/download/{fileId}")
    public ResponseEntity<?> downloadResume(@PathVariable long fileId) {
        try {
            Optional<Resume> resumeData = resumeRepository.findById(fileId);

            if(resumeData.isPresent()) {
                Resume resume = resumeData.get();

                return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resume.getName() + "\"")
                .body(resume.getData());
            }
            else {
                return new ResponseEntity<>(new ResponseMessage("Resume does not exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/upload/timetable/{studentId}")
    public ResponseEntity<?> uploadTimetable(@PathVariable("studentId") long studentId, @RequestParam("file") MultipartFile file) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            if(studentData.isPresent()) {

                Student student = studentData.get();

                String fileName = StringUtils.cleanPath(file.getOriginalFilename());
                Timetable timetable = new Timetable(fileName, file.getContentType(), file.getBytes(), student);
                timetableRepository.save(timetable);

                student.setTimetable(timetable);
                studentRepository.save(student);

                return new ResponseEntity<>(new ResponseMessage("Uploaded timetable successfully: " + file.getOriginalFilename()), HttpStatus.OK);
                
            } else {
                return new ResponseEntity<>(new ResponseMessage("Student does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Could not upload the timetable: " + e), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @GetMapping("/timetable/{fileId}")
    public ResponseEntity<?> getTimetable(@PathVariable long fileId) {

        try {

            Optional<Timetable> timetableData = timetableRepository.findById(fileId);

            if(timetableData.isPresent()) {
                Timetable timetable = timetableData.get();

                String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("allocationapp/timetable/download/")
                    .path(String.valueOf(timetable.getFileId()))
                    .toUriString();

                ResponseFile responseFile = new ResponseFile(timetable.getName(), fileDownloadUri, timetable.getType(), timetable.getData().length);

                return new ResponseEntity<>(responseFile, HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(new ResponseMessage("Could not find the timetable"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Error: " + e), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/timetable/download/{fileId}")
    public ResponseEntity<?> downloadTimetable(@PathVariable long fileId) {
        try {
            Optional<Timetable> timetableData = timetableRepository.findById(fileId);

            if(timetableData.isPresent()) {
                Timetable timetable = timetableData.get();

                return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + timetable.getName() + "\"")
                .body(timetable.getData());
            }
            else {
                return new ResponseEntity<>(new ResponseMessage("Timetable does not exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/upload/gradereport/{studentId}")
    public ResponseEntity<?> uploadGradeReport(@PathVariable("studentId") long studentId, @RequestParam("file") MultipartFile file) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);
            if(studentData.isPresent()) {

                Student student = studentData.get();

                String fileName = StringUtils.cleanPath(file.getOriginalFilename());
                GradeReport gradeReport = new GradeReport(fileName, file.getContentType(), file.getBytes(), student);
                gradeReportRepository.save(gradeReport);

                student.setGradeReport(gradeReport);
                studentRepository.save(student);

                return new ResponseEntity<>(new ResponseMessage("Uploaded grade report successfully: " + file.getOriginalFilename()), HttpStatus.OK);
                
            } else {
                return new ResponseEntity<>(new ResponseMessage("Student does not exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Could not upload the grade report: " + e), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @GetMapping("/gradereport/{fileId}")
    public ResponseEntity<?> getGradeReport(@PathVariable long fileId) {

        try {

            Optional<GradeReport> gradeReportData = gradeReportRepository.findById(fileId);

            if(gradeReportData.isPresent()) {
                GradeReport gradeReport = gradeReportData.get();

                String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("allocationapp/gradereport/download/")
                    .path(String.valueOf(gradeReport.getFileId()))
                    .toUriString();

                ResponseFile responseFile = new ResponseFile(gradeReport.getName(), fileDownloadUri, gradeReport.getType(), gradeReport.getData().length);

                return new ResponseEntity<>(responseFile, HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(new ResponseMessage("Could not find the grade report"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new ResponseMessage("Error: " + e), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/gradereport/download/{fileId}")
    public ResponseEntity<?> downloadGradeReport(@PathVariable long fileId) {
        try {

            Optional<GradeReport> gradeReportData = gradeReportRepository.findById(fileId);

            if(gradeReportData.isPresent()) {
                GradeReport gradeReport = gradeReportData.get();

                return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + gradeReport.getName() + "\"")
                .body(gradeReport.getData());
            }
            else {
                return new ResponseEntity<>(new ResponseMessage("Grade Report does not exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
