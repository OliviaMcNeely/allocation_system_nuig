package com.nuig.allocation_system.repository;

import com.nuig.allocation_system.model.Experience;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ExperienceRepository extends JpaRepository<Experience, Long> {
    
}
