package com.nuig.allocation_system.model;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "timetables")
public class Timetable extends File {
    
    @OneToOne(mappedBy = "timetable")
    private Student student;

    public Timetable() {
    }

    public Timetable(String name, String type, byte[] data, Student student) {
        super(name, type, data);
        this.student = student;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    
}
