package com.nuig.allocation_system.message;

public class ResponseUser {

    private long userId;

    private String firstname;

    private String surname;

    public ResponseUser() {       
    }

    public ResponseUser(long userId, String firstname, String surname) {
        this.userId = userId;
        this.firstname = firstname;
        this.surname = surname;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
    
}
