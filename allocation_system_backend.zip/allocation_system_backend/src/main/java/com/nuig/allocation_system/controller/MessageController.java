package com.nuig.allocation_system.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.nuig.allocation_system.message.ResponseUser;
import com.nuig.allocation_system.model.Message;
import com.nuig.allocation_system.model.User;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.MessageRepository;
import com.nuig.allocation_system.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/allocationapp")
public class MessageController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    MessageRepository messageRepository;
    
    @PostMapping("/new/message/{senderId}/{recipientId}")
    public ResponseEntity<?> createMessage(@PathVariable("senderId") long senderId, @PathVariable("recipientId") long recipientId, 
    @RequestBody Message message) {

        try {

            Optional<User> senderData = userRepository.findById(senderId);
            if(senderData.isPresent()) {
                User sender = senderData.get();

                Optional<User> recipientData = userRepository.findById(recipientId);
                if(recipientData.isPresent()) {
                    User recipient = recipientData.get();

                    Message m = new Message(message.getMessageText(), message.getDate(), sender, recipient);
                    messageRepository.save(m);

                    sender.getSentMessages().add(m);
                    userRepository.save(sender);

                    recipient.getReceivedMessages().add(m);
                    userRepository.save(recipient);

                    return new ResponseEntity<>(new MessageResponse("Message created successfully"), HttpStatus.CREATED);

                } else {
                    return new ResponseEntity<>(new MessageResponse("Recipient doesn't exist"), HttpStatus.NOT_FOUND);
                }

            } else {
                return new ResponseEntity<>(new MessageResponse("Sender doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception ex){
            return new ResponseEntity<>(new MessageResponse("Error: " + ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/handle/opened/{messageId}")
    public ResponseEntity<?> handleOpen(@PathVariable("messageId") long messageId) {
        try {

            Optional<Message> messageData = messageRepository.findById(messageId);

            if(messageData.isPresent()) {
                Message message = messageData.get();
                message.setOpened(!message.isOpened());
                messageRepository.save(message);
                return new ResponseEntity<>(HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Message doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/message/{messageId}")
    public ResponseEntity<?> getMessageById(@PathVariable("messageId") long messageId) {
        try {

            Optional<Message> messageData = messageRepository.findById(messageId);

            if(messageData.isPresent()) {
                Message m = messageData.get();
                m.setRSender(new ResponseUser(m.getSender().getUserId(), m.getSender().getFirstname(), m.getSender().getSurname()));
                m.setRRecipient(new ResponseUser(m.getRecipient().getUserId(), m.getRecipient().getFirstname(), m.getRecipient().getSurname()));
                return new ResponseEntity<>(m, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Message doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{userId}/sent/messages")
    public ResponseEntity<?> getAllUserSentMessages(@PathVariable("userId") long userId) {

        try {

            Optional<User> userData = userRepository.findById(userId);

            if(userData.isPresent()) {
                User user = userData.get();
                List<Message> messages = user.getSentMessages();
                List<Message> smessages = new ArrayList<>();
                for(Message m : messages) {
                    if(!m.getSenderDelete()) {
                        m.setRSender(new ResponseUser(m.getSender().getUserId(), m.getSender().getFirstname(), m.getSender().getSurname()));
                        m.setRRecipient(new ResponseUser(m.getRecipient().getUserId(), m.getRecipient().getFirstname(), m.getRecipient().getSurname()));
                        smessages.add(m);
                    }
                }
                Collections.sort(smessages);
                return new ResponseEntity<>(smessages, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("User doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{userId}/received/messages")
    public ResponseEntity<?> getAllUserReceivedMessages(@PathVariable("userId") long userId) {

        try {

            Optional<User> userData = userRepository.findById(userId);

            if(userData.isPresent()) {
                User user = userData.get();
                List<Message> messages = user.getReceivedMessages();
                List<Message> rmessages = new ArrayList<>();
                for(Message m : messages) {
                    if(!m.getRecipientDelete()) {
                        m.setRSender(new ResponseUser(m.getSender().getUserId(), m.getSender().getFirstname(), m.getSender().getSurname()));
                        m.setRRecipient(new ResponseUser(m.getRecipient().getUserId(), m.getRecipient().getFirstname(), m.getRecipient().getSurname()));
                        rmessages.add(m);
                    }
                }
                Collections.sort(rmessages);
                return new ResponseEntity<>(rmessages, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("User doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{userId}/received/messages/four")
    public ResponseEntity<?> getTopFourReceivedMessages(@PathVariable("userId") long userId) {

        try {

            Optional<User> userData = userRepository.findById(userId);

            if(userData.isPresent()) {
                User user = userData.get();
                List<Message> messages = user.getReceivedMessages();
                List<Message> fourmessages = new ArrayList<>();
                int length;
                if(messages.size() < 4) {
                    length = messages.size();
                }
                else {
                    length = 4;
                }

                for (int i = 0; i < length; i++) {
                    Message m = messages.get(i);
                    if(!m.getRecipientDelete()) {
                        m.setRSender(new ResponseUser(m.getSender().getUserId(), m.getSender().getFirstname(), m.getSender().getSurname()));
                        m.setRRecipient(new ResponseUser(m.getRecipient().getUserId(), m.getRecipient().getFirstname(), m.getRecipient().getSurname()));
                        fourmessages.add(m);
                    }
                }
                Collections.sort(fourmessages);
                return new ResponseEntity<>(fourmessages, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("User doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/received/message/{messageId}/{userId}")
    public ResponseEntity<?> deleteReceivedMessage(@PathVariable("messageId") long messageId, @PathVariable("userId") long userId) {

        try {

            Optional<User> userData = userRepository.findById(userId);

            if(userData.isPresent()) {
                User user = userData.get();

                Optional<Message> messageData = messageRepository.findById(messageId);
                if(messageData.isPresent()) {
                    Message message = messageData.get();

                    user.getReceivedMessages().remove(message);
                    userRepository.save(user);

                    message.setRecipientDelete(true);
                    messageRepository.save(message);
                    return new ResponseEntity<>(new MessageResponse("Message deleted successfully"), HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(new MessageResponse("Message doesn't exist"), HttpStatus.NOT_FOUND);
                }
            } else {
                return new ResponseEntity<>(new MessageResponse("User doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/sent/message/{messageId}/{userId}")
    public ResponseEntity<?> deleteSentMessage(@PathVariable("messageId") long messageId, @PathVariable("userId") long userId) {

        try {

            Optional<User> userData = userRepository.findById(userId);

            if(userData.isPresent()) {
                User user = userData.get();

                Optional<Message> messageData = messageRepository.findById(messageId);
                if(messageData.isPresent()) {
                    Message message = messageData.get();

                    user.getSentMessages().remove(message);
                    userRepository.save(user);

                    message.setSenderDelete(true);
                    messageRepository.save(message);
                    return new ResponseEntity<>(new MessageResponse("Message deleted successfully"), HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(new MessageResponse("Message doesn't exist"), HttpStatus.NOT_FOUND);
                }
            } else {
                return new ResponseEntity<>(new MessageResponse("User doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
