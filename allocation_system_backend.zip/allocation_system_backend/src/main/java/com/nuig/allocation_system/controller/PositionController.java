package com.nuig.allocation_system.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import com.nuig.allocation_system.message.ResponseLecturer;
import com.nuig.allocation_system.message.ResponseRecommendation;
import com.nuig.allocation_system.model.Application;
import com.nuig.allocation_system.model.Lecturer;
import com.nuig.allocation_system.model.Position;
import com.nuig.allocation_system.model.Recommendations;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.LecturerRepository;
import com.nuig.allocation_system.repository.PositionRepository;
import com.nuig.allocation_system.repository.RecommendationsRepository;
import com.nuig.allocation_system.repository.SkillRepository;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
@RequestMapping("/allocationapp")
public class PositionController {

    @Autowired
    PositionRepository positionRepository;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    RecommendationsRepository recommendationRepository;

    @Autowired
    LecturerRepository lecturerRepository;

    @Autowired
    SkillRepository skillRepository;

    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/all/positions")
    public ResponseEntity<?> getAllPositions() {
        try {

            List<Position> allPositions = new ArrayList<>();
            positionRepository.findAll().forEach(allPositions::add);
            List<Position> positions = new ArrayList<>();

            for(Position p : allPositions) {
                if(!p.getFilled()) {
                    ResponseLecturer responseLecturer = new ResponseLecturer(p.getLecturer().getUserId(), p.getLecturer().getFirstname(),
                    p.getLecturer().getSurname(), p.getLecturer().getSchool(), p.getLecturer().getEmail());
                    p.setResponseLecturer(responseLecturer);
                    positions.add(p);
                }
            }

            if(positions.isEmpty()) {
                return new ResponseEntity<>(new MessageResponse("No positions"), HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(positions, HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/position/{positionId}")
    public ResponseEntity<?> getPositionById(@PathVariable("positionId") long positionId) {
        try {

            Optional<Position> positionData = positionRepository.findById(positionId);

            if(positionData.isPresent()) {
                Position p = positionData.get();
                ResponseLecturer responseLecturer = new ResponseLecturer(p.getLecturer().getUserId(), p.getLecturer().getFirstname(),
                p.getLecturer().getSurname(), p.getLecturer().getSchool(), p.getLecturer().getEmail());
                p.setResponseLecturer(responseLecturer);
                return new ResponseEntity<>(p, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/position/create/{lecturerId}")
    public ResponseEntity<?> createPosition(@PathVariable("lecturerId") long lecturerId, @RequestBody Position p) {
        try {

            Optional<Lecturer> lecturerData = lecturerRepository.findById(lecturerId);

            if(lecturerData.isPresent()) {

                Lecturer lecturer = lecturerData.get();

                Position position = positionRepository
                .save(new Position(p.getModuleCode(), p.getModuleTitle(), p.getSchool(), p.getHours(), 
                p.getAssignmentCorrections(), p.getNumTutors(), p.getDescription(), p.getGraduateLevel(), 
                p.getSemester(), p.getLocation(), p.getDaytime(), lecturer));

                lecturer.getPosition().add(position);

                return new ResponseEntity<>(position, HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/position/update/details/{positionId}")
    public ResponseEntity<?> updatePositionDetails(@PathVariable("positionId") long positionId, @RequestBody Position p) {

        try {

            Optional<Position> positionData = positionRepository.findById(positionId);

            if(positionData.isPresent()) {
                Position position = positionData.get();
                position.setModuleCode(p.getModuleCode());
                position.setModuleTitle(p.getModuleTitle());
                position.setSchool(p.getSchool());
                position.setHours(p.getHours());
                position.setAssignmentCorrections(p.getAssignmentCorrections());
                position.setNumTutors(p.getNumTutors());
                position.setGraduateLevel(p.getGraduateLevel());
                position.setSemester(p.getSemester());
                position.setLocation(p.getLocation());
                position.setDaytime(p.getDaytime());
                positionRepository.save(position);

                return new ResponseEntity<>(new MessageResponse("Position updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/position/update/description/{positionId}")
    public ResponseEntity<?> updatePositionDescription(@PathVariable("positionId") long positionId, @RequestBody String description) {
        try {
        
            Optional<Position> positionData = positionRepository.findById(positionId);

            if(positionData.isPresent()) {
                Position position = positionData.get();
                position.setDescription(description);
                positionRepository.save(position);

                return new ResponseEntity<>(new MessageResponse("Position description updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }
        } catch (Exception e){
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/position/delete/{positionId}")
    public ResponseEntity<?> deletePosition(@PathVariable("positionId") long positionId) {
        try {

            Optional<Position> positionData = positionRepository.findById(positionId);

            if(positionData.isPresent()) {
                Position position = positionData.get();
                position.getStudentsLikes().clear();
                positionRepository.save(position);
                studentRepository.findAll().iterator().next().getPositionsLikes().remove(position);

                position.getSkills().clear();
                skillRepository.findAll().iterator().next().getPositions().remove(position);

                positionRepository.deleteById(positionId);
                return new ResponseEntity<>(new MessageResponse("Position deleted successfully"), HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Position doesn't exisit"), HttpStatus.NOT_FOUND);
            }
      
        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/positions/random")
    public ResponseEntity<?> get4RandomPositons() {
        try {

            List<Position> positions = new ArrayList<>();
            positionRepository.findAll().forEach(positions::add);
            if(positions.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            List<Position> randomPositions = new ArrayList<>();
            Random rand = new Random();
            for (int i = 0; i < 4; i++) {
                if(positions.isEmpty()) {
                    return new ResponseEntity<>(randomPositions, HttpStatus.OK);
                }
                randomPositions.add(positions.remove(rand.nextInt(positions.size())));
            }

            return new ResponseEntity<>(randomPositions, HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/positions/four/{lecturerId}")
    public ResponseEntity<?> get4LecturerPositons(@PathVariable("lecturerId") long lecturerId) {
        try {

            Optional<Lecturer> lecturerData = lecturerRepository.findById(lecturerId);

            if(lecturerData.isPresent()) {

                Lecturer lecturer = lecturerData.get();

                List<Position> positions = lecturer.getPosition();

                List<Position> fourPositions = new ArrayList<>();
                Random rand = new Random();
                for (int i = 0; i < 4; i++) {
                    if(positions.isEmpty()) {
                        return new ResponseEntity<>(fourPositions, HttpStatus.CREATED);
                    }
                    fourPositions.add(positions.remove(rand.nextInt(positions.size())));
                }

                return new ResponseEntity<>(fourPositions, HttpStatus.OK);

            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/positions/{lecturerId}")
    public ResponseEntity<?> getAllLecturerPositons(@PathVariable("lecturerId") long lecturerId) {
        try {

            Optional<Lecturer> lecturerData = lecturerRepository.findById(lecturerId);

            if(lecturerData.isPresent()) {

                Lecturer lecturer = lecturerData.get();

                List<Position> positions = lecturer.getPosition();

                return new ResponseEntity<>(positions, HttpStatus.OK);

            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/check/position/{lecturerId}/{positionId}")
    public ResponseEntity<?> checkLecturerPosition(@PathVariable("lecturerId") long lecturerId, @PathVariable("positionId") long positionId) {
        try {

            Optional<Lecturer> lecturerData = lecturerRepository.findById(lecturerId);
            if(lecturerData.isPresent()) {
                Lecturer lecturer = lecturerData.get();
                Optional<Position> positionData = positionRepository.findById(positionId);
                if(positionData.isPresent()) {
                    Position position = positionData.get();
                    if(lecturer.getPosition().contains(position)) {
                        return new ResponseEntity<>(true, HttpStatus.OK);
                    }
                    else {
                        return new ResponseEntity<>(false, HttpStatus.OK);
                    }
                } else {
                    return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.NOT_FOUND);
                }
            } else {
                return new ResponseEntity<>(new MessageResponse("Lecturer doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/positions/favourite/{studentId}")
    public ResponseEntity<?> getAllFavouritedPositions(@PathVariable("studentId") long studentId) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {

                Student student = studentData.get();

                List<Position> allPositions = student.getPositionsLikes();
                List<Position> positions = new ArrayList<>();

                for(Position p : allPositions) {
                    ResponseLecturer responseLecturer = new ResponseLecturer(p.getLecturer().getUserId(), p.getLecturer().getFirstname(),
                    p.getLecturer().getSurname(), p.getLecturer().getSchool(), p.getLecturer().getEmail());
                    p.setResponseLecturer(responseLecturer);
                    positions.add(p);
                }

                return new ResponseEntity<>(positions, HttpStatus.OK);

            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/positions/applied/{studentId}")
    public ResponseEntity<?> getAllAppliedPositionsByStatus(@PathVariable("studentId") long studentId, @RequestBody String status) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {

                Student student = studentData.get();

                List<Position> positions =  new ArrayList<>();

                for(Application a : student.getApplications()) {
                    if(a.getApplicationStatus().equals(status)) {
                        Position p = a.getPosition();
                        ResponseLecturer responseLecturer = new ResponseLecturer(p.getLecturer().getUserId(), p.getLecturer().getFirstname(),
                        p.getLecturer().getSurname(), p.getLecturer().getSchool(), p.getLecturer().getEmail());
                        p.setResponseLecturer(responseLecturer);
                        positions.add(p);
                    }
                }

                return new ResponseEntity<>(positions, HttpStatus.OK);

            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/positions/applied/offered/accepted/{studentId}")
    public ResponseEntity<?> getAllAppliedOfferedAcceptedPositions(@PathVariable("studentId") long studentId) {
        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {

                Student student = studentData.get();

                List<Position> positions =  new ArrayList<>();

                for(Application a : student.getApplications()) {
                    if(a.getApplicationStatus().equals("received") || a.getApplicationStatus().equals("offered") || a.getApplicationStatus().equals("accepted")) {
                        Position p = a.getPosition();
                        ResponseLecturer responseLecturer = new ResponseLecturer(p.getLecturer().getUserId(), p.getLecturer().getFirstname(),
                        p.getLecturer().getSurname(), p.getLecturer().getSchool(), p.getLecturer().getEmail());
                        p.setResponseLecturer(responseLecturer);
                        positions.add(p);
                    }
                }

                return new ResponseEntity<>(positions, HttpStatus.OK);

            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/check/recommendations/{positionId}")
    public ResponseEntity<?> checkRecommendations(@PathVariable("positionId") long positionId) {
        Optional<Position> positionData = positionRepository.findById(positionId);

        if(positionData.isPresent()) {
            Position position = positionData.get();
            if(position.getRecommendations().isEmpty()) {
                return new ResponseEntity<>(true, HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(false, HttpStatus.OK);
            }
        }
        else {
            return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/student/list/{positionId}")
    public ResponseEntity<?> getRecommendationList(@PathVariable("positionId") long positionId) {
        Optional<Position> positionData = positionRepository.findById(positionId);

        if(positionData.isPresent()) {
            Position position = positionData.get();
            List<Recommendations> recommendations = position.getRecommendations();
            recommendations.sort((o1, o2) -> o2.getScore().compareTo(o1.getScore()));

            List<ResponseRecommendation> students = new ArrayList<>();
            for(Recommendations r : recommendations) { 
                students.add(new ResponseRecommendation(r.getStudent().getUserId(), r.getStudent().getFirstname() + " " + r.getStudent().getSurname(),
                r.getScore(), r.getStudent().getCourseTitle(), r.getStudent().getSchool()));
            }
            return new ResponseEntity<>(students, HttpStatus.OK);
        }
        else {
            return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/generate/student/list/{positionId}")
    public ResponseEntity<?> generateRecommendationList(@PathVariable("positionId") long positionId) {

        String url = "http://allocationrecommenderapi.eba-h9w7zy8v.eu-west-1.elasticbeanstalk.com/recommend?id=" + positionId;

        Optional<Position> positionData = positionRepository.findById(positionId);
        if(positionData.isPresent()) {
            Position position = positionData.get();
            
            String ans = restTemplate.getForObject(url, String.class);

            if(ans.equals("created")) {

                List<Recommendations> recommendations = position.getRecommendations();
                List<ResponseRecommendation> students = new ArrayList<>();

                for(Recommendations r : recommendations) { 
                    students.add(new ResponseRecommendation(r.getStudent().getUserId(), r.getStudent().getFirstname() + " " + 
                    r.getStudent().getSurname(), r.getScore(), r.getStudent().getCourseTitle(), r.getStudent().getSchool()));
                }

                return new ResponseEntity<>(students, HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(new MessageResponse("Error with run python"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        else {
            return new ResponseEntity<>(new MessageResponse("Position doesn't exist"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
