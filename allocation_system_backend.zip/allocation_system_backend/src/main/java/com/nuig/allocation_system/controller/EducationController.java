package com.nuig.allocation_system.controller;

import java.util.Optional;

import com.nuig.allocation_system.model.Education;
import com.nuig.allocation_system.model.Student;
import com.nuig.allocation_system.payload.response.MessageResponse;
import com.nuig.allocation_system.repository.EducationRepository;
import com.nuig.allocation_system.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/allocationapp")
public class EducationController {

    @Autowired
    EducationRepository educationRepository;

    @Autowired
    StudentRepository studentRepository;

    @GetMapping("/{studentId}/education")
    public ResponseEntity<?> getAllStudentEducation(@PathVariable("studentId") long studentId) {

        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {
                Student student = studentData.get();
                return new ResponseEntity<>(student.getEducation(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/education/{studentId}")
    public ResponseEntity<?> createEducation(@PathVariable("studentId") long studentId, @RequestBody Education e) {

        try {

            Optional<Student> studentData = studentRepository.findById(studentId);

            if(studentData.isPresent()) {

                Student student = studentData.get();

                educationRepository.save(new Education(e.getSchoolName(), e.getCourseTitle(), e.getStartYear(), e.getEndYear(), student));

                return new ResponseEntity<>(new MessageResponse("Education created successfully"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(new MessageResponse("Student doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception ex){
            return new ResponseEntity<>(new MessageResponse("Error: " + ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/education/{educationId}")
    public ResponseEntity<?> updateEducation(@PathVariable("educationId") long id, @RequestBody Education e) {

        try {

            Optional<Education> educationData = educationRepository.findById(id);

            if(educationData.isPresent()) {
                Education education = educationData.get();
                education.setSchoolName(e.getSchoolName());
                education.setCourseTitle(e.getCourseTitle());
                education.setStartYear(e.getStartYear());
                education.setEndYear(e.getEndYear());
                educationRepository.save(education);

                return new ResponseEntity<>(new MessageResponse("Education updated successfully"), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new MessageResponse("Education doesn't exist"), HttpStatus.NOT_FOUND);
            }

        } catch (Exception ex) {
            return new ResponseEntity<>(new MessageResponse("Error: " + ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/education/{educationId}")
    public ResponseEntity<?> deleteEducation(@PathVariable("educationId") long id) {

        try {
            
            educationRepository.deleteById(id);
            return new ResponseEntity<>(new MessageResponse("Education deleted successfully"), HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(new MessageResponse("Error: " + e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
}
