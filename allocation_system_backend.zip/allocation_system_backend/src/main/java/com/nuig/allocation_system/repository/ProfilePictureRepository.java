package com.nuig.allocation_system.repository;

import com.nuig.allocation_system.model.ProfilePicture;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProfilePictureRepository extends JpaRepository<ProfilePicture, Long>{
    
}
